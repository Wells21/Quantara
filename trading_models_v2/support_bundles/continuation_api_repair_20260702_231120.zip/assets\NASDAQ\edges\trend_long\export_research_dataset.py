"""
Export reproducible research datasets for NASDAQ/trend_long.

Blueprint purpose
-----------------
The edge runtime is the source of truth. This exporter persists what runtime.py
already builds so feature surgery/model training can happen locally or in Colab
without re-engineering features outside the edge runtime.

Outputs are research artifacts only. They are not deployability artifacts until
model training, calibration, threshold sweep, and deployability audits pass.

Run from trading_models_v2:

    python ./assets/NASDAQ/edges/trend_long/export_research_dataset.py --overwrite
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

import pandas as pd

_THIS_FILE = Path(__file__).resolve()
_EDGE_ROOT = _THIS_FILE.parent
_V2_ROOT = _THIS_FILE.parents[4]
_REPO_ROOT = _THIS_FILE.parents[5]
for _path in (_EDGE_ROOT, _V2_ROOT, _REPO_ROOT):
    path_str = str(_path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

import runtime  # noqa: E402
from shared.io.artifact_hash import hash_artifacts  # noqa: E402


EDGE_ID = "NASDAQ/trend_long"
EXPORT_NAME = "research_dataset_v1_compat"


class ResearchDatasetExportError(RuntimeError):
    """Raised when exporting research artifacts must fail closed."""


def _relative_to_v2(path: Path) -> str:
    return path.resolve().relative_to(_V2_ROOT.resolve()).as_posix()


def _output_paths() -> dict[str, Path]:
    root = _EDGE_ROOT / "artifacts" / "research_dataset"
    return {
        "root": root,
        "feature_matrix": root / "nasdaq_trend_long_feature_matrix.csv",
        "candidate_events": root / "nasdaq_trend_long_candidate_events.csv",
        "model_rows": root / "nasdaq_trend_long_model_rows.csv",
        "model_row_manifest": root / "model_row_manifest.json",
        "export_manifest": root / "research_dataset_manifest.json",
    }


def _check_safe_to_write(paths: list[Path], overwrite: bool) -> None:
    existing = [path for path in paths if path.exists()]
    if existing and not overwrite:
        formatted = "\n".join(f"- {path}" for path in existing)
        raise ResearchDatasetExportError(
            "Research dataset output(s) already exist. Use --overwrite to replace intentionally:\n"
            f"{formatted}"
        )


def _write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def _feature_names() -> list[str]:
    return runtime._schema_feature_names()  # noqa: SLF001 - runtime schema is the edge source of truth.


def _feature_export_frame(features: pd.DataFrame, feature_names: list[str]) -> pd.DataFrame:
    base_cols = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close", "edge_id", "side"]
    cols = [col for col in base_cols if col in features.columns] + feature_names
    missing = [col for col in feature_names if col not in features.columns]
    if missing:
        raise ResearchDatasetExportError(f"Runtime feature matrix missing schema features: {missing}")
    return features[cols].copy()


def export_research_dataset(*, overwrite: bool = False, dry_run: bool = False) -> dict[str, Any]:
    started = time.time()
    paths = _output_paths()
    output_files = [
        paths["feature_matrix"],
        paths["candidate_events"],
        paths["model_rows"],
        paths["model_row_manifest"],
        paths["export_manifest"],
    ]
    if dry_run:
        return {
            "status": "DRY_RUN_PASS",
            "edge_id": EDGE_ID,
            "planned_outputs": {key: _relative_to_v2(value) for key, value in paths.items() if key != "root"},
        }

    _check_safe_to_write(output_files, overwrite=overwrite)
    paths["root"].mkdir(parents=True, exist_ok=True)

    feature_names = _feature_names()
    features = runtime.build_features(drop_warmup_rows=False)
    events = runtime.generate_candidate_events(features)
    model_rows, model_row_manifest = runtime.build_model_rows(features=features, events=events)

    feature_export = _feature_export_frame(features, feature_names)
    feature_export.to_csv(paths["feature_matrix"], index=False)
    events.to_csv(paths["candidate_events"], index=False)
    model_rows.to_csv(paths["model_rows"], index=False)
    _write_json(paths["model_row_manifest"], model_row_manifest)

    artifact_hashes = hash_artifacts(output_files[:-1], root=_V2_ROOT)
    export_manifest = {
        "edge_id": EDGE_ID,
        "export_name": EXPORT_NAME,
        "status": "research_dataset_exported_not_deployable",
        "runtime_contract_status": runtime.load_contract()["runtime_status"],
        "feature_count": int(len(feature_names)),
        "feature_names": feature_names,
        "rows_feature_matrix": int(len(feature_export)),
        "rows_candidate_events": int(len(events)),
        "rows_model_rows": int(len(model_rows)),
        "outputs": {
            "feature_matrix": _relative_to_v2(paths["feature_matrix"]),
            "candidate_events": _relative_to_v2(paths["candidate_events"]),
            "model_rows": _relative_to_v2(paths["model_rows"]),
            "model_row_manifest": _relative_to_v2(paths["model_row_manifest"]),
            "export_manifest": _relative_to_v2(paths["export_manifest"]),
        },
        "artifact_hashes": artifact_hashes,
        "colab_usage": {
            "upload_to_colab": [
                _relative_to_v2(paths["model_rows"]),
                _relative_to_v2(paths["model_row_manifest"]),
                "assets/NASDAQ/edges/trend_long/contracts/feature_schema.json",
                "assets/NASDAQ/edges/trend_long/contracts/label_schema.json"
            ],
            "colab_may_train_models": True,
            "colab_may_engineer_new_features": False,
            "colab_outputs_to_copy_back": [
                "selected_features.json",
                "model.pkl",
                "calibrator.pkl",
                "threshold_sweep.csv",
                "training_manifest.json"
            ]
        },
        "blueprint_boundaries": [
            "Features were generated by runtime.py::build_features, not Colab or dashboard.",
            "Candidate events were generated by runtime.py::generate_candidate_events.",
            "Labels/model rows were generated by runtime.py::build_model_rows and are research-only.",
            "Live score() remains fail-closed until model/calibrator/threshold/deployability audit pass."
        ],
        "elapsed_seconds": round(time.time() - started, 2),
    }
    _write_json(paths["export_manifest"], export_manifest)

    return {
        "status": "PASS",
        "edge_id": EDGE_ID,
        "feature_count": len(feature_names),
        "rows_feature_matrix": len(feature_export),
        "rows_candidate_events": len(events),
        "rows_model_rows": len(model_rows),
        "feature_matrix": _relative_to_v2(paths["feature_matrix"]),
        "candidate_events": _relative_to_v2(paths["candidate_events"]),
        "model_rows": _relative_to_v2(paths["model_rows"]),
        "export_manifest": _relative_to_v2(paths["export_manifest"]),
        "elapsed_seconds": round(time.time() - started, 2),
    }


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Export V2 research dataset for NASDAQ/trend_long.")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser


def _run(argv: list[str] | None = None) -> None:
    args = build_arg_parser().parse_args(argv)
    result = export_research_dataset(overwrite=args.overwrite, dry_run=args.dry_run)
    if result["status"] == "DRY_RUN_PASS":
        print("✅ NASDAQ/trend_long research dataset export dry-run passed.")
        print(f"Edge: {result['edge_id']}")
        for name, path in result["planned_outputs"].items():
            print(f"{name}: {path}")
        return

    print("✅ NASDAQ/trend_long research dataset exported.")
    print(f"Edge: {result['edge_id']}")
    print(f"Feature count: {result['feature_count']}")
    print(f"Feature matrix rows: {result['rows_feature_matrix']}")
    print(f"Candidate event rows: {result['rows_candidate_events']}")
    print(f"Model rows: {result['rows_model_rows']}")
    print(f"Feature matrix: {result['feature_matrix']}")
    print(f"Candidate events: {result['candidate_events']}")
    print(f"Model rows: {result['model_rows']}")
    print(f"Manifest: {result['export_manifest']}")
    print(f"Elapsed seconds: {result['elapsed_seconds']}")


if __name__ == "__main__":
    try:
        _run()
    except ResearchDatasetExportError as exc:
        raise SystemExit(f"❌ {exc}") from exc
