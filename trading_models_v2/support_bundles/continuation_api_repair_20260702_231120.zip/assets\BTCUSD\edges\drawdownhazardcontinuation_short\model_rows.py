"""Research model rows for BTCUSD/drawdownhazardcontinuation_short.

Selected grid-scan geometry: 1000 bars, 2R profit target and 1R stop.
The selected cell produced 5,538 rows, net/gross mean R of 0.10094,
a 0.0040 vertical-exit rate and a 40-bar median holding period. Same-bar
PT/SL ambiguity uses raw BTCUSD MID-tick first touch where available and
sl_first otherwise.
"""
from __future__ import annotations

import re
import sys
from functools import lru_cache
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd

_THIS_FILE = Path(__file__).resolve()
_EDGE_ROOT = _THIS_FILE.parent
_V2_ROOT = _THIS_FILE.parents[4]
_REPO_ROOT = _THIS_FILE.parents[5]
for _path in (_EDGE_ROOT, _V2_ROOT, _REPO_ROOT):
    _text = str(_path)
    if _text not in sys.path:
        sys.path.insert(0, _text)

from candidate_events import (  # noqa: E402
    MAX_RECOVERY_FRACTION,
    MIN_DRAWDOWN_SEVERITY_PERCENTILE,
    MIN_HAZARD_CELL_OBSERVATIONS,
    MIN_HAZARD_PROBABILITY,
)
from primary_side import PRIMARY_SIDE_RULE  # noqa: E402
from shared.assets.asset_layout import get_asset_layout  # noqa: E402

EDGE_ID = "BTCUSD/drawdownhazardcontinuation_short"
ASSET = "BTCUSD"
SIDE_VALUE = -1
VERTICAL_HORIZON = 1000
PT_MULTIPLIER = 2.0
SL_MULTIPLIER = 1.0
FALLBACK_TIE_POLICY = "sl_first"
TICK_RESOLUTION_PRICE = "mid"
ROW_BUILDER = "drawdownhazardcontinuation_short_v2_2r_1000_triple_barrier_model_rows"
GEOMETRY_STATUS = "selected_from_grid_scan"
GEOMETRY_SELECTION_SOURCE = "label_geometry_grid_scan"
GRID_SCAN_SELECTED_RANK = 1
GRID_SCAN_SELECTED_ROWS = 5538
GRID_SCAN_SELECTED_NET_MEAN_R = 0.10094
GRID_SCAN_SELECTED_GROSS_MEAN_R = 0.10094
GRID_SCAN_SELECTED_VERTICAL_RATE = 0.0040
GRID_SCAN_SELECTED_MEDIAN_HOLD_BARS = 40.0
EPS = 1e-12


class ModelRowsError(RuntimeError):
    pass


def _normalize_datetime(df: pd.DataFrame, column: str) -> pd.DataFrame:
    out = df.copy()
    out[column] = pd.to_datetime(out[column], utc=True, errors="coerce")
    return out.dropna(subset=[column]).copy()


def _parse_tick_range(name: str) -> tuple[pd.Timestamp, pd.Timestamp] | None:
    match = re.search(r"(\d{4}-\d{2}-\d{2})_to_(\d{4}-\d{2}-\d{2})", name)
    if not match:
        return None
    return pd.Timestamp(match.group(1), tz="UTC"), pd.Timestamp(match.group(2), tz="UTC")


def build_tick_file_catalog(asset: str = ASSET) -> list[dict[str, Any]]:
    folder = get_asset_layout(asset).tick_root
    if not folder.exists():
        raise ModelRowsError(f"Tick data folder not found: {folder}")
    broad_start = pd.Timestamp("1900-01-01", tz="UTC")
    broad_end = pd.Timestamp("2100-01-01", tz="UTC")
    catalog: list[dict[str, Any]] = []
    for path in sorted(folder.glob("*.csv")):
        start, end = _parse_tick_range(path.name) or (broad_start, broad_end)
        catalog.append({"path": path, "start": start, "end": end})
    if not catalog:
        raise ModelRowsError(f"No raw tick CSV files found under: {folder}")
    return catalog


def _find_column(columns: list[str], candidates: list[str]) -> str | None:
    lowered = {column.strip().lower(): column for column in columns}
    for candidate in candidates:
        if candidate in lowered:
            return lowered[candidate]
    return None


@lru_cache(maxsize=256)
def _load_tick_file(path_text: str) -> pd.DataFrame:
    path = Path(path_text)
    raw = pd.read_csv(path)
    timestamp = _find_column(list(raw.columns), ["timestamp", "time", "datetime", "date_time"])
    bid = _find_column(list(raw.columns), ["bidprice", "bid_price", "bid"])
    ask = _find_column(list(raw.columns), ["askprice", "ask_price", "ask"])
    if timestamp is None or bid is None or ask is None:
        raise ModelRowsError(f"Tick file {path.name} lacks timestamp/bid/ask columns")
    out = pd.DataFrame({
        "timestamp": pd.to_datetime(raw[timestamp], utc=True, errors="coerce"),
        "bid": pd.to_numeric(raw[bid], errors="coerce"),
        "ask": pd.to_numeric(raw[ask], errors="coerce"),
    }).dropna()
    out = out[(out["bid"] > 0) & (out["ask"] > 0)].copy()
    out["mid"] = (out["bid"] + out["ask"]) / 2.0
    return out.sort_values("timestamp").reset_index(drop=True)


def _ticks_for_interval(
    catalog: list[dict[str, Any]], start: pd.Timestamp, end: pd.Timestamp,
) -> pd.DataFrame:
    start_day = pd.Timestamp(start.date(), tz="UTC")
    end_day = pd.Timestamp(end.date(), tz="UTC")
    chunks: list[pd.DataFrame] = []
    for item in catalog:
        if item["end"] < start_day or item["start"] > end_day:
            continue
        ticks = _load_tick_file(str(item["path"]))
        mask = ticks["timestamp"].between(start, end)
        if mask.any():
            chunks.append(ticks.loc[mask, ["timestamp", "mid"]])
    if not chunks:
        return pd.DataFrame(columns=["timestamp", "mid"])
    return pd.concat(chunks, ignore_index=True).sort_values("timestamp")


def _fallback_tie() -> tuple[float, str | None]:
    if FALLBACK_TIE_POLICY == "sl_first":
        return 0.0, "sl"
    if FALLBACK_TIE_POLICY == "pt_first":
        return 1.0, "pt"
    if FALLBACK_TIE_POLICY == "drop":
        return np.nan, None
    raise ModelRowsError(f"Unknown tie policy: {FALLBACK_TIE_POLICY}")


def _resolve_tick_first_touch(
    catalog: list[dict[str, Any]], start: pd.Timestamp, end: pd.Timestamp,
    pt_price: float, sl_price: float,
) -> tuple[float, str | None, str]:
    ticks = _ticks_for_interval(catalog, start, end)
    if ticks.empty:
        label, hit = _fallback_tie()
        return label, hit, "fallback_no_ticks"
    for price in ticks["mid"].to_numpy(dtype="float64"):
        if price <= pt_price:
            return 1.0, "pt", "tick"
        if price >= sl_price:
            return 0.0, "sl", "tick"
    label, hit = _fallback_tie()
    return label, hit, "fallback_unresolved"


def _validate_events(events: pd.DataFrame) -> None:
    required = [
        "side", "Event_Vol", "Drawdown_Hazard_Event",
        "Drawdown_Hazard_Active_State", "Drawdown_Hazard_State_Entry",
        "Drawdown_Hazard_Renewed_Impulse", "Negative_Event_Bar",
        "Drawdown_Active", "Log_Return_1",
        "Drawdown_Severity_Percentile_100_Over_1000", "Recovery_Fraction",
        "Drawdown_Hazard_Probability", "Drawdown_Hazard_Cell_Count",
    ]
    missing = [column for column in required if column not in events.columns]
    if missing:
        raise ModelRowsError(f"Events missing drawdown-hazard fields: {missing}")
    if events.empty:
        raise ModelRowsError("drawdownhazardcontinuation_short events are empty")
    if "edge_id" in events.columns and not events["edge_id"].eq(EDGE_ID).all():
        raise ModelRowsError("Events contain wrong edge_id")
    if not pd.to_numeric(events["side"], errors="coerce").eq(SIDE_VALUE).all():
        raise ModelRowsError("Events must have side=-1")
    for column in [
        "Drawdown_Hazard_Event", "Drawdown_Hazard_Active_State",
        "Negative_Event_Bar", "Drawdown_Active",
    ]:
        if not pd.to_numeric(events[column], errors="coerce").eq(1).all():
            raise ModelRowsError(f"Events must satisfy {column}=1")
    entry = pd.to_numeric(events["Drawdown_Hazard_State_Entry"], errors="coerce")
    renewed = pd.to_numeric(events["Drawdown_Hazard_Renewed_Impulse"], errors="coerce")
    if not entry.isin([0, 1]).all() or not renewed.isin([0, 1]).all():
        raise ModelRowsError("Drawdown hazard event-type flags must be binary")
    if not (entry + renewed).eq(1).all():
        raise ModelRowsError("Each event must be exactly one of state entry or renewed impulse")
    checks = [
        ("Log_Return_1", lambda x: x < 0, "negative return"),
        ("Drawdown_Severity_Percentile_100_Over_1000", lambda x: x >= MIN_DRAWDOWN_SEVERITY_PERCENTILE, "severity percentile"),
        ("Recovery_Fraction", lambda x: x <= MAX_RECOVERY_FRACTION, "recovery fraction"),
        ("Drawdown_Hazard_Probability", lambda x: x >= MIN_HAZARD_PROBABILITY, "hazard probability"),
        ("Drawdown_Hazard_Cell_Count", lambda x: x >= MIN_HAZARD_CELL_OBSERVATIONS, "hazard sample count"),
        ("Event_Vol", lambda x: x > 0, "Event_Vol"),
    ]
    for column, predicate, description in checks:
        values = pd.to_numeric(events[column], errors="coerce")
        if values.isna().any() or not predicate(values).all():
            raise ModelRowsError(f"Events violate {description} contract")


def _barriers(entry: float, target: float) -> tuple[float, float]:
    return (
        entry * (1.0 - PT_MULTIPLIER * target),
        entry * (1.0 + SL_MULTIPLIER * target),
    )


def apply_triple_barrier_labels(
    bars: pd.DataFrame,
    events: pd.DataFrame,
    *,
    tick_catalog: list[dict[str, Any]] | None = None,
    vertical_horizon: int = VERTICAL_HORIZON,
) -> tuple[pd.DataFrame, dict[str, int]]:
    if vertical_horizon <= 0:
        raise ModelRowsError("vertical_horizon must be positive")
    _validate_events(events)
    required_bars = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close"]
    missing = [column for column in required_bars if column not in bars.columns]
    if missing:
        raise ModelRowsError(f"Bars missing required columns: {missing}")
    full = _normalize_datetime(bars, "Datetime")
    full["Bar_Start"] = pd.to_datetime(full["Bar_Start"], utc=True, errors="coerce")
    for column in ["Open", "High", "Low", "Close"]:
        full[column] = pd.to_numeric(full[column], errors="coerce")
    full = full.dropna(subset=required_bars).sort_values("Datetime").drop_duplicates("Datetime").set_index("Datetime")
    event_frame = _normalize_datetime(events, "Datetime").sort_values("Datetime").drop_duplicates("Datetime").set_index("Datetime")
    catalog = build_tick_file_catalog() if tick_catalog is None else tick_catalog
    index = full.index
    rows: list[dict[str, Any]] = []
    stats = {
        "events_seen": 0, "events_labeled": 0,
        "events_dropped_missing_timestamp": 0, "events_dropped_horizon": 0,
        "events_dropped_invalid_target": 0, "ambiguous_same_bar_count": 0,
        "tick_resolved_count": 0, "fallback_resolved_count": 0,
    }
    for event_time, event in event_frame.iterrows():
        stats["events_seen"] += 1
        if event_time not in full.index:
            stats["events_dropped_missing_timestamp"] += 1
            continue
        location = index.get_loc(event_time)
        if not isinstance(location, (int, np.integer)):
            stats["events_dropped_missing_timestamp"] += 1
            continue
        if location + vertical_horizon >= len(full):
            stats["events_dropped_horizon"] += 1
            continue
        target = float(event["Event_Vol"])
        entry_price = float(full.at[event_time, "Close"])
        if not np.isfinite(target) or target <= 0 or not np.isfinite(entry_price):
            stats["events_dropped_invalid_target"] += 1
            continue
        pt_price, sl_price = _barriers(entry_price, target)
        future = index[location + 1: location + vertical_horizon + 1]
        label, t1, barrier_hit, source = 0.0, future[-1], "vertical", "vertical"
        for timestamp in future:
            pt_touch = float(full.at[timestamp, "Low"]) <= pt_price
            sl_touch = float(full.at[timestamp, "High"]) >= sl_price
            if pt_touch and sl_touch:
                stats["ambiguous_same_bar_count"] += 1
                label, barrier_hit, source = _resolve_tick_first_touch(
                    catalog,
                    pd.Timestamp(full.at[timestamp, "Bar_Start"]),
                    pd.Timestamp(timestamp),
                    pt_price,
                    sl_price,
                )
                stats["tick_resolved_count" if source == "tick" else "fallback_resolved_count"] += 1
                t1 = timestamp
                break
            if pt_touch:
                label, barrier_hit, source, t1 = 1.0, "pt", "ohlc", timestamp
                break
            if sl_touch:
                label, barrier_hit, source, t1 = 0.0, "sl", "ohlc", timestamp
                break
        if pd.isna(label):
            continue
        if barrier_hit == "pt":
            realized_r = PT_MULTIPLIER / SL_MULTIPLIER
        elif barrier_hit == "sl":
            realized_r = -1.0
        else:
            exit_close = float(full.at[t1, "Close"])
            realized_r = SIDE_VALUE * ((exit_close / entry_price) - 1.0) / (
                SL_MULTIPLIER * target + EPS
            )
        record = event.to_dict()
        record.update({
            "Datetime": event_time,
            "meta_label": int(label),
            "t1": t1,
            "barrier_hit": barrier_hit,
            "resolution_source": source,
            "entry_price": entry_price,
            "pt_price": pt_price,
            "sl_price": sl_price,
            "realized_r": realized_r,
        })
        rows.append(record)
        stats["events_labeled"] += 1
    labeled = pd.DataFrame(rows)
    if labeled.empty:
        raise ModelRowsError("Triple-barrier labeling produced zero rows")
    labeled["Datetime"] = pd.to_datetime(labeled["Datetime"], utc=True)
    labeled["t1"] = pd.to_datetime(labeled["t1"], utc=True)
    labeled["side"] = SIDE_VALUE
    if not labeled["pt_price"].lt(labeled["entry_price"]).all():
        raise ModelRowsError("Short PT must be below entry")
    if not labeled["sl_price"].gt(labeled["entry_price"]).all():
        raise ModelRowsError("Short SL must be above entry")
    return labeled.sort_values("Datetime").reset_index(drop=True), stats


def build_event_model_rows(
    *,
    features: pd.DataFrame,
    events: pd.DataFrame,
    bars: pd.DataFrame,
    feature_names: list[str],
    vertical_horizon: int = VERTICAL_HORIZON,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    labeled, stats = apply_triple_barrier_labels(
        bars, events, vertical_horizon=vertical_horizon
    )
    feature_frame = _normalize_datetime(features, "Datetime")
    missing = [name for name in feature_names if name not in feature_frame.columns]
    if missing:
        raise ModelRowsError(f"Feature table missing schema features: {missing}")
    feature_columns = list(dict.fromkeys([
        column for column in [
            "Datetime", "Bar_Start", "Open", "High", "Low", "Close",
            "edge_id", *feature_names,
        ] if column in feature_frame.columns
    ]))
    context_columns = [
        "Datetime", "side", "Event_Vol", "meta_label", "t1", "barrier_hit",
        "resolution_source", "entry_price", "pt_price", "sl_price", "realized_r",
        "event_id", "candidate_event_generator", "Drawdown_Hazard_Event",
        "Drawdown_Hazard_Active_State", "Drawdown_Hazard_State_Entry",
        "Drawdown_Hazard_Renewed_Impulse", "Negative_Event_Bar",
        "Drawdown_Active", "Drawdown_Depth_50", "Drawdown_Depth_100",
        "Drawdown_Depth_250", "Drawdown_Severity_100",
        "Drawdown_Severity_Percentile_100_Over_1000", "Bars_Since_Peak_100",
        "Time_Under_Water_100", "Drawdown_Trough", "Bars_Since_Trough",
        "Distance_From_Trough_ATR", "Recovery_Fraction",
        "Maximum_Recovery_Fraction", "Drawdown_Velocity_3",
        "Drawdown_Velocity_5", "Drawdown_Velocity_10",
        "Drawdown_Acceleration_3_10", "New_Trough_Bar",
        "New_Trough_Count_20", "New_Trough_Count_Since_Peak",
        "Trough_Renewal_Rate", "Failed_Recovery_Count",
        "Bars_Since_Last_Failed_Recovery", "Negative_Return_Fraction_20",
        "Negative_Return_Fraction_Since_Peak", "Cumulative_Return_Since_Peak",
        "Cumulative_Negative_Return_20", "Downside_Semivariance_20",
        "Downside_Upmove_Ratio_20", "Drawdown_Hazard_Probability",
        "Drawdown_Hazard_Cell_Count", "Drawdown_Hazard_Backoff_Level",
        "Drawdown_Hazard_Resolution_Lag", "Drawdown_Hazard_Global_Count",
        "primary_peak_window", "severity_baseline_window",
        "hazard_resolution_max_bars", "hazard_observation_gap_bars",
        "new_trough_buffer_vol", "recovery_success_fraction",
        "min_drawdown_severity_percentile", "max_recovery_fraction",
        "min_hazard_probability", "min_hazard_cell_observations",
        "min_gap_bars", "primary_side", "primary_side_filter",
        "primary_side_rule",
    ]
    context_columns = [column for column in context_columns if column in labeled.columns]
    overlap = sorted((set(feature_columns) & set(context_columns)) - {"Datetime"})
    if overlap:
        raise ModelRowsError(
            f"Feature/event merge would create suffixed duplicate columns: {overlap}"
        )
    modeling = feature_frame[feature_columns].merge(
        labeled[context_columns], on="Datetime", how="inner", validate="one_to_one"
    )
    before_required = len(modeling)
    modeling["t1"] = pd.to_datetime(modeling["t1"], utc=True, errors="coerce")
    modeling = modeling.dropna(subset=["side", "Event_Vol", "meta_label", "t1"])
    after_required = len(modeling)
    before_features = len(modeling)
    modeling = modeling.dropna(subset=feature_names).copy()
    if modeling.empty:
        raise ModelRowsError("All model rows were dropped after feature filtering")
    modeling["side"] = modeling["side"].astype("int64")
    modeling["meta_label"] = modeling["meta_label"].astype("int64")
    modeling = modeling.sort_values("Datetime").reset_index(drop=True)
    manifest = {
        "edge_id": EDGE_ID,
        "side_value": SIDE_VALUE,
        "primary_side_rule": PRIMARY_SIDE_RULE,
        "row_builder": ROW_BUILDER,
        "geometry_status": GEOMETRY_STATUS,
        "geometry_selection_source": GEOMETRY_SELECTION_SOURCE,
        "grid_scan_selected_rank": GRID_SCAN_SELECTED_RANK,
        "grid_scan_selected_rows": GRID_SCAN_SELECTED_ROWS,
        "grid_scan_selected_net_mean_R": GRID_SCAN_SELECTED_NET_MEAN_R,
        "grid_scan_selected_gross_mean_R": GRID_SCAN_SELECTED_GROSS_MEAN_R,
        "grid_scan_selected_vertical_rate": GRID_SCAN_SELECTED_VERTICAL_RATE,
        "grid_scan_selected_median_hold_bars": GRID_SCAN_SELECTED_MEDIAN_HOLD_BARS,
        "rows_candidate_events_input": int(len(events)),
        "rows_labeled_events": int(len(labeled)),
        "rows_after_required_filter": int(after_required),
        "rows_after_feature_nan_filter": int(len(modeling)),
        "required_rows_dropped": int(before_required - after_required),
        "feature_nan_rows_dropped": int(before_features - len(modeling)),
        "feature_count": int(len(feature_names)),
        "vertical_horizon": int(vertical_horizon),
        "pt_multiplier": PT_MULTIPLIER,
        "sl_multiplier": SL_MULTIPLIER,
        "reward_risk_ratio": PT_MULTIPLIER / SL_MULTIPLIER,
        "fallback_tie_policy": FALLBACK_TIE_POLICY,
        "tick_resolution_price": TICK_RESOLUTION_PRICE,
        "short_barrier_contract": "pt_price_below_entry_sl_price_above_entry",
        "labeling_stats": stats,
        "meta_label_distribution": {
            str(key): float(value)
            for key, value in modeling["meta_label"].value_counts(normalize=True).sort_index().items()
        },
        "uses_future_information_for_labels": True,
        "live_scoring_must_not_use_label_columns": True,
    }
    return modeling, manifest


def model_row_config() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "side_value": SIDE_VALUE,
        "primary_side_rule": PRIMARY_SIDE_RULE,
        "row_builder": ROW_BUILDER,
        "vertical_horizon": VERTICAL_HORIZON,
        "pt_multiplier": PT_MULTIPLIER,
        "sl_multiplier": SL_MULTIPLIER,
        "reward_risk_ratio": PT_MULTIPLIER / SL_MULTIPLIER,
        "geometry_status": GEOMETRY_STATUS,
        "geometry_selection_source": GEOMETRY_SELECTION_SOURCE,
        "grid_scan_selected_rank": GRID_SCAN_SELECTED_RANK,
        "grid_scan_selected_rows": GRID_SCAN_SELECTED_ROWS,
        "grid_scan_selected_net_mean_R": GRID_SCAN_SELECTED_NET_MEAN_R,
        "grid_scan_selected_gross_mean_R": GRID_SCAN_SELECTED_GROSS_MEAN_R,
        "grid_scan_selected_vertical_rate": GRID_SCAN_SELECTED_VERTICAL_RATE,
        "grid_scan_selected_median_hold_bars": GRID_SCAN_SELECTED_MEDIAN_HOLD_BARS,
        "fallback_tie_policy": FALLBACK_TIE_POLICY,
        "tick_resolution_price": TICK_RESOLUTION_PRICE,
        "short_barrier_contract": "pt_price_below_entry_sl_price_above_entry",
        "uses_future_information_for_labels": True,
        "live_scoring_must_not_use_label_columns": True,
    }


if __name__ == "__main__":
    print("✅ BTCUSD/drawdownhazardcontinuation_short model_rows.py import check passed")
    print(model_row_config())
