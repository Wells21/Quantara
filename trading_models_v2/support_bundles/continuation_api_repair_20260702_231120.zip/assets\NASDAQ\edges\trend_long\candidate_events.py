"""
Candidate event generation for NASDAQ/trend_long.

This module ports the useful V1 Step 4 trend event sampler into the V2 edge
package boundary.

V1 reference idea:
- Use past-only event volatility from log(Close[t] / Close[t-50]).
- Run symmetric CUSUM over 1-bar log close differences.
- Use h[t] = 0.3 * Event_Vol[t].

V2 side-specialization:
- trend_long emits positive CUSUM triggers only.
- side is fixed to +1.
- negative CUSUM triggers reset negative state but are not emitted here.
- no labels, t1, barrier outcomes, probabilities, or AFML sizing are created.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

EDGE_ID = "NASDAQ/trend_long"
SIDE_VALUE = 1
EPS = 1e-12
CUSUM_K = 0.3
EVENT_VOL_LOOKBACK_BARS = 50
EVENT_VOL_EWM_SPAN = 100
MIN_EVENT_VOL = 1e-8
CANDIDATE_EVENT_GENERATOR = "trend_long_v1_positive_cusum_candidate_events"


class CandidateEventError(RuntimeError):
    """Raised when candidate event generation must fail closed."""


def _required_event_columns() -> list[str]:
    return [
        "Datetime",
        "Bar_Start",
        "edge_id",
        "side",
        "Event_Vol",
        "event_id",
        "candidate_event_generator",
        "cusum_direction",
        "event_known_after_close",
        "uses_future_information",
    ]


def _validate_candidate_events(events: pd.DataFrame) -> None:
    missing = [col for col in _required_event_columns() if col not in events.columns]
    if missing:
        raise CandidateEventError(f"Candidate events missing required columns: {missing}")
    if events.empty:
        raise CandidateEventError("Candidate event generator produced zero events.")
    if not (events["side"] == SIDE_VALUE).all():
        raise CandidateEventError("trend_long candidate events must have side=+1 only.")
    if not (events["edge_id"] == EDGE_ID).all():
        raise CandidateEventError("Candidate events contain unexpected edge_id values.")
    if not (events["candidate_event_generator"] == CANDIDATE_EVENT_GENERATOR).all():
        raise CandidateEventError("Candidate events contain unexpected generator values.")
    if not (events["cusum_direction"] == "positive").all():
        raise CandidateEventError("trend_long emits positive CUSUM triggers only.")
    if events["uses_future_information"].astype(bool).any():
        raise CandidateEventError("Candidate events must not use future information.")


def generate_v1_positive_cusum_candidate_events(
    features: pd.DataFrame,
    *,
    cusum_k: float = CUSUM_K,
    vol_lookback_bars: int = EVENT_VOL_LOOKBACK_BARS,
    vol_ewm_span: int = EVENT_VOL_EWM_SPAN,
    min_event_vol: float = MIN_EVENT_VOL,
) -> pd.DataFrame:
    """Generate V1 Step 4 positive CUSUM candidate events.

    The input must be the edge runtime feature table or any equivalent closed-bar
    table with Datetime, Bar_Start, and Close. No future labels are used.
    """

    if cusum_k <= 0:
        raise CandidateEventError("cusum_k must be > 0")
    if vol_lookback_bars <= 0:
        raise CandidateEventError("vol_lookback_bars must be > 0")
    if vol_ewm_span <= 0:
        raise CandidateEventError("vol_ewm_span must be > 0")
    if min_event_vol <= 0:
        raise CandidateEventError("min_event_vol must be > 0")

    required = ["Datetime", "Bar_Start", "Close"]
    missing = [col for col in required if col not in features.columns]
    if missing:
        raise CandidateEventError(f"Input features missing required columns: {missing}")

    df = features.copy()
    df["Datetime"] = pd.to_datetime(df["Datetime"], utc=True, errors="coerce")
    df["Bar_Start"] = pd.to_datetime(df["Bar_Start"], utc=True, errors="coerce")
    df["Close"] = pd.to_numeric(df["Close"], errors="coerce")
    df = df.dropna(subset=["Datetime", "Bar_Start", "Close"]).copy()
    df = df.sort_values("Datetime").reset_index(drop=True)

    close = df["Close"].astype("float64")
    log_close = np.log(close + EPS)
    log_ret_1 = log_close.diff()
    long_horizon_return = np.log((close + EPS) / (close.shift(vol_lookback_bars) + EPS))
    event_vol = long_horizon_return.ewm(span=vol_ewm_span, adjust=False).std().clip(lower=min_event_vol)

    rows: list[dict[str, Any]] = []
    s_pos = 0.0
    s_neg = 0.0

    for i in range(1, len(df)):
        diff = log_ret_1.iat[i]
        vol = event_vol.iat[i]
        if not np.isfinite(diff) or not np.isfinite(vol):
            continue

        threshold = float(cusum_k * vol)
        if threshold <= 0 or not np.isfinite(threshold):
            continue

        s_pos = max(0.0, s_pos + float(diff))
        s_neg = min(0.0, s_neg + float(diff))

        if s_pos > threshold:
            event_time = pd.Timestamp(df.at[i, "Datetime"])
            rows.append(
                {
                    "Datetime": event_time,
                    "Bar_Start": df.at[i, "Bar_Start"],
                    "edge_id": EDGE_ID,
                    "side": SIDE_VALUE,
                    "Event_Vol": float(vol),
                    "event_id": f"{EDGE_ID}|{event_time.isoformat()}|positive_cusum",
                    "candidate_event_generator": CANDIDATE_EVENT_GENERATOR,
                    "cusum_direction": "positive",
                    "event_known_after_close": True,
                    "uses_future_information": False,
                    "cusum_k": float(cusum_k),
                    "cusum_threshold": threshold,
                    "bar_index": int(i),
                    "Close": float(close.iat[i]),
                }
            )
            s_pos = 0.0

        if s_neg < -threshold:
            s_neg = 0.0

    events = pd.DataFrame(rows)
    if not events.empty:
        events["Datetime"] = pd.to_datetime(events["Datetime"], utc=True)
        events["Bar_Start"] = pd.to_datetime(events["Bar_Start"], utc=True)
        events = events.sort_values("Datetime").reset_index(drop=True)

    _validate_candidate_events(events)
    return events
