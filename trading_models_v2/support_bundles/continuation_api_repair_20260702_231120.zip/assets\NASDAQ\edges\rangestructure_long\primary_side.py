"""
Primary-side logic for NASDAQ/rangestructure_long.

V1 source:
- NASDAQ/range-structure-independent-edge/5a_range_structure_primary_side_engine.py

Core V1 mapping:
- Range_Structure_Event_Type marks location only:
    -1 = near prior range low
    +1 = near prior range high
- Final side is assigned from past-only Structure_Bias_TStat:
    Structure_Bias_TStat > 0 -> side=+1 long
    Structure_Bias_TStat < 0 -> side=-1 short

V2 side-specialization:
- rangestructure_long keeps only Structure_Bias_TStat > 0 -> side=+1 long.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

_THIS_FILE = Path(__file__).resolve()
_EDGE_ROOT = _THIS_FILE.parent
_V2_ROOT = _THIS_FILE.parents[4]
_REPO_ROOT = _THIS_FILE.parents[5]
for _path in (_EDGE_ROOT, _V2_ROOT, _REPO_ROOT):
    path_str = str(_path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from shared.ffd.verify_asset_ffd_manifest import verify_asset_ffd_manifest  # noqa: E402

EDGE_ID = "NASDAQ/rangestructure_long"
ASSET = "NASDAQ"
SIDE_VALUE = 1
LIVE_BUFFER_BARS = 300
EPS = 1e-12

FORBIDDEN_PRIMARY_SIDE_COLUMNS = {
    "meta_label",
    "t1",
    "barrier_hit",
    "resolution_source",
    "entry_price",
    "pt_price",
    "sl_price",
    "realized_r",
    "raw_probability",
    "calibrated_probability",
    "afml_bet_size",
    "approved_signal",
}


class PrimarySideError(RuntimeError):
    """Raised when primary-side generation must fail closed."""


def load_verified_ffd_features(asset: str = ASSET) -> pd.DataFrame:
    """Load verified shared asset-level FFD features for runtime feature parity.

    This helper is intentionally generic and mirrors the V2 edge pattern used by
    other NASDAQ edges: feature_expansion.py may merge verified FFD columns, but
    it must never create independent/dashboard-only FFD features.
    """

    verification = verify_asset_ffd_manifest(asset)
    path = _V2_ROOT / verification["features"]
    if not path.exists():
        raise PrimarySideError(f"Verified FFD features path does not exist: {path}")

    ffd = pd.read_csv(path)
    required = ["Datetime", "Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]
    missing = [col for col in required if col not in ffd.columns]
    if missing:
        raise PrimarySideError(f"FFD features missing required columns: {missing}")

    ffd["Datetime"] = pd.to_datetime(ffd["Datetime"], utc=True, errors="coerce")
    for col in ["Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]:
        ffd[col] = pd.to_numeric(ffd[col], errors="coerce")
    ffd = ffd.dropna(subset=required).copy()
    ffd = ffd.sort_values("Datetime").reset_index(drop=True)
    if ffd.empty:
        raise PrimarySideError("Verified FFD features are empty after normalization.")
    return ffd


def _validate_primary_side_input(events: pd.DataFrame) -> pd.DataFrame:
    required = [
        "Datetime",
        "edge_id",
        "side",
        "Event_Vol",
        "Range_Structure_Event_Type",
        "Structure_Bias_TStat",
    ]
    missing = [col for col in required if col not in events.columns]
    if missing:
        raise PrimarySideError(f"Primary-side input missing required columns: {missing}")

    forbidden_present = sorted(FORBIDDEN_PRIMARY_SIDE_COLUMNS.intersection(events.columns))
    if forbidden_present:
        raise PrimarySideError(f"Primary-side input contains forbidden research/live-decision columns: {forbidden_present}")

    out = events.copy()
    out["Datetime"] = pd.to_datetime(out["Datetime"], utc=True, errors="coerce")
    if "Bar_Start" in out.columns:
        out["Bar_Start"] = pd.to_datetime(out["Bar_Start"], utc=True, errors="coerce")
    for col in ["side", "Event_Vol", "Range_Structure_Event_Type", "Structure_Bias_TStat"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=["Datetime", "side", "Event_Vol", "Range_Structure_Event_Type", "Structure_Bias_TStat"]).copy()
    if out.empty:
        raise PrimarySideError("Primary-side input is empty after normalization.")
    if not (out["edge_id"] == EDGE_ID).all():
        bad = out.loc[out["edge_id"] != EDGE_ID, "edge_id"].unique().tolist()
        raise PrimarySideError(f"rangestructure_long primary side received wrong edge_id values: {bad}")
    if not out["Range_Structure_Event_Type"].isin([-1, 1]).all():
        bad = out.loc[~out["Range_Structure_Event_Type"].isin([-1, 1]), "Range_Structure_Event_Type"].unique().tolist()
        raise PrimarySideError(f"Range_Structure_Event_Type must be location -1/+1 only: {bad}")
    return out.sort_values("Datetime").reset_index(drop=True)


def assign_rangestructure_long_primary_side(events: pd.DataFrame) -> pd.DataFrame:
    out = _validate_primary_side_input(events)
    out["raw_side_from_structure_bias"] = np.sign(out["Structure_Bias_TStat"]).astype("int64")
    out["primary_side_rule"] = "Structure_Bias_TStat > 0 -> side=+1 long"
    out["primary_side"] = np.where(out["Structure_Bias_TStat"] > 0, SIDE_VALUE, 0).astype("int64")
    out["primary_side_filter"] = (out["primary_side"] == SIDE_VALUE).astype("int64")
    out = out[out["primary_side_filter"] == 1].copy()

    if out.empty:
        raise PrimarySideError("No rangestructure_long events survived Structure_Bias_TStat > 0 primary-side mapping.")
    if not (pd.to_numeric(out["Structure_Bias_TStat"], errors="coerce") > 0).all():
        raise PrimarySideError("rangestructure_long primary side must only accept Structure_Bias_TStat > 0.")
    if not (out["primary_side"] == SIDE_VALUE).all():
        raise PrimarySideError("rangestructure_long primary_side must be +1 only.")

    out["side"] = SIDE_VALUE
    return out.sort_values("Datetime").reset_index(drop=True)


def filter_long_events_with_primary_side(events: pd.DataFrame, features: pd.DataFrame | None = None) -> pd.DataFrame:
    return assign_rangestructure_long_primary_side(events)


def validate_primary_side_events(events: pd.DataFrame) -> None:
    out = assign_rangestructure_long_primary_side(events)
    if out.empty:
        raise PrimarySideError("Validated rangestructure_long primary-side output is empty.")


def primary_side_config() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "side_value": SIDE_VALUE,
        "side_rule": "Structure_Bias_TStat > 0 -> side=+1 long",
        "range_structure_event_type_meaning": "-1 near prior range low, +1 near prior range high; location only, not final direction",
        "event_specific_fields_are_model_inputs": False,
        "uses_verified_shared_ffd": True,
        "live_buffer_bars": LIVE_BUFFER_BARS,
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
        "v1_reference": "NASDAQ/range-structure-independent-edge/5a_range_structure_primary_side_engine.py",
    }


if __name__ == "__main__":
    print("✅ NASDAQ/rangestructure_long primary_side.py import/self-contract check passed.")
    print(primary_side_config())
