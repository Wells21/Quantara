"""
Candidate event generation for NASDAQ/absorption_long.

This module ports V1 Step 4 absorption event sampling into the V2 edge package
boundary.

V1 reference idea:
- Price-only absorption / failed displacement events.
- Event_Type +1 = upside displacement failed -> short candidate in V1 5A.
- Event_Type -1 = downside displacement failed -> long candidate in V1 5A.
- Clean liquidity sweeps are excluded by default to reduce overlap with a
  separate liquidity/sweep edge.

V2 side-specialization:
- absorption_long emits downside failed-displacement events only.
- side is fixed to +1.
- Absorption_Event_Type is fixed to -1 in emitted events.
- The opposite event type may be computed internally only to preserve V1
  MIN_GAP_BARS spacing behavior across all absorption events.
- no labels, t1, barrier outcomes, probabilities, AFML sizing, or execution
  decisions are created here.

Blueprint boundary:
- All calculations use current/previous closed-bar data only.
- The same absorption feature function can be called later by runtime.py so
  any selected absorption-specific model feature is live reproducible.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

EDGE_ID = "NASDAQ/absorption_long"
SIDE_VALUE = 1
ABSORPTION_EVENT_TYPE = -1
CANDIDATE_EVENT_GENERATOR = "absorption_long_v1_downside_failed_displacement_candidate_events"

MIN_GAP_BARS = 2
WICK_SHARE_THRESHOLD = 0.50
CLOSE_FAIL_THRESHOLD = 0.50
MIN_RANGE_ATR = 0.60
MAX_BODY_SHARE = 0.40
MIN_WICK_ATR = 0.30
EXCLUDE_LIQUIDITY_SWEEPS = True
LIQUIDITY_LOOKBACK = 10
LIQUIDITY_SWEEP_ATR_THRESHOLD = 0.10
EVENT_VOL_LOOKBACK = 50
EVENT_VOL_EWM_SPAN = 100
MIN_VOL = 1e-8
EPS = 1e-12

EVENT_CONTEXT_COLUMNS = [
    "Event_Vol",
    "Absorption_Event_Type",
    "Body_Direction",
    "Body_Size",
    "Body_Share",
    "Close_Location",
    "Upper_Wick",
    "Lower_Wick",
    "Upper_Wick_Share",
    "Lower_Wick_Share",
    "Wick_Imbalance",
    "Range_ATR",
    "Upper_Wick_ATR",
    "Lower_Wick_ATR",
    "Bull_Response_ATR",
    "Bear_Response_ATR",
    "Clean_Liquidity_High_Sweep",
    "Clean_Liquidity_Low_Sweep",
    "Sweep_High_ATR_Liq",
    "Sweep_Low_ATR_Liq",
]


class CandidateEventError(RuntimeError):
    """Raised when candidate event generation must fail closed."""


def _required_event_columns() -> list[str]:
    return [
        "Datetime",
        "Bar_Start",
        "edge_id",
        "side",
        "Event_Vol",
        "event_id",
        "candidate_event_generator",
        "Absorption_Event_Type",
        "event_known_after_close",
        "uses_future_information",
    ]


def _forbidden_event_columns() -> set[str]:
    return {
        "meta_label",
        "t1",
        "barrier_hit",
        "resolution_source",
        "entry_price",
        "pt_price",
        "sl_price",
        "realized_r",
        "raw_probability",
        "calibrated_probability",
        "afml_bet_size",
        "approved_signal",
    }


def _optional_context_columns(features: pd.DataFrame) -> list[str]:
    return [
        col
        for col in [
            "NATR",
            "Regime_State",
            "Regime_Entropy",
            "Regime_Duration",
            "Prob_State_0",
            "Prob_State_1",
            "Prob_State_2",
            "Prob_State_3",
        ]
        if col in features.columns
    ]


def _normalize_feature_input(features: pd.DataFrame) -> pd.DataFrame:
    required = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close", "ATR_14"]
    missing = [col for col in required if col not in features.columns]
    if missing:
        raise CandidateEventError(f"Input features missing required columns: {missing}")

    df = features.copy()
    df["Datetime"] = pd.to_datetime(df["Datetime"], utc=True, errors="coerce")
    df["Bar_Start"] = pd.to_datetime(df["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open",
        "High",
        "Low",
        "Close",
        "ATR_14",
        "NATR",
        "Regime_State",
        "Regime_Entropy",
        "Regime_Duration",
        "Prob_State_0",
        "Prob_State_1",
        "Prob_State_2",
        "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in df.columns]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=required).copy()
    df = df.sort_values("Datetime").reset_index(drop=True)
    if df.empty:
        raise CandidateEventError("Input features are empty after normalization.")
    return df


def add_v1_absorption_price_rejection_features(
    features: pd.DataFrame,
    *,
    liquidity_lookback: int = LIQUIDITY_LOOKBACK,
    liquidity_sweep_atr_threshold: float = LIQUIDITY_SWEEP_ATR_THRESHOLD,
    event_vol_lookback: int = EVENT_VOL_LOOKBACK,
    event_vol_ewm_span: int = EVENT_VOL_EWM_SPAN,
    min_vol: float = MIN_VOL,
) -> pd.DataFrame:
    """Add V1 Step 4 price-only absorption / failed-displacement features.

    This function is live-safe: it uses only the current closed bar and shifted
    rolling history. Runtime.py should call this same function so absorption
    model-input features are reproducible live.
    """

    if liquidity_lookback <= 0:
        raise CandidateEventError("liquidity_lookback must be > 0")
    if liquidity_sweep_atr_threshold < 0:
        raise CandidateEventError("liquidity_sweep_atr_threshold must be >= 0")
    if event_vol_lookback <= 0:
        raise CandidateEventError("event_vol_lookback must be > 0")
    if event_vol_ewm_span <= 0:
        raise CandidateEventError("event_vol_ewm_span must be > 0")
    if min_vol <= 0:
        raise CandidateEventError("min_vol must be > 0")

    out = _normalize_feature_input(features)

    open_ = out["Open"].astype("float64")
    high = out["High"].astype("float64")
    low = out["Low"].astype("float64")
    close = out["Close"].astype("float64")
    atr = out["ATR_14"].astype("float64")

    bar_range = (high - low).clip(lower=EPS)
    body = close - open_
    body_abs = body.abs()
    upper_wick = (high - pd.concat([open_, close], axis=1).max(axis=1)).clip(lower=0)
    lower_wick = (pd.concat([open_, close], axis=1).min(axis=1) - low).clip(lower=0)

    out["Body_Direction"] = np.sign(body)
    out["Body_Size"] = body_abs
    out["Body_Share"] = body_abs / (bar_range + EPS)
    out["Close_Location"] = (close - low) / (bar_range + EPS)
    out["Upper_Wick"] = upper_wick
    out["Lower_Wick"] = lower_wick
    out["Upper_Wick_Share"] = upper_wick / (bar_range + EPS)
    out["Lower_Wick_Share"] = lower_wick / (bar_range + EPS)
    out["Wick_Imbalance"] = (upper_wick - lower_wick) / (bar_range + EPS)
    out["Range_ATR"] = bar_range / (atr + EPS)
    out["Upper_Wick_ATR"] = upper_wick / (atr + EPS)
    out["Lower_Wick_ATR"] = lower_wick / (atr + EPS)
    out["Bull_Response_ATR"] = (close - open_) / (atr + EPS)
    out["Bear_Response_ATR"] = (open_ - close) / (atr + EPS)

    out["Prev_High_Liq"] = high.rolling(liquidity_lookback).max().shift(1)
    out["Prev_Low_Liq"] = low.rolling(liquidity_lookback).min().shift(1)
    out["Sweep_High_ATR_Liq"] = (high - out["Prev_High_Liq"]) / (atr + EPS)
    out["Sweep_Low_ATR_Liq"] = (out["Prev_Low_Liq"] - low) / (atr + EPS)
    out["Clean_Liquidity_High_Sweep"] = (
        (out["Sweep_High_ATR_Liq"] >= liquidity_sweep_atr_threshold)
        & (close < out["Prev_High_Liq"])
    ).astype("float64")
    out["Clean_Liquidity_Low_Sweep"] = (
        (out["Sweep_Low_ATR_Liq"] >= liquidity_sweep_atr_threshold)
        & (close > out["Prev_Low_Liq"])
    ).astype("float64")

    ret = np.log((close + EPS) / (close.shift(event_vol_lookback) + EPS))
    out["Event_Vol"] = ret.ewm(span=event_vol_ewm_span, adjust=False).std().clip(lower=min_vol)

    out.replace([np.inf, -np.inf], np.nan, inplace=True)
    return out


def mark_v1_absorption_event_types(
    features: pd.DataFrame,
    *,
    wick_share_threshold: float = WICK_SHARE_THRESHOLD,
    close_fail_threshold: float = CLOSE_FAIL_THRESHOLD,
    min_range_atr: float = MIN_RANGE_ATR,
    max_body_share: float = MAX_BODY_SHARE,
    min_wick_atr: float = MIN_WICK_ATR,
    exclude_liquidity_sweeps: bool = EXCLUDE_LIQUIDITY_SWEEPS,
) -> pd.DataFrame:
    """Mark V1 absorption event types without extracting events.

    +1 = upside displacement failed -> short candidate in V1.
    -1 = downside displacement failed -> long candidate in V1 / absorption_long.
    """

    out = features.copy()
    required = [
        "Upper_Wick_Share",
        "Lower_Wick_Share",
        "Upper_Wick_ATR",
        "Lower_Wick_ATR",
        "Close_Location",
        "Range_ATR",
        "Body_Share",
        "Clean_Liquidity_High_Sweep",
        "Clean_Liquidity_Low_Sweep",
    ]
    missing = [col for col in required if col not in out.columns]
    if missing:
        raise CandidateEventError(f"Absorption feature table missing required columns: {missing}")

    upside_absorption = (
        (out["Upper_Wick_Share"] >= wick_share_threshold)
        & (out["Upper_Wick_ATR"] >= min_wick_atr)
        & (out["Close_Location"] <= close_fail_threshold)
        & (out["Range_ATR"] >= min_range_atr)
        & (out["Body_Share"] <= max_body_share)
    )

    downside_absorption = (
        (out["Lower_Wick_Share"] >= wick_share_threshold)
        & (out["Lower_Wick_ATR"] >= min_wick_atr)
        & (out["Close_Location"] >= (1.0 - close_fail_threshold))
        & (out["Range_ATR"] >= min_range_atr)
        & (out["Body_Share"] <= max_body_share)
    )

    if exclude_liquidity_sweeps:
        upside_absorption = upside_absorption & (~out["Clean_Liquidity_High_Sweep"].astype(bool))
        downside_absorption = downside_absorption & (~out["Clean_Liquidity_Low_Sweep"].astype(bool))

    out["Absorption_Event_Type"] = 0
    out.loc[upside_absorption, "Absorption_Event_Type"] = 1
    out.loc[downside_absorption, "Absorption_Event_Type"] = -1
    return out


def _extract_v1_spaced_absorption_events(features: pd.DataFrame, *, min_gap_bars: int = MIN_GAP_BARS) -> pd.DataFrame:
    """Preserve V1 event spacing across all absorption event types."""

    if min_gap_bars < 0:
        raise CandidateEventError("min_gap_bars must be >= 0")
    if "Absorption_Event_Type" not in features.columns:
        raise CandidateEventError("Feature table missing Absorption_Event_Type")

    event_type = pd.to_numeric(features["Absorption_Event_Type"], errors="coerce").fillna(0).astype(int).to_numpy()
    selected_indices: list[int] = []
    last_i = -10**9

    for i, event in enumerate(event_type):
        if i - last_i < min_gap_bars:
            continue
        if event != 0:
            selected_indices.append(i)
            last_i = i

    if not selected_indices:
        return features.iloc[[]].copy()
    return features.iloc[selected_indices].copy().reset_index(drop=True)


def _validate_candidate_events(events: pd.DataFrame) -> None:
    missing = [col for col in _required_event_columns() if col not in events.columns]
    if missing:
        raise CandidateEventError(f"Candidate events missing required columns: {missing}")
    if events.empty:
        raise CandidateEventError("Candidate event generator produced zero absorption_long events.")

    forbidden_present = sorted(_forbidden_event_columns().intersection(events.columns))
    if forbidden_present:
        raise CandidateEventError(
            f"Candidate events contain forbidden research/live-decision columns: {forbidden_present}"
        )

    if not (events["edge_id"] == EDGE_ID).all():
        raise CandidateEventError("Candidate events contain unexpected edge_id values.")
    if not (events["side"] == SIDE_VALUE).all():
        raise CandidateEventError("absorption_long candidate events must have side=+1 only.")
    if not (events["candidate_event_generator"] == CANDIDATE_EVENT_GENERATOR).all():
        raise CandidateEventError("Candidate events contain unexpected generator values.")
    if not (events["Absorption_Event_Type"] == ABSORPTION_EVENT_TYPE).all():
        raise CandidateEventError("absorption_long emits Absorption_Event_Type=-1 only.")
    if events["uses_future_information"].astype(bool).any():
        raise CandidateEventError("Candidate events must not use future information.")
    if not events["event_known_after_close"].astype(bool).all():
        raise CandidateEventError("Candidate events must be known after bar close.")
    if not np.isfinite(events["Event_Vol"].to_numpy(dtype="float64")).all():
        raise CandidateEventError("Candidate events contain non-finite Event_Vol values.")


def generate_v1_absorption_long_candidate_events(
    features: pd.DataFrame,
    *,
    min_gap_bars: int = MIN_GAP_BARS,
    wick_share_threshold: float = WICK_SHARE_THRESHOLD,
    close_fail_threshold: float = CLOSE_FAIL_THRESHOLD,
    min_range_atr: float = MIN_RANGE_ATR,
    max_body_share: float = MAX_BODY_SHARE,
    min_wick_atr: float = MIN_WICK_ATR,
    exclude_liquidity_sweeps: bool = EXCLUDE_LIQUIDITY_SWEEPS,
) -> pd.DataFrame:
    """Generate V1 Step 4 downside failed-displacement candidate events for absorption_long."""

    expanded = add_v1_absorption_price_rejection_features(features)
    marked = mark_v1_absorption_event_types(
        expanded,
        wick_share_threshold=wick_share_threshold,
        close_fail_threshold=close_fail_threshold,
        min_range_atr=min_range_atr,
        max_body_share=max_body_share,
        min_wick_atr=min_wick_atr,
        exclude_liquidity_sweeps=exclude_liquidity_sweeps,
    )
    spaced = _extract_v1_spaced_absorption_events(marked, min_gap_bars=min_gap_bars)
    long_events = spaced[spaced["Absorption_Event_Type"] == ABSORPTION_EVENT_TYPE].copy()
    if long_events.empty:
        # Return a structurally valid empty frame for callers that want to inspect,
        # but validation below will fail when this is the primary runtime generator.
        long_events = pd.DataFrame(columns=["Datetime", "Bar_Start", *EVENT_CONTEXT_COLUMNS])

    optional_cols = _optional_context_columns(marked)
    keep_cols = [
        "Datetime",
        "Bar_Start",
        "Open",
        "High",
        "Low",
        "Close",
        *EVENT_CONTEXT_COLUMNS,
        *optional_cols,
    ]
    keep_cols = [col for col in keep_cols if col in long_events.columns]
    events = long_events[keep_cols].copy()

    events["edge_id"] = EDGE_ID
    events["side"] = SIDE_VALUE
    events["event_id"] = events["Datetime"].apply(
        lambda ts: f"{EDGE_ID}|{pd.Timestamp(ts).isoformat()}|downside_failed_displacement"
    )
    events["candidate_event_generator"] = CANDIDATE_EVENT_GENERATOR
    events["event_known_after_close"] = True
    events["uses_future_information"] = False
    events["min_gap_bars"] = int(min_gap_bars)
    events["wick_share_threshold"] = float(wick_share_threshold)
    events["close_fail_threshold"] = float(close_fail_threshold)
    events["min_range_atr"] = float(min_range_atr)
    events["max_body_share"] = float(max_body_share)
    events["min_wick_atr"] = float(min_wick_atr)
    events["exclude_liquidity_sweeps"] = bool(exclude_liquidity_sweeps)
    events["liquidity_lookback"] = int(LIQUIDITY_LOOKBACK)
    events["liquidity_sweep_atr_threshold"] = float(LIQUIDITY_SWEEP_ATR_THRESHOLD)

    events["Datetime"] = pd.to_datetime(events["Datetime"], utc=True, errors="coerce")
    events["Bar_Start"] = pd.to_datetime(events["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "side",
        "Event_Vol",
        "Absorption_Event_Type",
        "Body_Direction",
        "Body_Size",
        "Body_Share",
        "Close_Location",
        "Upper_Wick",
        "Lower_Wick",
        "Upper_Wick_Share",
        "Lower_Wick_Share",
        "Wick_Imbalance",
        "Range_ATR",
        "Upper_Wick_ATR",
        "Lower_Wick_ATR",
        "Bull_Response_ATR",
        "Bear_Response_ATR",
        "Clean_Liquidity_High_Sweep",
        "Clean_Liquidity_Low_Sweep",
        "Sweep_High_ATR_Liq",
        "Sweep_Low_ATR_Liq",
        *optional_cols,
    ]
    for col in [c for c in numeric_cols if c in events.columns]:
        events[col] = pd.to_numeric(events[col], errors="coerce")

    events = events.dropna(subset=["Datetime", "Bar_Start", "Event_Vol", "Absorption_Event_Type"]).copy()
    events = events.sort_values("Datetime").reset_index(drop=True)

    ordered_cols = [
        "Datetime",
        "Bar_Start",
        "edge_id",
        "side",
        "Event_Vol",
        "event_id",
        "candidate_event_generator",
        "Absorption_Event_Type",
        "event_known_after_close",
        "uses_future_information",
        *[col for col in events.columns if col not in _required_event_columns()],
    ]
    events = events[[col for col in ordered_cols if col in events.columns]].copy()

    _validate_candidate_events(events)
    return events


def validate_candidate_events(events: pd.DataFrame) -> None:
    """Public wrapper around the absorption_long candidate-event contract validator."""
    _validate_candidate_events(events)


def candidate_event_contract() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "side": SIDE_VALUE,
        "absorption_event_type": ABSORPTION_EVENT_TYPE,
        "candidate_event_generator": CANDIDATE_EVENT_GENERATOR,
        "event_logic": "downside failed displacement -> long candidate",
        "min_gap_bars": MIN_GAP_BARS,
        "wick_share_threshold": WICK_SHARE_THRESHOLD,
        "close_fail_threshold": CLOSE_FAIL_THRESHOLD,
        "min_range_atr": MIN_RANGE_ATR,
        "max_body_share": MAX_BODY_SHARE,
        "min_wick_atr": MIN_WICK_ATR,
        "exclude_liquidity_sweeps": EXCLUDE_LIQUIDITY_SWEEPS,
        "liquidity_lookback": LIQUIDITY_LOOKBACK,
        "liquidity_sweep_atr_threshold": LIQUIDITY_SWEEP_ATR_THRESHOLD,
        "event_vol_lookback": EVENT_VOL_LOOKBACK,
        "event_vol_ewm_span": EVENT_VOL_EWM_SPAN,
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
        "v1_reference": "NASDAQ/absorption-independent-edge/4_absorption_event_sampling.py",
    }


if __name__ == "__main__":
    print("✅ NASDAQ/absorption_long candidate_events.py import/self-contract check passed.")
    print(candidate_event_contract())
