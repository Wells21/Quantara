from __future__ import annotations

"""
V2 PORTFOLIO EXECUTION BOT
version: 2026-05-20_v2_execution_bot_manifest_signal_consumer

Purpose
-------
Consumes approved V2 execution-ready signals exported by:

    trading_models_v2/portfolio_live/portfolio_live_dashboard_orchestrator.py
    portfolio_live/outputs/live_dashboard/live_approved_signals.csv/jsonl

and converts them into MT5 paper/live orders with portfolio-level risk controls.

SOTD boundaries
---------------
- This bot does NOT build bars.
- This bot does NOT build features.
- This bot does NOT generate candidate events.
- This bot does NOT load models/calibrators or recompute probabilities.
- This bot consumes dashboard-approved runtime score outputs only.
- This bot owns broker checks, sizing, duplicate blocking, risk caps, order_send,
  paper/live audit logs, and position metadata.

Live arming
-----------
Real MT5 order_send is fail-closed unless ALL are true:
    settings.PORTFOLIO_EXECUTION_MODE == "live"
    settings.ENABLE_ORDER_SEND is True
    settings.LIVE_MODE == "REAL_LIVE"
    settings.ALLOW_REAL_LIVE_TRADING_EXPORT is True
    live_manifest.deployment_status == "LIVE_APPROVED"
    live_manifest.live_ready is True
    live_manifest.live_trade_enabled is True
    live_manifest.stress_validation_status == "STRESS_PASS"
    live_bar_policy.order_execution_allowed_by_policy is True

Otherwise, approved signals are paper-audited only.
"""

import argparse
import csv
import hashlib
import json
import logging
import math
import os
import signal
import sys
import threading
import time
import traceback
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from logging.handlers import RotatingFileHandler
from typing import Any, Iterable
from types import SimpleNamespace

import pandas as pd

THIS_FILE = Path(__file__).resolve()
LIVE_DIR = THIS_FILE.parent
V2_ROOT = THIS_FILE.parents[1]
REPO_ROOT = THIS_FILE.parents[2]
for _p in (LIVE_DIR, V2_ROOT, REPO_ROOT):
    _s = str(_p)
    if _s in sys.path:
        sys.path.remove(_s)
    sys.path.insert(0, _s)

import live_settings as settings  # type: ignore  # noqa: E402
from common import (  # type: ignore  # noqa: E402
    ensure_dirs,
    init_mt5,
    load_live_manifest,
    read_json,
    setup_logger,
    shutdown_mt5,
    write_json,
)

try:  # Telegram remains optional.
    import requests
except Exception:  # pragma: no cover
    requests = None


BOT_VERSION = "2026-07-02_v2_execution_bot_safe_lot_backoff_daily_guard+pending_bar_journal_v1+ack_retry_v1"
SIGNAL_SCHEMA = "v2_dashboard_approved_signal"
# Dashboard v2.1 writes schema_version="v2.1" while the execution-bot
# contract name remains v2_dashboard_approved_signal. Accept both explicit
# versions without weakening any downstream validation gates.
ACCEPTED_SIGNAL_SCHEMA_VERSIONS = {SIGNAL_SCHEMA, "v2.1"}
RISK_CONTRACT_VERSION = "direct_weight_calibrated_afml_broker_executable"
PROBABILITY_COLUMN = "calibrated_probability"

DASHBOARD_OUTPUT_DIR = settings.OUTPUT_DIR / "live_dashboard"
APPROVED_SIGNALS_CSV = DASHBOARD_OUTPUT_DIR / "live_approved_signals.csv"
APPROVED_SIGNALS_JSONL = DASHBOARD_OUTPUT_DIR / "live_approved_signals.jsonl"
DASHBOARD_STATUS_JSON = DASHBOARD_OUTPUT_DIR / "latest_dashboard_status.json"
DASHBOARD_BAR_ACK_JSON = DASHBOARD_OUTPUT_DIR / "latest_dashboard_bar_ack.json"
PENDING_LIVE_BAR_DIR = settings.LIVE_STATE_DIR / "pending_live_bars"

BOT_OUTPUT_DIR = settings.OUTPUT_DIR / "portfolio_execution_bot"
EXECUTION_AUDIT_CSV = BOT_OUTPUT_DIR / "portfolio_execution_audit.csv"
EXECUTED_TRADES_CSV = BOT_OUTPUT_DIR / "portfolio_executed_trades.csv"
REJECTED_SIGNALS_CSV = BOT_OUTPUT_DIR / "portfolio_rejected_signals.csv"
LATEST_STATUS_JSON = BOT_OUTPUT_DIR / "latest_execution_bot_status.json"

STATE_PATH = settings.LIVE_STATE_DIR / "portfolio_execution_bot_state.json"
LOG_PATH = settings.LIVE_LOGS_DIR / "portfolio_execution_bot.log"
LIVE_BAR_POLICY_PATH = settings.LIVE_CONFIG_DIR / "live_bar_policy.json"

EXECUTION_MODE = str(getattr(settings, "PORTFOLIO_EXECUTION_MODE", "paper")).lower().strip()
ENABLE_ORDER_SEND = bool(getattr(settings, "ENABLE_ORDER_SEND", False))
POLL_SECONDS = float(getattr(settings, "PORTFOLIO_EXECUTION_POLL_SECONDS", 1.0))
HEARTBEAT_SECONDS = float(getattr(settings, "PORTFOLIO_EXECUTION_HEARTBEAT_SECONDS", 5.0))
MAX_SIGNAL_AGE_SECONDS = int(getattr(settings, "PORTFOLIO_EXECUTION_MAX_SIGNAL_AGE_SECONDS", 300))
FUTURE_SIGNAL_TOLERANCE_SECONDS = float(getattr(settings, "PORTFOLIO_EXECUTION_FUTURE_SIGNAL_TOLERANCE_SECONDS", 5.0))
MAGIC_NUMBER = int(getattr(settings, "PORTFOLIO_MAGIC_NUMBER", 260512))

INCLUDE_UNMANAGED_POSITIONS_IN_RISK = bool(getattr(settings, "PORTFOLIO_INCLUDE_UNMANAGED_POSITIONS_IN_RISK", True))
BLOCK_IF_UNKNOWN_OPEN_RISK = bool(getattr(settings, "PORTFOLIO_BLOCK_IF_UNKNOWN_OPEN_RISK", True))
ENFORCE_BROKER_MIN_STOP_LEVEL = bool(getattr(settings, "PORTFOLIO_ENFORCE_BROKER_MIN_STOP_LEVEL", True))
ALLOW_WIDEN_TO_BROKER_MIN_STOP = bool(getattr(settings, "PORTFOLIO_ALLOW_WIDEN_TO_BROKER_MIN_STOP", False))
STATIC_FLOOR_BUFFER_USD = float(getattr(settings, "PORTFOLIO_STATIC_FLOOR_BUFFER_USD", 25.0))
BLOCK_NEW_TRADES_AT_OR_ABOVE_TARGET = bool(getattr(settings, "PORTFOLIO_BLOCK_AT_TARGET_BALANCE", True))
ALLOW_MIN_LOT_FALLBACK = bool(getattr(settings, "PORTFOLIO_ALLOW_MIN_LOT_FALLBACK", True))

# Live symbol-risk safety overlay. The allocator's internal cap remains part of
# the signed source contract, but live admission is tightened dynamically to
# legal_cap / multiplier. For Atmos: min(950, 1000 / 1.25) = 800 USD.
DEFAULT_SYMBOL_RISK_STRESS_MULTIPLIER = 1.25
EXPECTED_CHALLENGE_STAGE = "challenge"
EXPECTED_CHALLENGE_SCOPE = "atmos_nova_100k_challenge_only"
POST_FILL_RISK_CHECK_ENABLED = True
POST_FILL_EMERGENCY_REDUCE_ENABLED = True
POST_FILL_POSITION_LOOKUP_RETRIES = 8
POST_FILL_POSITION_LOOKUP_SLEEP_SECONDS = 0.20

MAX_SPREAD_POINTS_BY_ASSET = dict(getattr(settings, "PORTFOLIO_MAX_SPREAD_POINTS_BY_ASSET", {}))
ENTRY_DRIFT_LIMIT_PRICE_BY_ASSET = dict(getattr(settings, "PORTFOLIO_ENTRY_DRIFT_LIMIT_PRICE_BY_ASSET", {}))
ENTRY_DRIFT_FRACTION_OF_SL_BY_ASSET = dict(getattr(settings, "PORTFOLIO_ENTRY_DRIFT_FRACTION_OF_SL_BY_ASSET", {}))
ENTRY_DRIFT_MAX_CAP_PRICE_BY_ASSET = dict(getattr(settings, "PORTFOLIO_ENTRY_DRIFT_MAX_CAP_PRICE_BY_ASSET", {}))
DEVIATION_POINTS_BY_ASSET = dict(getattr(settings, "PORTFOLIO_DEVIATION_POINTS_BY_ASSET", {}))
MAX_LOT_CAP_BY_ASSET = dict(getattr(settings, "PORTFOLIO_MAX_LOT_CAP_BY_ASSET", {}))

TELEGRAM_TOKEN = str(getattr(settings, "TELEGRAM_TOKEN", "") or "")
TELEGRAM_CHAT_IDS = list(getattr(settings, "TELEGRAM_CHAT_IDS", []) or [])
SEND_STARTUP_TELEGRAM = bool(getattr(settings, "PORTFOLIO_SEND_STARTUP_TELEGRAM", False))
SEND_EXECUTION_TELEGRAM = bool(getattr(settings, "PORTFOLIO_SEND_EXECUTION_TELEGRAM", False))
SEND_REJECTION_TELEGRAM = bool(getattr(settings, "PORTFOLIO_SEND_REJECTION_TELEGRAM", False))

LIVE_BAR_READ_RETRIES = max(int(getattr(settings, "PORTFOLIO_LIVE_BAR_READ_RETRIES", 4)), 1)
LIVE_BAR_READ_RETRY_SECONDS = max(float(getattr(settings, "PORTFOLIO_LIVE_BAR_READ_RETRY_SECONDS", 0.05)), 0.0)
TRANSIENT_ORDER_RETRY_INITIAL_SECONDS = max(float(getattr(settings, "PORTFOLIO_TRANSIENT_ORDER_RETRY_INITIAL_SECONDS", 2.0)), 0.25)
TRANSIENT_ORDER_RETRY_MAX_SECONDS = max(float(getattr(settings, "PORTFOLIO_TRANSIENT_ORDER_RETRY_MAX_SECONDS", 15.0)), TRANSIENT_ORDER_RETRY_INITIAL_SECONDS)

# Vertical-barrier exits remain bar-count based and anchored to the model event
# time. These guards only verify that counted bars are canonical, dashboard-
# acknowledged UTC live bars and that the broker position has experienced at
# least one genuinely new bar after its fill. Any ambiguity defers the exit;
# broker-side SL/TP protection remains active.
VERTICAL_BARRIER_REQUIRE_DASHBOARD_ACK = bool(
    getattr(settings, "PORTFOLIO_VERTICAL_BARRIER_REQUIRE_DASHBOARD_ACK", True)
)
VERTICAL_BARRIER_FUTURE_TOLERANCE_SECONDS = max(
    float(
        getattr(
            settings,
            "PORTFOLIO_VERTICAL_BARRIER_FUTURE_TOLERANCE_SECONDS",
            FUTURE_SIGNAL_TOLERANCE_SECONDS,
        )
    ),
    0.0,
)
VERTICAL_BARRIER_REQUIRE_POST_FILL_BAR = bool(
    getattr(settings, "PORTFOLIO_VERTICAL_BARRIER_REQUIRE_POST_FILL_BAR", True)
)
VERTICAL_BARRIER_STATUS_READ_RETRIES = max(
    int(getattr(settings, "PORTFOLIO_VERTICAL_BARRIER_STATUS_READ_RETRIES", 3)),
    1,
)
VERTICAL_BARRIER_ACK_CATCHUP_RETRIES = max(
    int(getattr(settings, "PORTFOLIO_VERTICAL_BARRIER_ACK_CATCHUP_RETRIES", 8)),
    1,
)
VERTICAL_BARRIER_ACK_CATCHUP_SLEEP_SECONDS = max(
    float(getattr(settings, "PORTFOLIO_VERTICAL_BARRIER_ACK_CATCHUP_SLEEP_SECONDS", 0.15)),
    0.01,
)

# Daily-drawdown runtime overrides are optional. By default the signed allocator
# contract supplies the percentage, while the dashboard's locked broker-time
# offset supplies the server-day rollover boundary.
DAILY_DRAWDOWN_PCT_OVERRIDE = getattr(settings, "PORTFOLIO_DAILY_DRAWDOWN_PCT", None)
DAILY_RESET_OFFSET_HOURS_OVERRIDE = getattr(settings, "PORTFOLIO_DAILY_RESET_OFFSET_HOURS", None)
RISK_CONTRACT_DERIVATION_VERSION = "v3_percent_daily_and_equity_hwm_trailing"


def setup_logger(name: str, log_file: Path | None = None) -> logging.Logger:
    """Preserve existing logging behavior while bounding live log growth."""
    ensure_dirs()
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    if log_file is not None:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        max_bytes = max(int(getattr(settings, "LIVE_LOG_ROTATION_MAX_BYTES", 25_000_000)), 1_000_000)
        backup_count = max(int(getattr(settings, "LIVE_LOG_ROTATION_BACKUP_COUNT", 8)), 1)
        fh = RotatingFileHandler(log_file, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    return logger


@dataclass
class CandidateSizing:
    base_portfolio_risk_budget_pct: float
    portfolio_weight: float
    afml_bet_size: float
    throttle_multiplier: float
    target_lock_multiplier: float
    target_risk_pct_before_cap: float
    target_risk_pct: float
    target_risk_usd: float
    max_single_risk_usd: float
    remaining_total_cap_usd: float
    remaining_asset_cap_usd: float
    remaining_family_cap_usd: float
    remaining_edge_cap_usd: float


@dataclass
class OrderPlan:
    signal_id: str
    edge_id: str
    asset: str
    symbol: str
    family: str
    side_name: str
    side_value: int
    order_type_name: str
    order_type: int
    entry_price: float
    signal_price: float
    stop_loss: float
    take_profit: float
    sl_distance: float
    tp_distance: float
    # Original model/allocator target after AFML/HRP/throttle/max-single logic.
    model_target_risk_pct: float
    model_target_risk_usd: float
    # Final target used for broker volume sizing after remaining total/asset/family/edge caps.
    target_risk_pct: float
    target_risk_usd: float
    actual_risk_usd: float
    actual_risk_pct: float
    volume: float
    used_min_lot_fallback: bool
    spread_points: float
    entry_drift_price: float
    deviation_points: int
    magic: int
    comment: str
    type_filling: int
    geometry_hash: str | None
    pt_multiplier: float
    sl_multiplier: float
    reward_risk_ratio: float
    vertical_horizon_bars: int | None
    risk_contract_hash: str | None
    trailing_floor: float | None
    actual_trailing_buffer_before: float | None
    # Backward-compatible alias for projected buffer after existing positions hit SL.
    remaining_trailing_buffer_before: float | None
    projected_trailing_buffer_before: float | None
    projected_trailing_buffer_after: float | None
    required_trailing_buffer_reserve: float | None
    # Backward-compatible alias for projected remaining capacity before entry.
    daily_loss_remaining_before: float | None
    actual_daily_loss_remaining_before: float | None
    projected_daily_loss_remaining_before: float | None
    projected_daily_equity_proxy: float | None
    symbol_closed_losses_usd: float | None
    projected_symbol_risk_usd: float | None
    symbol_risk_stress_multiplier: float | None
    projected_stressed_symbol_risk_usd: float | None
    live_internal_symbol_risk_amount: float | None
    legal_symbol_risk_amount: float | None
    execution_plan_hash: str | None
    live_manifest_hash: str | None
    edge_manifest_hash: str | None
    bar_policy_hash: str | None


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def utc_now_ts() -> pd.Timestamp:
    return pd.Timestamp(datetime.now(timezone.utc))


def ensure_runtime_dirs() -> None:
    ensure_dirs()
    BOT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def safe_float(x: Any, default: float | None = None) -> float | None:
    try:
        if x is None:
            return default
        if isinstance(x, str) and x.strip().lower() in {"", "nan", "none", "null"}:
            return default
        val = float(x)
        if math.isnan(val) or math.isinf(val):
            return default
        return val
    except Exception:
        return default


def safe_int(x: Any, default: int | None = None) -> int | None:
    try:
        if x is None:
            return default
        if isinstance(x, str) and x.strip().lower() in {"", "nan", "none", "null"}:
            return default
        return int(float(x))
    except Exception:
        return default


def safe_bool(x: Any, default: bool = False) -> bool:
    if isinstance(x, bool):
        return x
    if x is None:
        return default
    try:
        if pd.isna(x):
            return default
    except Exception:
        pass
    s = str(x).strip().lower()
    if s in {"true", "1", "yes", "y"}:
        return True
    if s in {"false", "0", "no", "n"}:
        return False
    return default


def ensure_utc_timestamp(ts: Any) -> pd.Timestamp | None:
    try:
        stamp = pd.Timestamp(ts)
        if pd.isna(stamp):
            return None
        if stamp.tzinfo is None:
            stamp = stamp.tz_localize("UTC")
        else:
            stamp = stamp.tz_convert("UTC")
        return stamp
    except Exception:
        return None


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def hash_or_none(path: Path) -> str | None:
    return sha256_file(path) if path.exists() else None


def read_json_object(path: Path) -> dict[str, Any]:
    return read_json(path)


def append_rows_csv(path: Path, rows: list[dict[str, Any]], dedup_cols: list[str] | None = None) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    new_df = pd.DataFrame(rows)
    if path.exists():
        try:
            old = pd.read_csv(path)
            df = pd.concat([old, new_df], ignore_index=True, sort=False)
        except Exception:
            df = new_df
    else:
        df = new_df
    if dedup_cols:
        cols = [c for c in dedup_cols if c in df.columns]
        if cols:
            df = df.drop_duplicates(subset=cols, keep="last")
    df.to_csv(path, index=False)


def append_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, default=str, sort_keys=True) + "\n")


def get_retcode_name(mt5: Any, retcode: Any) -> str:
    try:
        retcode_int = int(retcode)
    except Exception:
        return ""
    for name in dir(mt5):
        if name.startswith("TRADE_RETCODE_") and isinstance(getattr(mt5, name), int):
            if getattr(mt5, name) == retcode_int:
                return name
    return ""


def _mask_telegram_chat_id(chat_id: Any) -> str:
    text = str(chat_id)
    if len(text) <= 4:
        return "*" * len(text)
    return f"{text[:2]}***{text[-2:]}"


def telegram_config_snapshot() -> dict[str, Any]:
    return {
        "token_present": bool(TELEGRAM_TOKEN),
        "token_length": len(TELEGRAM_TOKEN),
        "chat_ids_count": len(TELEGRAM_CHAT_IDS),
        "masked_chat_ids": [_mask_telegram_chat_id(chat_id) for chat_id in TELEGRAM_CHAT_IDS],
        "requests_available": requests is not None,
        "send_startup_enabled": SEND_STARTUP_TELEGRAM,
        "send_execution_enabled": SEND_EXECUTION_TELEGRAM,
        "send_rejection_enabled": SEND_REJECTION_TELEGRAM,
    }


def send_telegram(message: str) -> dict[str, str]:
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_IDS or requests is None:
        return {}
    out: dict[str, str] = {}
    for chat_id in TELEGRAM_CHAT_IDS:
        try:
            url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
            resp = requests.post(url, data={"chat_id": chat_id, "text": message}, timeout=8)
            out[str(chat_id)] = "ok" if resp.ok else f"HTTP {resp.status_code}: {resp.text[:200]}"
        except Exception as exc:
            out[str(chat_id)] = f"EXC: {exc}"
    return out


def send_telegram_logged(
    logger: Any,
    state: dict[str, Any],
    purpose: str,
    message: str,
) -> dict[str, str]:
    """Send Telegram and log/store the exact outcome without exposing the token.

    Telegram is observability only. A Telegram failure must never block signal
    validation, paper auditing, or live order execution; it must only leave a
    clear diagnostic trail in the bot log and state file.
    """
    config = telegram_config_snapshot()
    result = send_telegram(message)
    if not result:
        skipped_reasons = []
        if not TELEGRAM_TOKEN:
            skipped_reasons.append("missing_telegram_token")
        if not TELEGRAM_CHAT_IDS:
            skipped_reasons.append("missing_telegram_chat_ids")
        if requests is None:
            skipped_reasons.append("requests_not_available")
        if not skipped_reasons:
            skipped_reasons.append("send_returned_empty_result")

        record = {
            "created_at": utc_now(),
            "purpose": str(purpose),
            "status": "skipped",
            "reason": ";".join(skipped_reasons),
            "message_length": len(str(message)),
            **config,
            "result": result,
        }
        logger.warning(
            "TELEGRAM_SEND_SKIPPED purpose=%s reason=%s token_present=%s token_length=%s "
            "chat_ids_count=%s masked_chat_ids=%s requests_available=%s startup_enabled=%s "
            "execution_enabled=%s rejection_enabled=%s",
            purpose,
            record["reason"],
            config["token_present"],
            config["token_length"],
            config["chat_ids_count"],
            config["masked_chat_ids"],
            config["requests_available"],
            config["send_startup_enabled"],
            config["send_execution_enabled"],
            config["send_rejection_enabled"],
        )
    else:
        masked_result = {_mask_telegram_chat_id(chat_id): status for chat_id, status in result.items()}
        failed = {chat_id: status for chat_id, status in masked_result.items() if status != "ok"}
        status = "ok" if not failed else "partial_or_failed"
        record = {
            "created_at": utc_now(),
            "purpose": str(purpose),
            "status": status,
            "reason": "ok" if status == "ok" else "one_or_more_telegram_sends_failed",
            "message_length": len(str(message)),
            **config,
            "result": masked_result,
            "failed": failed,
        }
        if failed:
            logger.warning(
                "TELEGRAM_SEND_RESULT purpose=%s status=%s failed=%s result=%s",
                purpose,
                status,
                failed,
                masked_result,
            )
        else:
            logger.info(
                "TELEGRAM_SEND_RESULT purpose=%s status=ok chat_ids_count=%s masked_chat_ids=%s",
                purpose,
                config["chat_ids_count"],
                config["masked_chat_ids"],
            )

    state["last_telegram_send"] = record
    state.setdefault("telegram_send_history", []).append(record)
    state["telegram_send_history"] = state["telegram_send_history"][-50:]
    return result


def _telegram_reason_family(reason: str) -> str:
    """Normalize numeric/repeating reason text for Telegram de-duplication.

    Plan-stage waits such as ``entry_drift_too_large:5.91>4.00`` can change
    every polling loop even though the underlying reason is the same. The full
    reason is still shown in the message/audit rows, but the notification key
    uses this stable family to prevent repeated Telegram spam for one signal.
    """
    text = str(reason or "").strip()
    if not text:
        return "unknown_reason"
    return text.split(":", 1)[0]


def _telegram_issue_key(signal: dict[str, Any], stage: str, status: str, reason: str) -> str:
    """Stable de-dup key for issue notifications.

    Transient plan-stage waits can repeat every polling loop. This key prevents
    Telegram spam while still sending a new alert if the same signal later fails
    for a different stage/reason family.
    """
    sid = str(signal.get("signal_id", "") or "").strip() or "unknown_signal"
    return f"{sid}|{stage}|{status}|{_telegram_reason_family(reason)}"


def send_signal_issue_telegram_once(
    logger: Any,
    state: dict[str, Any],
    *,
    signal: dict[str, Any],
    stage: str,
    status: str,
    reason: str,
    account: Any = None,
    open_risk: dict[str, Any] | None = None,
    live_armed: bool | None = None,
    live_blockers: list[str] | None = None,
) -> None:
    """Notify Telegram once for plan/open-risk/account-stage non-execution.

    This is observability only. It must not change validation, sizing, order
    submission, terminal marking, or retry behavior. Validation-stage blocks and
    broker order rejections keep their existing Telegram paths.
    """
    if not SEND_REJECTION_TELEGRAM:
        return

    key = _telegram_issue_key(signal, stage, status, reason)
    sent_keys = state.setdefault("telegram_signal_issue_notification_keys", [])
    if key in sent_keys:
        return

    sent_keys.append(key)
    state["telegram_signal_issue_notification_keys"] = sent_keys[-1000:]

    icon = "⏳" if status == "transient_wait" else "❌"
    title = "V2 signal waiting" if status == "transient_wait" else "V2 signal blocked"
    asset = signal.get("asset")
    edge_id = signal.get("edge_id")
    side_value = safe_int(signal.get("side_value"), None)
    side_text = "LONG" if side_value == 1 else "SHORT" if side_value == -1 else str(side_value)
    cp = safe_float(signal.get("calibrated_probability"), 0.0) or 0.0
    thr = safe_float(signal.get("final_live_threshold"), 0.0) or 0.0
    signal_price = safe_float(signal.get("signal_price"), None)
    equity = getattr(account, "equity", None) if account is not None else None
    open_risk_total = (open_risk or {}).get("total_open_risk_usd")

    message = (
        f"{icon} {title}\n"
        f"stage={stage} status={status}\n"
        f"{asset} {side_text} | {edge_id}\n"
        f"reason={reason}\n"
        f"p={cp:.4f} thr={thr:.4f}\n"
        f"signal_price={signal_price}\n"
        f"equity={equity} open_risk=${open_risk_total}\n"
        f"live_armed={live_armed}"
    )
    if live_blockers:
        message += f"\nlive_blockers={'; '.join(live_blockers[:3])}"

    send_telegram_logged(logger, state, f"{stage}_{status}", message)


def initial_state() -> dict[str, Any]:
    return {
        "created_at": utc_now(),
        "updated_at": None,
        "version": BOT_VERSION,
        "terminal_signal_ids": {},
        # Primary exact map: MT5 position ticket -> full execution metadata.
        "open_position_metadata_by_ticket": {},
        # Secondary maps preserve full edge attribution across MT5 restarts,
        # order/deal ticket differences, and broker-truncated comments.
        "open_position_metadata_by_comment": {},
        "open_position_metadata_by_order": {},
        "open_position_metadata_by_deal": {},
        "open_position_metadata_by_signal_id": {},
        "ambiguous_position_metadata_comments": {},
        "last_heartbeat_at": None,
        "last_manifest_hash": None,
        "last_bar_policy_hash": None,
        "last_telegram_send": None,
        "telegram_send_history": [],
        "telegram_signal_issue_notification_keys": [],
        "prop_risk_state": {},
        "vertical_exit_notification_keys": [],
        "equity_high_watermark_migration": {},
        "preferred_filling_mode_by_symbol": {},
        "transient_order_retry_by_signal": {},
        "vertical_bar_read_deferred_count_by_asset": {},
        "vertical_barrier_last_progress_by_ticket": {},
        "vertical_barrier_deferred_history": [],
        "counters": {
            "seen_candidates": 0,
            "paper_trades": 0,
            "live_trades": 0,
            "blocked": 0,
            "transient_waits": 0,
            "errors": 0,
        },
    }

def load_state() -> dict[str, Any]:
    if STATE_PATH.exists():
        try:
            state = read_json_object(STATE_PATH)
        except Exception:
            state = initial_state()
    else:
        state = initial_state()
    state.setdefault("terminal_signal_ids", {})
    state.setdefault("open_position_metadata_by_ticket", {})
    state.setdefault("open_position_metadata_by_comment", {})
    state.setdefault("open_position_metadata_by_order", {})
    state.setdefault("open_position_metadata_by_deal", {})
    state.setdefault("open_position_metadata_by_signal_id", {})
    state.setdefault("ambiguous_position_metadata_comments", {})
    state.setdefault("last_telegram_send", None)
    state.setdefault("telegram_send_history", [])
    state.setdefault("telegram_signal_issue_notification_keys", [])
    state.setdefault("prop_risk_state", {})
    state.setdefault("vertical_exit_notification_keys", [])
    state.setdefault("equity_high_watermark_migration", {})
    state.setdefault("preferred_filling_mode_by_symbol", {})
    state.setdefault("transient_order_retry_by_signal", {})
    state.setdefault("vertical_bar_read_deferred_count_by_asset", {})
    state.setdefault("vertical_barrier_last_progress_by_ticket", {})
    state.setdefault("vertical_barrier_deferred_history", [])
    state.setdefault("counters", {})
    for key in ["seen_candidates", "paper_trades", "live_trades", "blocked", "transient_waits", "errors"]:
        state["counters"].setdefault(key, 0)

    # Backfill full edge metadata from prior execution audit/output rows. This
    # repairs older open positions whose MT5 comments only contain shortened
    # family text and therefore would otherwise be bucketed as edge_id=UNKNOWN.
    try:
        backfill_position_metadata_from_execution_outputs(state)
    except Exception:
        # State loading must stay fail-open; unresolved positions are later
        # handled by get_open_risk_snapshot()/BLOCK_IF_UNKNOWN_OPEN_RISK.
        pass
    return state

def save_state(state: dict[str, Any]) -> None:
    state["updated_at"] = utc_now()
    write_json(STATE_PATH, state)


def mark_terminal(state: dict[str, Any], signal_id: str, status: str, reason: str, extra: dict[str, Any] | None = None) -> None:
    state.setdefault("terminal_signal_ids", {})[str(signal_id)] = {
        "status": status,
        "reason": reason,
        "timestamp": utc_now(),
        **(extra or {}),
    }


def is_terminal(state: dict[str, Any], signal_id: str) -> bool:
    return str(signal_id) in state.get("terminal_signal_ids", {})


def load_live_bar_policy() -> dict[str, Any]:
    if not LIVE_BAR_POLICY_PATH.exists():
        raise FileNotFoundError(f"Missing live bar policy: {LIVE_BAR_POLICY_PATH}. Run portfolio_live/04_freeze_live_bar_thresholds.py first.")
    payload = read_json_object(LIVE_BAR_POLICY_PATH)
    if payload.get("manifest_type") != "v2_frozen_live_bar_policy":
        raise ValueError(f"Invalid live bar policy manifest_type: {payload.get('manifest_type')}")
    return payload


def selected_edge_lookup(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    edges = manifest.get("selected_edges", [])
    if not isinstance(edges, list) or not edges:
        raise ValueError("live_manifest.selected_edges must be a non-empty list")
    out: dict[str, dict[str, Any]] = {}
    for edge in edges:
        edge_id = str(edge.get("edge_id", "")).strip()
        if not edge_id:
            raise ValueError("selected edge missing edge_id")
        if edge_id in out:
            raise ValueError(f"duplicate selected edge_id: {edge_id}")
        out[edge_id] = edge
    return out


def universe_symbols(manifest: dict[str, Any]) -> dict[str, str]:
    out: dict[str, str] = {}
    for edge in manifest.get("selected_edges", []):
        asset = str(edge.get("asset", "")).strip()
        if asset:
            out[settings.MT5_SYMBOL_MAP.get(asset, asset)] = asset
    return out


def real_order_send_armed(manifest: dict[str, Any], policy: dict[str, Any]) -> tuple[bool, list[str]]:
    blockers: list[str] = []
    local_stage = str(getattr(settings, "PORTFOLIO_ACCOUNT_STAGE", "")).strip().lower()
    manifest_stage = str(manifest.get("approved_account_stage") or manifest.get("account_stage") or "").strip().lower()
    if EXECUTION_MODE != "live": blockers.append(f"PORTFOLIO_EXECUTION_MODE={EXECUTION_MODE}")
    if not ENABLE_ORDER_SEND: blockers.append("ENABLE_ORDER_SEND=False")
    if str(getattr(settings, "LIVE_MODE", "DRY_RUN_ONLY")) != "REAL_LIVE": blockers.append(f"LIVE_MODE={getattr(settings, 'LIVE_MODE', None)}")
    if not bool(getattr(settings, "ALLOW_REAL_LIVE_TRADING_EXPORT", False)): blockers.append("ALLOW_REAL_LIVE_TRADING_EXPORT=False")
    if manifest.get("deployment_status") != "LIVE_APPROVED": blockers.append(f"manifest_deployment_status={manifest.get('deployment_status')}")
    if manifest.get("live_ready") is not True: blockers.append("manifest.live_ready=False")
    if manifest.get("live_trade_enabled") is not True: blockers.append("manifest.live_trade_enabled=False")
    if manifest.get("stress_validation_status") != "STRESS_PASS": blockers.append(f"stress_validation_status={manifest.get('stress_validation_status')}")
    if manifest.get("risk_contract_version") != RISK_CONTRACT_VERSION: blockers.append("risk_contract_version_mismatch")
    if local_stage != manifest_stage: blockers.append(f"account_stage_mismatch:local={local_stage},manifest={manifest_stage}")
    if manifest_stage == EXPECTED_CHALLENGE_STAGE:
        if manifest.get("live_approval_scope") != EXPECTED_CHALLENGE_SCOPE: blockers.append("challenge_live_approval_scope_mismatch")
        if manifest.get("daily_symbol_risk_rule_enabled") is not False: blockers.append("challenge_symbol_risk_rule_must_be_disabled")
    elif manifest.get("funded_stage_live_approval_status") != "APPROVED_FOR_FUNDED_LIVE_MANIFEST_EXPORT":
        blockers.append("funded_stage_not_approved")
    current_manifest_hash = hash_or_none(settings.LIVE_MANIFEST_PATH)
    if policy.get("source_live_manifest_sha256") != current_manifest_hash: blockers.append("bar_policy_source_manifest_hash_mismatch")
    if policy.get("approved_account_stage") != manifest_stage: blockers.append("bar_policy_account_stage_mismatch")
    if policy.get("live_policy_ready") is not True: blockers.append(f"live_policy_ready={policy.get('live_policy_ready')}")
    if policy.get("order_execution_allowed_by_policy") is not True: blockers.append(f"order_execution_allowed_by_policy={policy.get('order_execution_allowed_by_policy')}")
    return not blockers, blockers


def validate_live_manifest(manifest: dict[str, Any]) -> None:
    if manifest.get("manifest_type") != "v2_allocator_selected_live_manifest":
        raise ValueError(f"Invalid live_manifest manifest_type: {manifest.get('manifest_type')}")
    if manifest.get("threshold_probability_column") != PROBABILITY_COLUMN:
        raise ValueError("live_manifest.threshold_probability_column must be calibrated_probability")
    if manifest.get("risk_contract_version") != RISK_CONTRACT_VERSION:
        raise ValueError(f"live_manifest.risk_contract_version must be {RISK_CONTRACT_VERSION}")
    manifest_stage = str(manifest.get("approved_account_stage") or manifest.get("account_stage") or "").strip().lower()
    local_stage = str(getattr(settings, "PORTFOLIO_ACCOUNT_STAGE", "")).strip().lower()
    if manifest_stage != local_stage:
        raise ValueError(f"local/manifest account stage mismatch: {local_stage!r}!={manifest_stage!r}")
    if manifest_stage == EXPECTED_CHALLENGE_STAGE:
        if manifest.get("live_approval_scope") != EXPECTED_CHALLENGE_SCOPE:
            raise ValueError("challenge manifest approval scope mismatch")
        if manifest.get("daily_symbol_risk_rule_enabled") is not False:
            raise ValueError("challenge manifest must keep funded symbol-risk rule disabled")
    if manifest.get("sotd_contracts", {}).get("execution_bot_must_consume_approved_signal_schema_only") is not True:
        raise ValueError("live_manifest SOTD contract does not require approved signal schema consumption")
    if not manifest.get("selected_edges"):
        raise ValueError("live_manifest selected_edges is empty")


def select_symbols(mt5: Any, manifest: dict[str, Any], logger: Any) -> None:
    for symbol, asset in universe_symbols(manifest).items():
        ok = bool(mt5.symbol_select(symbol, True))
        info = mt5.symbol_info(symbol)
        if not ok or info is None:
            raise RuntimeError(f"Failed to select/read MT5 symbol for asset={asset} symbol={symbol}")
        logger.info(
            "SYMBOL_READY asset=%s symbol=%s digits=%s point=%s vol_min=%s vol_step=%s filling_mode=%s",
            asset,
            symbol,
            getattr(info, "digits", None),
            getattr(info, "point", None),
            getattr(info, "volume_min", None),
            getattr(info, "volume_step", None),
            getattr(info, "filling_mode", None),
        )


def read_approved_signal_rows(logger: Any) -> pd.DataFrame:
    df = pd.DataFrame()
    if APPROVED_SIGNALS_CSV.exists():
        try:
            df = pd.read_csv(APPROVED_SIGNALS_CSV)
        except Exception as exc:
            logger.warning("SIGNAL_READ_WARN path=%s error=%s", APPROVED_SIGNALS_CSV, exc)
            df = pd.DataFrame()
    elif APPROVED_SIGNALS_JSONL.exists():
        rows: list[dict[str, Any]] = []
        try:
            with APPROVED_SIGNALS_JSONL.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        rows.append(json.loads(line))
            df = pd.DataFrame(rows)
        except Exception as exc:
            logger.warning("SIGNAL_JSONL_READ_WARN path=%s error=%s", APPROVED_SIGNALS_JSONL, exc)
            df = pd.DataFrame()
    if df.empty:
        return df
    required = [
        "schema_version", "signal_id", "signal_status", "edge_id", "asset", "mt5_symbol",
        "side_value", "event_time", "calibrated_probability", "afml_bet_size",
        "final_live_threshold", "threshold_probability_column", "approved_signal",
        "portfolio_weight", "risk_contract_version", "account_stage", "approved_account_stage",
        "live_approval_scope", "daily_symbol_risk_rule_enabled", "selected_variant_contract_hash",
        "live_manifest_hash", "edge_manifest_hash", "bar_policy_hash", "bar_gap_healed", "bar_executable",
        "signal_price", "execution_plan_ready", "execution_plan_json",
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        logger.warning("SIGNAL_CONTRACT_MISSING_COLUMNS missing=%s", missing)
        return pd.DataFrame()
    df = df.copy()
    df["_event_ts"] = pd.to_datetime(df["event_time"], utc=True, errors="coerce")
    df = df.dropna(subset=["_event_ts"])
    df = df.sort_values(["_event_ts", "signal_id"]).reset_index(drop=True)
    return df


def row_to_signal(row: pd.Series) -> dict[str, Any]:
    d = row.to_dict()
    for col in [
        "approved_signal", "probability_passes_final_threshold", "execution_allowed",
        "live_trade_enabled", "live_policy_ready", "bar_gap_healed", "bar_executable", "execution_plan_ready",
        "daily_symbol_risk_rule_enabled",
    ]:
        if col in d:
            d[col] = safe_bool(d[col], False)
    for col in ["side_value", "bar_ticks", "bar_threshold", "vertical_horizon_bars"]:
        if col in d:
            d[col] = safe_int(d[col], None)
    for col in [
        "raw_probability", "calibrated_probability", "afml_bet_size", "final_live_threshold",
        "portfolio_weight", "signal_price", "planned_sl_distance_price", "planned_tp_distance_price",
        "planned_stop_loss", "planned_take_profit",
    ]:
        if col in d:
            d[col] = safe_float(d[col], None)
    return d


def candidate_rows(df: pd.DataFrame, state: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    if df.empty:
        return out
    for _, row in df.iterrows():
        sig = row_to_signal(row)
        sid = str(sig.get("signal_id", "")).strip()
        if not sid or is_terminal(state, sid):
            continue
        if str(sig.get("signal_status", "")) != "approved_signal":
            continue
        if not safe_bool(sig.get("approved_signal"), False):
            continue
        if safe_bool(sig.get("bar_gap_healed"), False):
            continue
        if not safe_bool(sig.get("bar_executable"), False):
            continue
        if not safe_bool(sig.get("execution_plan_ready"), False):
            continue
        retry = (state.get("transient_order_retry_by_signal") or {}).get(sid) or {}
        next_retry_at = ensure_utc_timestamp(retry.get("next_retry_at"))
        if next_retry_at is not None and utc_now_ts() < next_retry_at:
            continue
        out.append(sig)
    return out


def parse_execution_plan(signal: dict[str, Any]) -> tuple[dict[str, Any] | None, str]:
    raw = signal.get("execution_plan_json")
    if raw is None or (isinstance(raw, float) and pd.isna(raw)) or str(raw).strip() == "":
        return None, "missing_execution_plan_json"
    try:
        if isinstance(raw, str):
            compact = raw
            plan = json.loads(raw)
        else:
            plan = raw
            compact = json.dumps(plan, sort_keys=True, default=str, allow_nan=True)
    except Exception as exc:
        return None, f"invalid_execution_plan_json:{exc}"
    if not isinstance(plan, dict):
        return None, "execution_plan_json_not_object"
    expected_hash = str(signal.get("execution_plan_hash") or "").strip()
    actual_hash = hashlib.sha256(compact.encode("utf-8")).hexdigest()
    if not expected_hash:
        return None, "missing_execution_plan_hash"
    if actual_hash != expected_hash:
        return None, "execution_plan_hash_mismatch"
    if safe_bool(plan.get("execution_plan_ready"), safe_bool(signal.get("execution_plan_ready"), False)) is not True:
        return None, f"execution_plan_not_ready:{plan.get('execution_plan_blocker') or signal.get('execution_plan_blocker')}"
    plan["execution_plan_hash"] = expected_hash
    plan["execution_plan_json"] = compact
    return plan, "ok"



def validate_signal_contract(
    signal: dict[str, Any],
    edge_lookup: dict[str, dict[str, Any]],
    current_hashes: dict[str, str | None],
    require_execution_allowed_for_live: bool,
) -> tuple[bool, str, dict[str, Any] | None]:
    sid = str(signal.get("signal_id", "")).strip()
    if not sid:
        return False, "missing_signal_id", None
    schema_version = str(signal.get("schema_version", "")).strip()
    if schema_version not in ACCEPTED_SIGNAL_SCHEMA_VERSIONS:
        return False, f"wrong_schema_version:{signal.get('schema_version')}", None
    if str(signal.get("signal_status", "")) != "approved_signal" or not safe_bool(signal.get("approved_signal"), False):
        return False, "not_approved_signal", None
    if str(signal.get("threshold_probability_column", "calibrated_probability")) != PROBABILITY_COLUMN:
        return False, "threshold_probability_column_not_calibrated_probability", None
    if safe_bool(signal.get("bar_gap_healed"), False):
        return False, "gap_healed_bar_not_executable", None
    if not safe_bool(signal.get("bar_executable"), False):
        return False, "bar_not_executable", None
    if not safe_bool(signal.get("execution_plan_ready"), False):
        return False, f"execution_plan_not_ready:{signal.get('execution_plan_blocker')}", None
    if require_execution_allowed_for_live and not safe_bool(signal.get("execution_allowed"), False):
        return False, f"execution_not_allowed_by_signal:{signal.get('execution_blocker')}", None

    edge_id = str(signal.get("edge_id", "")).strip()
    if edge_id not in edge_lookup:
        return False, f"edge_not_in_live_manifest:{edge_id}", None
    edge = edge_lookup[edge_id]
    if str(signal.get("live_manifest_hash", "")) != str(current_hashes.get("live_manifest_hash")):
        return False, "live_manifest_hash_mismatch", None
    if str(signal.get("bar_policy_hash", "")) != str(current_hashes.get("bar_policy_hash")):
        return False, "bar_policy_hash_mismatch", None
    if str(signal.get("edge_manifest_hash", "")) != str(edge.get("edge_manifest_hash", "")):
        return False, "edge_manifest_hash_mismatch", None
    if str(signal.get("risk_contract_version", "")) != RISK_CONTRACT_VERSION:
        return False, "signal_risk_contract_version_mismatch", None
    manifest_stage = str(edge.get("account_stage") or signal.get("approved_account_stage") or signal.get("account_stage") or "").strip().lower()
    signal_stage = str(signal.get("approved_account_stage") or signal.get("account_stage") or "").strip().lower()
    if signal_stage != str(getattr(settings, "PORTFOLIO_ACCOUNT_STAGE", "")).strip().lower():
        return False, "signal_account_stage_mismatch", None
    if safe_bool(signal.get("daily_symbol_risk_rule_enabled"), False) != (signal_stage == "funded"):
        if signal_stage == "challenge" and safe_bool(signal.get("daily_symbol_risk_rule_enabled"), False):
            return False, "challenge_signal_enables_funded_symbol_rule", None
    expected_variant_hash = str(signal.get("selected_variant_contract_hash") or "")
    if expected_variant_hash != str((edge.get("selected_variant_contract_hash") or current_hashes.get("selected_variant_contract_hash") or "")):
        return False, "selected_variant_contract_hash_mismatch", None

    cp = safe_float(signal.get("calibrated_probability"), None)
    thr = safe_float(signal.get("final_live_threshold"), None)
    if cp is None or thr is None:
        return False, "missing_probability_or_threshold", None
    if cp + 1e-12 < thr:
        return False, f"calibrated_probability_below_threshold:{cp:.8f}<{thr:.8f}", None
    if not safe_bool(signal.get("probability_passes_final_threshold"), True):
        return False, "probability_passes_final_threshold_false", None
    afml = safe_float(signal.get("afml_bet_size"), None)
    if afml is None or afml <= 0:
        return False, f"non_positive_afml_bet_size:{afml}", None
    side_value = safe_int(signal.get("side_value"), None)
    if side_value not in {-1, 1}:
        return False, f"invalid_side_value:{side_value}", None
    event_ts = ensure_utc_timestamp(signal.get("event_time"))
    if event_ts is None:
        return False, "invalid_event_time", None
    age = (utc_now_ts() - event_ts).total_seconds()
    if age < -FUTURE_SIGNAL_TOLERANCE_SECONDS:
        return False, f"future_event_time:{age:.1f}s", None
    if age > MAX_SIGNAL_AGE_SECONDS:
        return False, f"stale_signal:{age:.1f}s>{MAX_SIGNAL_AGE_SECONDS}s", None

    exec_plan, plan_reason = parse_execution_plan(signal)
    if exec_plan is None:
        return False, plan_reason, None

    # Execution-plan identity and edge-specific geometry are fail-closed.
    if str(exec_plan.get("edge_id", "")) != edge_id:
        return False, "execution_plan_edge_id_mismatch", None
    if str(exec_plan.get("asset", "")) != str(edge.get("asset", "")):
        return False, "execution_plan_asset_mismatch", None
    if safe_int(exec_plan.get("side_value"), None) != side_value:
        return False, "execution_plan_side_mismatch", None
    if str(exec_plan.get("edge_manifest_hash", "")) != str(edge.get("edge_manifest_hash", "")):
        return False, "execution_plan_edge_manifest_hash_mismatch", None

    geometry = edge.get("trade_geometry") if isinstance(edge.get("trade_geometry"), dict) else edge
    expected_geometry_hash = str(geometry.get("geometry_hash") or edge.get("geometry_hash") or "").strip()
    if not expected_geometry_hash:
        return False, "live_manifest_missing_geometry_hash", None
    if str(exec_plan.get("geometry_hash") or "") != expected_geometry_hash:
        return False, "execution_plan_geometry_hash_mismatch", None
    expected_pt = safe_float(geometry.get("pt_multiplier"), None)
    expected_sl = safe_float(geometry.get("sl_multiplier"), None)
    expected_vh = safe_int(geometry.get("vertical_horizon_bars"), None)
    plan_pt = safe_float(exec_plan.get("pt_multiplier"), None)
    plan_sl = safe_float(exec_plan.get("sl_multiplier"), None)
    plan_vh = safe_int(exec_plan.get("vertical_horizon_bars"), None)
    if expected_pt is None or expected_sl is None or expected_vh is None:
        return False, "live_manifest_incomplete_trade_geometry", None
    if plan_pt is None or not math.isclose(plan_pt, expected_pt, rel_tol=0.0, abs_tol=1e-10):
        return False, "execution_plan_pt_multiplier_mismatch", None
    if plan_sl is None or not math.isclose(plan_sl, expected_sl, rel_tol=0.0, abs_tol=1e-10):
        return False, "execution_plan_sl_multiplier_mismatch", None
    if plan_vh != expected_vh:
        return False, "execution_plan_vertical_horizon_mismatch", None
    dsl = safe_float(exec_plan.get("planned_sl_distance_price"), None)
    dtp = safe_float(exec_plan.get("planned_tp_distance_price"), None)
    if dsl is None or dtp is None or dsl <= 0 or dtp <= 0:
        return False, "execution_plan_missing_positive_distances", None
    if not math.isclose(dtp / dsl, expected_pt / expected_sl, rel_tol=1e-9, abs_tol=1e-9):
        return False, "execution_plan_reward_risk_ratio_mismatch", None
    return True, "ok", exec_plan



def order_type_for_side(mt5: Any, side_value: int) -> int:
    return mt5.ORDER_TYPE_BUY if int(side_value) == 1 else mt5.ORDER_TYPE_SELL


def side_name_from_value(side_value: int) -> str:
    return "long" if int(side_value) == 1 else "short"


def position_order_type(mt5: Any, position_type: int) -> int | None:
    if int(position_type) == int(mt5.POSITION_TYPE_BUY):
        return mt5.ORDER_TYPE_BUY
    if int(position_type) == int(mt5.POSITION_TYPE_SELL):
        return mt5.ORDER_TYPE_SELL
    return None


def parse_comment_metadata(comment: str) -> dict[str, Any]:
    out = {"asset": None, "family": "UNKNOWN", "edge_id": "UNKNOWN", "metadata_source": "comment_parse"}
    try:
        parts = str(comment or "").split("|")
        if len(parts) >= 3 and parts[0] == "V2P":
            out["asset"] = parts[1]
            out["family"] = parts[2]
    except Exception:
        pass
    return out


def metadata_key(value: Any) -> str:
    """Normalize MT5/order/deal/comment keys for persistent metadata maps."""
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    text = str(value).strip()
    if not text or text.lower() in {"nan", "none", "null"}:
        return ""
    try:
        val = float(text)
        if math.isfinite(val) and abs(val - round(val)) < 1e-9:
            return str(int(round(val)))
    except Exception:
        pass
    return text


def compact_family_code(family: str) -> str:
    cleaned = "".join(ch for ch in str(family or "edge").upper() if ch.isalnum())
    return (cleaned[:6] or "EDGE")


def compact_asset_code(asset: str) -> str:
    cleaned = "".join(ch for ch in str(asset or "").upper() if ch.isalnum())
    if cleaned == "NASDAQ":
        return "NAS"
    if cleaned == "XAUUSD":
        return "XAU"
    if cleaned == "BTCUSD":
        return "BTC"
    return (cleaned[:6] or "ASSET")


def signal_hash_suffix(signal_id: str, length: int = 6) -> str:
    raw = str(signal_id or "").strip()
    if not raw:
        raw = utc_now()
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:length]


def make_position_metadata(plan: "OrderPlan", signal: dict[str, Any], result: Any = None) -> dict[str, Any]:
    return {
        "signal_id": plan.signal_id,
        "edge_id": plan.edge_id,
        "asset": plan.asset,
        "symbol": plan.symbol,
        "family": plan.family,
        "side_name": plan.side_name,
        "side_value": plan.side_value,
        "event_time": signal.get("event_time"),
        "model_target_risk_pct": plan.model_target_risk_pct,
        "model_target_risk_usd": plan.model_target_risk_usd,
        "target_risk_pct": plan.target_risk_pct,
        "target_risk_usd": plan.target_risk_usd,
        "actual_risk_usd_at_entry": plan.actual_risk_usd,
        "actual_risk_pct_at_entry": plan.actual_risk_pct,
        "volume": plan.volume,
        "entry_price": plan.entry_price,
        "stop_loss": plan.stop_loss,
        "take_profit": plan.take_profit,
        "geometry_hash": plan.geometry_hash,
        "pt_multiplier": plan.pt_multiplier,
        "sl_multiplier": plan.sl_multiplier,
        "reward_risk_ratio": plan.reward_risk_ratio,
        "vertical_horizon_bars": plan.vertical_horizon_bars,
        # Research/live barrier anchor. The horizon remains event-bar based.
        "entry_event_time": signal.get("event_time"),
        # Separate execution timestamp for causal safety diagnostics. This is
        # refined to the broker position open time once MT5 exposes the fill.
        "order_send_completed_at": utc_now(),
        "position_open_time": None,
        "risk_contract_hash": plan.risk_contract_hash,
        "order": getattr(result, "order", None) if result is not None else None,
        "deal": getattr(result, "deal", None) if result is not None else None,
        "comment": plan.comment,
        "execution_plan_hash": plan.execution_plan_hash,
        "live_manifest_hash": plan.live_manifest_hash,
        "edge_manifest_hash": plan.edge_manifest_hash,
        "bar_policy_hash": plan.bar_policy_hash,
        "metadata_source": "execution_bot_order_plan",
        "created_at": utc_now(),
    }


def _metadata_edge_id(meta: dict[str, Any] | None) -> str:
    if not isinstance(meta, dict):
        return ""
    return str(meta.get("edge_id") or "").strip()


def _register_metadata_map(
    state: dict[str, Any],
    map_name: str,
    key: Any,
    metadata: dict[str, Any],
    *,
    ambiguity_map_name: str | None = None,
) -> None:
    k = metadata_key(key)
    if not k:
        return
    mapping = state.setdefault(map_name, {})
    existing = mapping.get(k)
    new_edge = _metadata_edge_id(metadata)
    old_edge = _metadata_edge_id(existing)
    if existing and old_edge and new_edge and old_edge != new_edge:
        if ambiguity_map_name:
            state.setdefault(ambiguity_map_name, {})[k] = {
                "created_at": utc_now(),
                "reason": "same_metadata_key_multiple_edge_ids",
                "old_edge_id": old_edge,
                "new_edge_id": new_edge,
                "metadata_key": k,
                "map_name": map_name,
            }
            mapping.pop(k, None)
        return
    mapping[k] = metadata


def register_position_metadata(
    state: dict[str, Any],
    metadata: dict[str, Any],
    *,
    ticket: Any = None,
    comment: Any = None,
    order: Any = None,
    deal: Any = None,
    signal_id: Any = None,
) -> None:
    """Persist full edge attribution under every key MT5/audits may expose."""
    if not isinstance(metadata, dict) or not _metadata_edge_id(metadata):
        return
    _register_metadata_map(state, "open_position_metadata_by_ticket", ticket, metadata)
    _register_metadata_map(
        state,
        "open_position_metadata_by_comment",
        comment or metadata.get("comment"),
        metadata,
        ambiguity_map_name="ambiguous_position_metadata_comments",
    )
    _register_metadata_map(state, "open_position_metadata_by_order", order or metadata.get("order"), metadata)
    _register_metadata_map(state, "open_position_metadata_by_deal", deal or metadata.get("deal"), metadata)
    _register_metadata_map(state, "open_position_metadata_by_signal_id", signal_id or metadata.get("signal_id"), metadata)


def metadata_from_execution_output_row(row: dict[str, Any]) -> dict[str, Any] | None:
    edge_id = str(row.get("plan_edge_id") or row.get("edge_id") or "").strip()
    signal_id = str(row.get("plan_signal_id") or row.get("signal_id") or "").strip()
    comment = str(row.get("plan_comment") or row.get("comment") or "").strip()
    if not edge_id or edge_id.upper() == "UNKNOWN":
        return None
    return {
        "signal_id": signal_id,
        "edge_id": edge_id,
        "asset": row.get("plan_asset") or row.get("asset"),
        "symbol": row.get("plan_symbol") or row.get("symbol"),
        "family": row.get("plan_family") or row.get("family") or "UNKNOWN",
        "side_name": row.get("plan_side_name"),
        "side_value": row.get("plan_side_value") or row.get("side_value"),
        "event_time": row.get("event_time"),
        "model_target_risk_pct": row.get("plan_model_target_risk_pct") or row.get("model_target_risk_pct"),
        "model_target_risk_usd": row.get("plan_model_target_risk_usd") or row.get("model_target_risk_usd"),
        "target_risk_pct": row.get("plan_target_risk_pct"),
        "target_risk_usd": row.get("plan_target_risk_usd"),
        "actual_risk_usd_at_entry": row.get("plan_actual_risk_usd"),
        "actual_risk_pct_at_entry": row.get("plan_actual_risk_pct"),
        "volume": row.get("plan_volume"),
        "entry_price": row.get("plan_entry_price"),
        "stop_loss": row.get("plan_stop_loss"),
        "take_profit": row.get("plan_take_profit"),
        "vertical_horizon_bars": row.get("plan_vertical_horizon_bars"),
        "entry_event_time": row.get("event_time"),
        "order_send_completed_at": row.get("created_at"),
        "position_open_time": row.get("position_open_time"),
        "order": row.get("order"),
        "deal": row.get("deal"),
        "comment": comment,
        "execution_plan_hash": row.get("plan_execution_plan_hash") or row.get("execution_plan_hash"),
        "live_manifest_hash": row.get("plan_live_manifest_hash") or row.get("live_manifest_hash"),
        "edge_manifest_hash": row.get("plan_edge_manifest_hash") or row.get("edge_manifest_hash"),
        "bar_policy_hash": row.get("plan_bar_policy_hash") or row.get("bar_policy_hash"),
        "metadata_source": "execution_output_backfill",
        "created_at": utc_now(),
    }


def backfill_position_metadata_from_execution_outputs(state: dict[str, Any]) -> None:
    """Recover metadata maps from prior execution CSV/JSONL outputs.

    This is intentionally best-effort. It is used to recover full edge_id
    attribution after restarts and for older positions whose MT5 comment could
    not encode the full edge id.
    """
    rows: list[dict[str, Any]] = []

    if EXECUTED_TRADES_CSV.exists():
        try:
            df = pd.read_csv(EXECUTED_TRADES_CSV)
            if not df.empty:
                rows.extend(df.to_dict("records"))
        except Exception:
            pass

    jsonl_path = BOT_OUTPUT_DIR / "portfolio_executed_trades.jsonl"
    if jsonl_path.exists():
        try:
            with jsonl_path.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        payload = json.loads(line)
                        if isinstance(payload, dict):
                            rows.append(payload)
        except Exception:
            pass

    for row in rows[-5000:]:
        metadata = metadata_from_execution_output_row(row)
        if not metadata:
            continue
        register_position_metadata(
            state,
            metadata,
            ticket=row.get("position") or row.get("ticket"),
            comment=metadata.get("comment"),
            order=metadata.get("order"),
            deal=metadata.get("deal"),
            signal_id=metadata.get("signal_id"),
        )


def resolve_position_metadata(position: Any, state: dict[str, Any]) -> tuple[dict[str, Any], str]:
    ticket = metadata_key(getattr(position, "ticket", None))
    identifier = metadata_key(getattr(position, "identifier", None))
    comment = metadata_key(getattr(position, "comment", None))

    lookup_order = [
        ("ticket", state.setdefault("open_position_metadata_by_ticket", {}).get(ticket)),
        ("identifier_as_ticket", state.setdefault("open_position_metadata_by_ticket", {}).get(identifier)),
        ("comment", state.setdefault("open_position_metadata_by_comment", {}).get(comment)),
        ("order", state.setdefault("open_position_metadata_by_order", {}).get(ticket)),
        ("deal", state.setdefault("open_position_metadata_by_deal", {}).get(ticket)),
        ("identifier_as_order", state.setdefault("open_position_metadata_by_order", {}).get(identifier)),
        ("identifier_as_deal", state.setdefault("open_position_metadata_by_deal", {}).get(identifier)),
    ]
    for source, meta in lookup_order:
        if isinstance(meta, dict) and _metadata_edge_id(meta) and _metadata_edge_id(meta).upper() != "UNKNOWN":
            out = dict(meta)
            out["metadata_source"] = source
            # Promote resolved ticket for faster future snapshots.
            register_position_metadata(
                state,
                out,
                ticket=ticket,
                comment=comment,
                order=out.get("order"),
                deal=out.get("deal"),
                signal_id=out.get("signal_id"),
            )
            return out, source

    parsed = parse_comment_metadata(comment)
    return parsed, "comment_parse_fallback"

def estimate_position_risk_usd(mt5: Any, position: Any, logger: Any) -> tuple[float | None, str]:
    symbol = str(position.symbol)
    volume = float(position.volume)
    entry = float(position.price_open)
    sl = safe_float(getattr(position, "sl", None), 0.0) or 0.0
    if sl <= 0:
        return None, "missing_stop_loss"
    otype = position_order_type(mt5, int(position.type))
    if otype is None:
        return None, "unknown_position_type"
    profit_at_sl = mt5.order_calc_profit(otype, symbol, volume, entry, sl)
    if profit_at_sl is None:
        logger.warning("OPEN_RISK_CALC_WARN ticket=%s symbol=%s error=%s", getattr(position, "ticket", ""), symbol, mt5.last_error())
        return None, "order_calc_profit_failed"
    return max(0.0, -float(profit_at_sl)), "ok"


def get_open_risk_snapshot(mt5: Any, manifest: dict[str, Any], state: dict[str, Any], logger: Any) -> dict[str, Any]:
    symbol_to_asset = universe_symbols(manifest)
    positions = mt5.positions_get()
    if positions is None:
        positions = []

    # Refresh maps from audit outputs before measuring risk. This is cheap for
    # the small execution log and protects per-edge caps after restarts.
    try:
        backfill_position_metadata_from_execution_outputs(state)
    except Exception as exc:
        logger.warning("POSITION_METADATA_BACKFILL_WARN error=%s", exc)

    risk_by_asset: dict[str, float] = {}
    risk_by_family: dict[str, float] = {}
    risk_by_edge: dict[str, float] = {}
    count_by_asset: dict[str, int] = {}
    count_by_edge: dict[str, int] = {}
    unknown_risk_positions: list[dict[str, Any]] = []
    total = 0.0
    unresolved_edge_metadata_count = 0

    for pos in positions:
        symbol = str(getattr(pos, "symbol", ""))
        if symbol not in symbol_to_asset:
            if not INCLUDE_UNMANAGED_POSITIONS_IN_RISK:
                continue
            # Unknown symbols cannot be bucketed against this universe, so skip unless later extended.
            continue
        asset = symbol_to_asset[symbol]
        ticket = str(getattr(pos, "ticket", ""))
        comment = str(getattr(pos, "comment", ""))

        meta, metadata_source = resolve_position_metadata(pos, state)
        family = str(meta.get("family") or "UNKNOWN")
        edge_id = str(meta.get("edge_id") or "UNKNOWN")
        if not meta.get("asset"):
            meta["asset"] = asset

        risk, reason = estimate_position_risk_usd(mt5, pos, logger)
        if risk is None:
            unknown_risk_positions.append({
                "ticket": ticket,
                "symbol": symbol,
                "asset": asset,
                "volume": float(getattr(pos, "volume", 0.0)),
                "comment": comment,
                "reason": reason,
                "metadata_source": metadata_source,
                "edge_id": edge_id,
                "family": family,
            })
            continue

        total += risk
        risk_by_asset[asset] = risk_by_asset.get(asset, 0.0) + risk
        risk_by_family[family] = risk_by_family.get(family, 0.0) + risk
        risk_by_edge[edge_id] = risk_by_edge.get(edge_id, 0.0) + risk
        count_by_asset[asset] = count_by_asset.get(asset, 0) + 1
        count_by_edge[edge_id] = count_by_edge.get(edge_id, 0) + 1

        if edge_id.upper() == "UNKNOWN":
            unresolved_edge_metadata_count += 1
            unknown_risk_positions.append({
                "ticket": ticket,
                "symbol": symbol,
                "asset": asset,
                "volume": float(getattr(pos, "volume", 0.0)),
                "comment": comment,
                "risk_usd": risk,
                "reason": "unresolved_edge_metadata",
                "metadata_source": metadata_source,
                "edge_id": edge_id,
                "family": family,
            })

    return {
        "total_open_risk_usd": total,
        "risk_by_asset": risk_by_asset,
        "risk_by_family": risk_by_family,
        "risk_by_edge": risk_by_edge,
        "count_by_asset": count_by_asset,
        "count_by_edge": count_by_edge,
        "unknown_risk_positions": unknown_risk_positions,
        "unresolved_edge_metadata_count": unresolved_edge_metadata_count,
        "position_count_considered": len(positions),
        "metadata_map_counts": {
            "ticket": len(state.get("open_position_metadata_by_ticket", {})),
            "comment": len(state.get("open_position_metadata_by_comment", {})),
            "order": len(state.get("open_position_metadata_by_order", {})),
            "deal": len(state.get("open_position_metadata_by_deal", {})),
            "signal_id": len(state.get("open_position_metadata_by_signal_id", {})),
            "ambiguous_comments": len(state.get("ambiguous_position_metadata_comments", {})),
        },
    }

def get_fill_type(mt5: Any, symbol: str) -> int:
    info = mt5.symbol_info(symbol)
    if info is None:
        return mt5.ORDER_FILLING_FOK
    mode = int(getattr(info, "filling_mode", mt5.ORDER_FILLING_FOK))
    if mode == getattr(mt5, "ORDER_FILLING_IOC", -1):
        return mt5.ORDER_FILLING_IOC
    if mode == getattr(mt5, "ORDER_FILLING_FOK", -1):
        return mt5.ORDER_FILLING_FOK
    if hasattr(mt5, "ORDER_FILLING_RETURN") and mode == getattr(mt5, "ORDER_FILLING_RETURN"):
        return mt5.ORDER_FILLING_RETURN
    try:
        if mode & mt5.ORDER_FILLING_IOC:
            return mt5.ORDER_FILLING_IOC
        if mode & mt5.ORDER_FILLING_FOK:
            return mt5.ORDER_FILLING_FOK
    except Exception:
        pass
    if hasattr(mt5, "ORDER_FILLING_RETURN"):
        return mt5.ORDER_FILLING_RETURN
    return mt5.ORDER_FILLING_FOK


def cached_filling_mode(state: dict[str, Any] | None, symbol: str) -> int | None:
    if not isinstance(state, dict):
        return None
    return safe_int((state.get("preferred_filling_mode_by_symbol") or {}).get(str(symbol)), None)


def remember_filling_mode(state: dict[str, Any] | None, symbol: str, mode: Any) -> None:
    if not isinstance(state, dict):
        return
    parsed = safe_int(mode, None)
    if parsed is None:
        return
    state.setdefault("preferred_filling_mode_by_symbol", {})[str(symbol)] = int(parsed)


def filling_mode_candidates(
    mt5: Any,
    symbol: str,
    preferred: int | None = None,
    state: dict[str, Any] | None = None,
) -> list[int]:
    """Return safe filling modes, preferring the last broker-accepted mode."""
    candidates: list[int] = []

    def _add(value: Any) -> None:
        try:
            mode = int(value)
        except Exception:
            return
        if mode not in candidates:
            candidates.append(mode)

    _add(cached_filling_mode(state, symbol))
    if preferred is not None:
        _add(preferred)

    try:
        _add(get_fill_type(mt5, symbol))
    except Exception:
        pass

    for name in ["ORDER_FILLING_IOC", "ORDER_FILLING_FOK", "ORDER_FILLING_RETURN"]:
        if hasattr(mt5, name):
            _add(getattr(mt5, name))

    return candidates


def is_invalid_fill_result(mt5: Any, result: Any) -> bool:
    """True only for broker rejection caused by unsupported filling mode."""
    if result is None:
        return False
    retcode = getattr(result, "retcode", None)
    try:
        if int(retcode) == int(getattr(mt5, "TRADE_RETCODE_INVALID_FILL")):
            return True
    except Exception:
        pass
    comment = str(getattr(result, "comment", "") or "").lower()
    return "unsupported filling" in comment or "invalid fill" in comment


def transient_order_result_reason(mt5: Any, result: Any) -> str | None:
    """Classify explicit no-execution broker conditions that are safe to retry."""
    if result is None:
        return None

    retcode = safe_int(getattr(result, "retcode", None), None)
    retname = get_retcode_name(mt5, retcode)
    comment = str(getattr(result, "comment", "") or "").strip().lower()

    retryable_names = {
        "TRADE_RETCODE_CONNECTION",
        "TRADE_RETCODE_TIMEOUT",
        "TRADE_RETCODE_PRICE_OFF",
        "TRADE_RETCODE_TOO_MANY_REQUESTS",
        "TRADE_RETCODE_LOCKED",
        "TRADE_RETCODE_MARKET_CLOSED",
    }
    if retname in retryable_names:
        return f"{retname}:{comment or 'temporary_broker_condition'}"

    explicit_no_connection = [
        "absence of network connection",
        "no connection",
        "not connected",
        "connection lost",
        "trade server unavailable",
        "server unavailable",
        "temporarily unavailable",
    ]
    if any(token in comment for token in explicit_no_connection):
        if not getattr(result, "order", None) and not getattr(result, "deal", None):
            return f"{retname or retcode}:{comment}"
    return None


def reconcile_prior_transient_order(
    mt5: Any,
    plan: OrderPlan,
    state: dict[str, Any],
    logger: Any,
) -> Any | None:
    """Detect a fill that may have completed despite a prior timeout response.

    Exact comment, symbol and magic matching prevents a timeout retry from
    duplicating an already-opened order. Connection/no-price failures normally
    find nothing and proceed to the normal retry path.
    """
    retry = (state.get("transient_order_retry_by_signal") or {}).get(plan.signal_id)
    if not isinstance(retry, dict) or not retry:
        return None

    expected_comment = str(retry.get("comment") or plan.comment or "")[:31]
    expected_symbol = str(retry.get("symbol") or plan.symbol or "")
    expected_magic = int(plan.magic)

    try:
        positions = mt5.positions_get(symbol=expected_symbol)
        if positions is None:
            positions = mt5.positions_get() or []
        for position in positions or []:
            if str(getattr(position, "symbol", "") or "") != expected_symbol:
                continue
            if int(getattr(position, "magic", -1) or -1) != expected_magic:
                continue
            if str(getattr(position, "comment", "") or "")[:31] != expected_comment:
                continue
            ticket = int(getattr(position, "ticket", 0) or 0)
            logger.warning(
                "TRANSIENT_ORDER_RECONCILED signal_id=%s symbol=%s source=open_position ticket=%s",
                plan.signal_id,
                expected_symbol,
                ticket,
            )
            return SimpleNamespace(
                retcode=int(mt5.TRADE_RETCODE_DONE),
                order=ticket,
                deal=0,
                comment="reconciled_existing_position_after_transient_result",
            )
    except Exception as exc:
        logger.warning(
            "TRANSIENT_ORDER_RECONCILE_POSITION_WARN signal_id=%s symbol=%s error=%s",
            plan.signal_id,
            expected_symbol,
            exc,
        )

    last_attempt = ensure_utc_timestamp(retry.get("last_attempt_at"))
    if last_attempt is None:
        return None
    history_start = (last_attempt - pd.Timedelta(seconds=10)).to_pydatetime()
    history_end = datetime.now(timezone.utc)
    try:
        deals = mt5.history_deals_get(history_start, history_end) or []
        for deal in deals:
            if str(getattr(deal, "symbol", "") or "") != expected_symbol:
                continue
            if int(getattr(deal, "magic", -1) or -1) != expected_magic:
                continue
            if str(getattr(deal, "comment", "") or "")[:31] != expected_comment:
                continue
            order_ticket = int(getattr(deal, "order", 0) or 0)
            deal_ticket = int(getattr(deal, "ticket", 0) or 0)
            logger.warning(
                "TRANSIENT_ORDER_RECONCILED signal_id=%s symbol=%s source=deal_history order=%s deal=%s",
                plan.signal_id,
                expected_symbol,
                order_ticket,
                deal_ticket,
            )
            return SimpleNamespace(
                retcode=int(mt5.TRADE_RETCODE_DONE),
                order=order_ticket,
                deal=deal_ticket,
                comment="reconciled_deal_after_transient_result",
            )
    except Exception as exc:
        logger.warning(
            "TRANSIENT_ORDER_RECONCILE_HISTORY_WARN signal_id=%s symbol=%s error=%s",
            plan.signal_id,
            expected_symbol,
            exc,
        )
    return None


def record_transient_order_retry(
    state: dict[str, Any],
    plan: OrderPlan,
    result: Any,
    reason: str,
) -> dict[str, Any]:
    retries = state.setdefault("transient_order_retry_by_signal", {})
    prior = retries.get(plan.signal_id) or {}
    attempt_count = int(prior.get("attempt_count", 0) or 0) + 1
    delay = min(
        TRANSIENT_ORDER_RETRY_MAX_SECONDS,
        TRANSIENT_ORDER_RETRY_INITIAL_SECONDS * (2 ** max(attempt_count - 1, 0)),
    )
    next_retry = utc_now_ts() + pd.Timedelta(seconds=float(delay))
    record = {
        "signal_id": plan.signal_id,
        "symbol": plan.symbol,
        "comment": plan.comment,
        "attempt_count": attempt_count,
        "last_reason": reason,
        "last_retcode": getattr(result, "retcode", None) if result is not None else None,
        "last_attempt_at": utc_now(),
        "next_retry_at": next_retry.isoformat(),
        "retry_delay_seconds": float(delay),
    }
    retries[plan.signal_id] = record
    return record


def clear_transient_order_retry(state: dict[str, Any], signal_id: str) -> None:
    state.setdefault("transient_order_retry_by_signal", {}).pop(str(signal_id), None)


def summarize_order_attempt(mt5: Any, result: Any, type_filling: int) -> dict[str, Any]:
    retcode = getattr(result, "retcode", None) if result is not None else None
    return {
        "type_filling": int(type_filling),
        "retcode": retcode,
        "retcode_name": get_retcode_name(mt5, retcode),
        "comment": getattr(result, "comment", "order_send returned None") if result is not None else "order_send returned None",
        "order": getattr(result, "order", None) if result is not None else None,
        "deal": getattr(result, "deal", None) if result is not None else None,
    }



def stable_json_hash(value: Any) -> str:
    compact = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str, allow_nan=False)
    return hashlib.sha256(compact.encode("utf-8")).hexdigest()


def resolve_manifest_source_path(manifest: dict[str, Any]) -> Path:
    raw = str(manifest.get("source") or "").strip()
    if not raw:
        raise RuntimeError("live_manifest_missing_allocator_source")
    path = Path(raw)
    if not path.is_absolute():
        path = V2_ROOT / path
    if not path.exists():
        raise FileNotFoundError(f"allocator_source_not_found:{path}")
    expected = str((manifest.get("source_hash") or {}).get("sha256") or "").strip()
    if not expected:
        raise RuntimeError("live_manifest_missing_allocator_source_hash")
    actual = sha256_file(path)
    if actual != expected:
        raise RuntimeError(f"allocator_source_hash_mismatch:{actual}!={expected}")
    return path


def _same_tiers(a: Any, b: Any) -> bool:
    def norm(rows: Any) -> list[list[float]]:
        out: list[list[float]] = []
        for item in rows or []:
            if isinstance(item, dict):
                floor = safe_float(item.get("floor") or item.get("balance_floor") or item.get("threshold"), None)
                mult = safe_float(item.get("multiplier") or item.get("mult"), None)
            elif isinstance(item, (list, tuple)) and len(item) >= 2:
                floor = safe_float(item[0], None); mult = safe_float(item[1], None)
            else:
                continue
            if floor is not None and mult is not None:
                out.append([float(floor), float(mult)])
        return out
    return norm(a) == norm(b)


def load_prop_risk_contract(manifest: dict[str, Any]) -> dict[str, Any]:
    """Load the allocator-selected stage-aware account/risk contract."""
    source_path = resolve_manifest_source_path(manifest)
    source = read_json_object(source_path)
    variant = source.get("selected_variant") or {}
    rules = source.get("atmos_nova_rule_contract") or source.get("prop_rule_contract") or source.get("account_rule_contract") or {}
    if not isinstance(variant, dict) or not variant: raise RuntimeError("allocator_source_missing_selected_variant")
    if not isinstance(rules, dict) or not rules: raise RuntimeError("allocator_source_missing_account_rule_contract")
    cap_keys = ["base_portfolio_risk_budget_pct", "max_single_trade_risk_pct", "max_total_open_risk_pct", "max_asset_open_risk_pct", "max_family_open_risk_pct", "max_edge_open_risk_pct", "max_open_trades_per_edge", "max_open_trades_per_asset"]
    root_caps = manifest.get("risk_caps") or {}
    for key in cap_keys:
        if key not in variant or key not in root_caps: raise RuntimeError(f"risk_contract_missing_cap:{key}")
        if not math.isclose(float(variant[key]), float(root_caps[key]), rel_tol=0.0, abs_tol=1e-12): raise RuntimeError(f"risk_contract_cap_drift:{key}:{root_caps[key]}!={variant[key]}")
    m_throttle = manifest.get("throttle_config") or {}
    if not _same_tiers(m_throttle.get("throttle_tiers"), variant.get("throttle_tiers")): raise RuntimeError("risk_contract_throttle_tiers_drift")
    if not math.isclose(float(m_throttle.get("pause_below_balance")), float(variant.get("pause_below_balance")), rel_tol=0.0, abs_tol=1e-9): raise RuntimeError("risk_contract_pause_floor_drift")
    account_stage = str(source.get("approved_account_stage") or source.get("account_stage") or rules.get("account_stage") or manifest.get("approved_account_stage") or "").strip().lower()
    symbol_rule_enabled = safe_bool(source.get("daily_symbol_risk_rule_enabled"), safe_bool(rules.get("daily_symbol_risk_rule_enabled"), account_stage == "funded"))
    if account_stage == "challenge" and symbol_rule_enabled: raise RuntimeError("challenge_contract_enables_funded_symbol_rule")
    start = float(rules.get("starting_capital"))
    max_loss_pct = safe_float(rules.get("max_overall_loss_pct"), None)
    max_loss_amount_contract = safe_float(rules.get("max_overall_loss_amount"), None)
    if max_loss_pct is None:
        if max_loss_amount_contract is None or start <= 0:
            raise RuntimeError("risk_contract_missing_max_overall_loss_pct")
        max_loss_pct = float(max_loss_amount_contract) / float(start)
    max_loss_pct = float(max_loss_pct)
    # Accept either fractional form (0.08) or percentage-points form (8).
    if 1.0 <= max_loss_pct <= 100.0:
        max_loss_pct /= 100.0
    if max_loss_pct <= 0 or max_loss_pct >= 1:
        raise RuntimeError(f"invalid_max_overall_loss_pct:{max_loss_pct}")
    approval_scope_for_max_loss = str(
        source.get("live_approval_scope") or manifest.get("live_approval_scope") or ""
    ).strip()
    if approval_scope_for_max_loss == EXPECTED_CHALLENGE_SCOPE and not math.isclose(
        max_loss_pct, 0.08, rel_tol=0.0, abs_tol=1e-12
    ):
        raise RuntimeError(f"nova_max_overall_loss_pct_must_be_0.08:{max_loss_pct}")
    max_loss_amount_at_plan_size = float(start) * max_loss_pct
    if max_loss_amount_contract is not None and not math.isclose(
        float(max_loss_amount_contract),
        max_loss_amount_at_plan_size,
        rel_tol=0.0,
        abs_tol=0.01,
    ):
        raise RuntimeError(
            "max_overall_loss_contract_pct_amount_mismatch:"
            f"amount={max_loss_amount_contract},pct_amount={max_loss_amount_at_plan_size}"
        )
    profit_target_pct = safe_float(rules.get("profit_target_pct"), None)
    target_balance = safe_float(rules.get("target_balance"), None)
    if target_balance is None and profit_target_pct is not None: target_balance = start * (1.0 + profit_target_pct)
    # Daily loss is percentage-based. Preserve any allocator dollar field only
    # as a plan-size reference/check; runtime allowance is recalculated from the
    # broker-day starting balance on every risk day.
    daily_amount_contract = safe_float(variant.get("daily_drawdown_amount"), None)
    daily_pct = safe_float(DAILY_DRAWDOWN_PCT_OVERRIDE, None)
    if daily_pct is None:
        daily_pct = safe_float(
            source.get("daily_drawdown_pct"),
            safe_float(
                source.get("daily_loss_pct"),
                safe_float(
                    rules.get("daily_loss_pct"),
                    safe_float(variant.get("daily_drawdown_pct"), safe_float(manifest.get("daily_drawdown_pct"), None)),
                ),
            ),
        )
    if daily_pct is None and daily_amount_contract is not None and start > 0:
        daily_pct = float(daily_amount_contract) / float(start)
    daily_pct = float(daily_pct or 0.0)
    # Accept either fractional form (0.04) or percentage-points form (4).
    if 1.0 <= daily_pct <= 100.0:
        daily_pct /= 100.0
    if daily_pct < 0 or daily_pct >= 1:
        raise RuntimeError(f"invalid_daily_drawdown_pct:{daily_pct}")
    approval_scope = str(source.get("live_approval_scope") or manifest.get("live_approval_scope") or "").strip()
    if approval_scope == EXPECTED_CHALLENGE_SCOPE and not math.isclose(daily_pct, 0.04, rel_tol=0.0, abs_tol=1e-12):
        raise RuntimeError(f"nova_daily_drawdown_pct_must_be_0.04:{daily_pct}")
    daily_amount_at_plan_size = float(start) * daily_pct
    if daily_amount_contract is not None and daily_pct > 0:
        if not math.isclose(float(daily_amount_contract), daily_amount_at_plan_size, rel_tol=0.0, abs_tol=0.01):
            raise RuntimeError(
                f"daily_drawdown_contract_pct_amount_mismatch:"
                f"amount={daily_amount_contract},pct_amount={daily_amount_at_plan_size}"
            )
    reserve = safe_float(variant.get("trailing_buffer_fixed_reserve_amount"), safe_float(variant.get("trailing_buffer_reserve_amount"), 0.0)) or 0.0
    trailing_allowance = float(variant.get("trailing_buffer_cost_allowance_r", 0.0) or 0.0)
    daily_buffer_admission_enabled = safe_bool(
        variant.get("daily_buffer_admission_enabled"),
        bool(variant.get("daily_drawdown_enabled", daily_pct > 0))
        and bool(variant.get("trailing_buffer_admission_enabled", False)),
    )
    daily_buffer_reserve_mode = str(
        variant.get("daily_buffer_reserve_mode")
        or variant.get("trailing_buffer_reserve_mode")
        or "off"
    )
    daily_buffer_reserve_amount = safe_float(
        variant.get("daily_buffer_fixed_reserve_amount"),
        reserve if daily_buffer_admission_enabled else 0.0,
    ) or 0.0
    daily_buffer_cost_allowance_r = safe_float(
        variant.get("daily_buffer_cost_allowance_r"),
        trailing_allowance if daily_buffer_admission_enabled else 0.0,
    ) or 0.0
    internal_symbol = safe_float(variant.get("internal_operating_risk_per_symbol_amount"), safe_float(rules.get("internal_operating_risk_per_symbol_amount"), None))
    legal_symbol = safe_float(variant.get("max_daily_risk_per_symbol_amount"), safe_float(rules.get("max_daily_risk_per_symbol_amount"), None))
    stress_multiplier = max(1.0, safe_float(variant.get("symbol_risk_stress_multiplier"), safe_float(rules.get("symbol_risk_stress_multiplier"), DEFAULT_SYMBOL_RISK_STRESS_MULTIPLIER)) or DEFAULT_SYMBOL_RISK_STRESS_MULTIPLIER)
    if symbol_rule_enabled and (internal_symbol is None or legal_symbol is None): raise RuntimeError("funded_risk_contract_missing_symbol_limits")
    live_internal_symbol = min(float(internal_symbol), float(legal_symbol) / stress_multiplier) if symbol_rule_enabled else None
    normalized = {
        "source_path": str(source_path), "source_sha256": sha256_file(source_path),
        "account_rule_profile": str(source.get("account_rule_profile") or variant.get("account_rule_profile") or "allocator_selected"),
        "account_stage": account_stage, "live_approval_scope": str(source.get("live_approval_scope") or manifest.get("live_approval_scope") or ""),
        "daily_symbol_risk_rule_enabled": bool(symbol_rule_enabled),
        "daily_symbol_risk_enforcement_mode": str(source.get("daily_symbol_risk_enforcement_mode") or rules.get("daily_symbol_risk_enforcement_mode") or ("enforced" if symbol_rule_enabled else "observed_only_not_enforced")),
        "starting_capital": start, "profit_target_balance": target_balance,
        "drawdown_type": str(rules.get("drawdown_type") or "static"),
        "max_overall_loss_pct": float(max_loss_pct),
        # Backward-compatible plan-size amount; runtime trailing distance compounds from equity HWM.
        "max_overall_loss_amount": float(max_loss_amount_at_plan_size),
        "max_overall_loss_amount_at_plan_size": float(max_loss_amount_at_plan_size),
        "max_overall_loss_basis": "highest_observed_equity",
        "initial_floor": start * (1.0 - float(max_loss_pct)),
        "stop_trailing_at_balance": start if str(rules.get("drawdown_type")) == "trailing_stops_at_initial_balance" else None,
        "daily_drawdown_enabled": bool(variant.get("daily_drawdown_enabled", daily_pct > 0)),
        "daily_drawdown_pct": float(daily_pct),
        # Backward-compatible reference amount at plan size; not the runtime day allowance.
        "daily_drawdown_amount": float(daily_amount_at_plan_size),
        "daily_drawdown_amount_at_plan_size": float(daily_amount_at_plan_size),
        "daily_drawdown_basis": "broker_day_start_balance",
        "daily_reset_timezone": str(source.get("daily_reset_timezone") or manifest.get("daily_reset_timezone") or "broker_server_time"),
        "daily_reset_offset_hours": float(source.get("daily_reset_offset_hours", manifest.get("daily_reset_offset_hours", 0.0)) or 0.0),
        "internal_symbol_risk_amount": float(internal_symbol) if internal_symbol is not None else None,
        "live_internal_symbol_risk_amount": float(live_internal_symbol) if live_internal_symbol is not None else None,
        "legal_symbol_risk_amount": float(legal_symbol) if legal_symbol is not None else None,
        "symbol_risk_stress_multiplier": float(stress_multiplier),
        "symbol_risk_mode": str(rules.get("symbol_risk_mode") or "closed_losses_plus_floating_stop_risk"),
        "trailing_buffer_admission_enabled": bool(variant.get("trailing_buffer_admission_enabled", False)),
        "trailing_buffer_reserve_mode": str(variant.get("trailing_buffer_reserve_mode") or "off"),
        "trailing_buffer_reserve_amount": float(reserve), "trailing_buffer_cost_allowance_r": float(trailing_allowance),
        "daily_buffer_admission_enabled": bool(daily_buffer_admission_enabled),
        "daily_buffer_reserve_mode": daily_buffer_reserve_mode,
        "daily_buffer_reserve_amount": float(daily_buffer_reserve_amount),
        "daily_buffer_cost_allowance_r": float(daily_buffer_cost_allowance_r),
        "throttle_basis": str(variant.get("throttle_basis") or "account_balance"), "throttle_tiers": variant.get("throttle_tiers") or [],
        "pause_below_balance": float(variant.get("pause_below_balance")), "target_lock_tiers": variant.get("target_lock_tiers") or [],
        "selected_variant_name": str(variant.get("name") or ""),
        "selected_variant_contract_hash": str((source.get("stress_integrity") or {}).get("selected_variant_contract_hash") or manifest.get("selected_variant_contract_hash") or ""),
    }
    normalized["risk_contract_hash"] = stable_json_hash({k: v for k, v in normalized.items() if k not in {"source_path", "source_sha256", "risk_contract_hash"}})
    return normalized


def risk_day_window_utc(now: datetime, offset_hours: float) -> tuple[datetime, datetime, str]:
    """Return the UTC window for one broker-server calendar day.

    ``offset_hours`` is broker server time minus UTC. For example, UTC+3 uses
    ``+3`` and therefore rolls over at 21:00 UTC.
    """
    shifted = now + timedelta(hours=float(offset_hours))
    shifted_start = datetime(shifted.year, shifted.month, shifted.day, tzinfo=timezone.utc)
    start = shifted_start - timedelta(hours=float(offset_hours))
    return start, now, shifted_start.date().isoformat()


def dashboard_broker_offset_hours(manifest: dict[str, Any]) -> tuple[float | None, str]:
    """Read the dashboard's locked broker-time offset without guessing.

    The dashboard already normalizes live broker timestamps and persists one
    locked offset per selected symbol. Reusing that authority prevents the
    executor from maintaining a second, drifting time-inference algorithm.
    """
    if not DASHBOARD_STATUS_JSON.exists():
        return None, "dashboard_status_missing"
    try:
        payload = read_json_object(DASHBOARD_STATUS_JSON)
    except Exception as exc:
        return None, f"dashboard_status_unreadable:{type(exc).__name__}"
    offsets = payload.get("broker_time_offset_seconds_by_symbol") or {}
    locked = payload.get("broker_time_offset_locked_by_symbol") or {}
    if not isinstance(offsets, dict) or not isinstance(locked, dict):
        return None, "dashboard_status_offset_contract_missing"
    selected_symbols = list(universe_symbols(manifest).keys())
    values: list[float] = []
    for symbol in selected_symbols:
        if locked.get(symbol) is not True:
            continue
        seconds = safe_float(offsets.get(symbol), None)
        if seconds is not None:
            values.append(float(seconds))
    if not values:
        return None, "dashboard_status_no_locked_selected_symbol_offset"
    # All selected symbols should share one broker server clock. Refuse a
    # materially inconsistent dashboard snapshot instead of silently averaging.
    if max(values) - min(values) > 1.0:
        return None, f"dashboard_status_inconsistent_offsets:{values}"
    return (sum(values) / len(values)) / 3600.0, "dashboard_locked_broker_time_offset"


def resolve_daily_reset_offset_hours(
    manifest: dict[str, Any],
    contract: dict[str, Any],
) -> tuple[float, str]:
    explicit = safe_float(DAILY_RESET_OFFSET_HOURS_OVERRIDE, None)
    if explicit is not None:
        return float(explicit), "settings.PORTFOLIO_DAILY_RESET_OFFSET_HOURS"
    dashboard_offset, dashboard_source = dashboard_broker_offset_hours(manifest)
    if dashboard_offset is not None:
        return float(dashboard_offset), dashboard_source
    return float(contract.get("daily_reset_offset_hours", 0.0) or 0.0), f"allocator_contract_fallback:{dashboard_source}"


def mt5_daily_trade_snapshot(
    mt5: Any,
    manifest: dict[str, Any],
    contract: dict[str, Any],
    now: datetime | None = None,
    *,
    effective_reset_offset_hours: float | None = None,
    reset_offset_source: str | None = None,
) -> dict[str, Any]:
    now = now or datetime.now(timezone.utc)
    offset = (
        float(effective_reset_offset_hours)
        if effective_reset_offset_hours is not None
        else float(contract.get("daily_reset_offset_hours", 0.0) or 0.0)
    )
    start, end, risk_day = risk_day_window_utc(now, offset)
    deals = mt5.history_deals_get(start, end)
    if deals is None:
        raise RuntimeError(f"mt5_history_deals_unavailable:{mt5.last_error()}")

    buy_type = int(getattr(mt5, "DEAL_TYPE_BUY", 0))
    sell_type = int(getattr(mt5, "DEAL_TYPE_SELL", 1))
    trading_adjustment_types = {
        int(value)
        for name in (
            "DEAL_TYPE_COMMISSION", "DEAL_TYPE_COMMISSION_DAILY",
            "DEAL_TYPE_COMMISSION_MONTHLY", "DEAL_TYPE_COMMISSION_AGENT_DAILY",
            "DEAL_TYPE_COMMISSION_AGENT_MONTHLY", "DEAL_TYPE_CHARGE",
            "DEAL_TYPE_INTEREST", "DEAL_TYPE_TAX",
        )
        if (value := getattr(mt5, name, None)) is not None
    }
    symbol_to_asset = universe_symbols(manifest)
    net_realized_trading_pnl = 0.0
    net_balance_change_since_day_start = 0.0
    separate_trading_adjustments = 0.0
    nontrading_balance_adjustments = 0.0
    closed_losses_by_asset: dict[str, float] = {}
    considered = 0
    trading_deals_considered = 0

    for deal in deals:
        deal_type = int(getattr(deal, "type", -999))
        net = sum(float(getattr(deal, key, 0.0) or 0.0) for key in ("profit", "commission", "swap", "fee"))
        # Every financial deal contributes to the actual balance movement used
        # to reconstruct the broker-day opening balance.
        net_balance_change_since_day_start += net
        considered += 1

        symbol = str(getattr(deal, "symbol", "") or "")
        if deal_type in {buy_type, sell_type}:
            net_realized_trading_pnl += net
            trading_deals_considered += 1
            if symbol and net < 0:
                asset = symbol_to_asset.get(symbol, symbol)
                closed_losses_by_asset[asset] = closed_losses_by_asset.get(asset, 0.0) + abs(net)
        elif deal_type in trading_adjustment_types:
            net_realized_trading_pnl += net
            separate_trading_adjustments += net
        else:
            nontrading_balance_adjustments += net

    return {
        # Keep legacy names for downstream symbol-risk code.
        "utc_day": risk_day,
        "utc_day_start": start.isoformat(),
        "risk_day": risk_day,
        "risk_day_start_utc": start.isoformat(),
        "risk_day_end_utc": end.isoformat(),
        "daily_reset_offset_hours": offset,
        "daily_reset_offset_source": reset_offset_source or "contract",
        "deals_considered": considered,
        "trading_deals_considered": trading_deals_considered,
        "net_realized_trading_pnl": float(net_realized_trading_pnl),
        "net_balance_change_since_day_start": float(net_balance_change_since_day_start),
        "separate_trading_adjustments": float(separate_trading_adjustments),
        "nontrading_balance_adjustments": float(nontrading_balance_adjustments),
        "closed_losses_by_asset": closed_losses_by_asset,
    }


def attach_prop_risk_context(
    mt5: Any,
    manifest: dict[str, Any],
    account: Any,
    open_risk: dict[str, Any],
    state: dict[str, Any],
) -> dict[str, Any]:
    contract = load_prop_risk_contract(manifest)
    effective_offset, offset_source = resolve_daily_reset_offset_hours(manifest, contract)
    daily = mt5_daily_trade_snapshot(
        mt5,
        manifest,
        contract,
        effective_reset_offset_hours=effective_offset,
        reset_offset_source=offset_source,
    )
    login = str(getattr(account, "login", ""))
    server = str(getattr(account, "server", ""))
    risk_state = state.setdefault("prop_risk_state", {})
    old_login = str(risk_state.get("account_login") or "")
    old_server = str(risk_state.get("account_server") or "")
    old_hash = str(risk_state.get("risk_contract_hash") or "")
    if old_login and old_login != login:
        raise RuntimeError(f"prop_risk_state_account_login_changed:{old_login}!={login}")
    if old_server and old_server != server:
        raise RuntimeError(f"prop_risk_state_account_server_changed:{old_server}!={server}")
    if old_hash and old_hash != contract["risk_contract_hash"]:
        # One-time migration from the previous fixed-dollar daily derivation.
        # Preserve the overall high-water mark, but invalidate the old daily
        # anchor because its percentage basis/day boundary may be different.
        old_derivation = str(risk_state.get("risk_contract_derivation_version") or "")
        if old_derivation == RISK_CONTRACT_DERIVATION_VERSION:
            raise RuntimeError("prop_risk_contract_changed_state_reset_required")
        if old_derivation not in {
            "",
            "v2_fixed_daily_drawdown_amount",
            "v2_percent_of_broker_day_start_balance",
        }:
            raise RuntimeError("prop_risk_contract_changed_state_reset_required")
        risk_state["previous_risk_contract_hash"] = old_hash
        risk_state["risk_contract_migrated_at"] = utc_now()
        for key in (
            "daily_anchor_utc_day", "daily_anchor_start_balance",
            "daily_anchor_created_at", "daily_anchor_reset_offset_hours",
        ):
            risk_state.pop(key, None)

    balance = float(account.balance)
    broker_equity = float(account.equity)
    total_open = float(open_risk.get("total_open_risk_usd", 0.0))
    starting_capital = float(contract["starting_capital"])
    max_overall_loss_pct = float(contract["max_overall_loss_pct"])

    prior_equity_hwm = safe_float(risk_state.get("equity_high_watermark"), None)
    hwm_source = "persisted_equity_high_watermark"
    if prior_equity_hwm is None:
        # One-time migration: the old bot persisted only realised balance HWM.
        # It cannot reconstruct unrecorded historical floating-equity peaks, so
        # seed conservatively from the highest trustworthy value available.
        legacy_balance_hwm = safe_float(
            risk_state.get("realized_balance_high_watermark"),
            starting_capital,
        ) or starting_capital
        prior_equity_hwm = max(starting_capital, float(legacy_balance_hwm), broker_equity)
        hwm_source = "migrated_from_legacy_balance_hwm_and_current_equity"
        state["equity_high_watermark_migration"] = {
            "created_at": utc_now(),
            "legacy_realized_balance_high_watermark": float(legacy_balance_hwm),
            "current_broker_equity": broker_equity,
            "seeded_equity_high_watermark": float(prior_equity_hwm),
        }

    equity_hwm = max(float(prior_equity_hwm), broker_equity, starting_capital)
    if equity_hwm > float(prior_equity_hwm) + 1e-9:
        hwm_source = "new_broker_equity_high_watermark"

    drawdown_type = str(contract["drawdown_type"])
    percentage_trailing_floor = equity_hwm * (1.0 - max_overall_loss_pct)
    initial_floor = float(contract["initial_floor"])
    if drawdown_type == "trailing_stops_at_initial_balance":
        floor = min(
            starting_capital,
            max(initial_floor, percentage_trailing_floor),
        )
    elif drawdown_type in {"continuously_trailing", "trailing"}:
        floor = max(initial_floor, percentage_trailing_floor)
    else:
        floor = initial_floor

    trailing_distance_amount_at_hwm = equity_hwm * max_overall_loss_pct
    actual_trailing_buffer = broker_equity - floor

    # Conservative admission asks where final balance would be if all currently
    # open positions ultimately close at their existing stop losses.
    projected_trailing_equity_proxy = balance - total_open
    projected_trailing_buffer = projected_trailing_equity_proxy - floor

    # Backward-compatible aliases preserve the allocator's existing fixed USD
    # throttle tiers and their simulation basis. They now consume the corrected
    # percentage/equity-HWM trailing floor.
    equity_proxy = projected_trailing_equity_proxy
    remaining_buffer = projected_trailing_buffer

    current_day = str(daily["risk_day"])
    anchored_day = str(risk_state.get("daily_anchor_utc_day") or "")
    anchored_start = safe_float(risk_state.get("daily_anchor_start_balance"), None)
    anchored_offset = safe_float(risk_state.get("daily_anchor_reset_offset_hours"), None)
    offset_matches = anchored_offset is not None and math.isclose(
        float(anchored_offset), float(effective_offset), rel_tol=0.0, abs_tol=1e-9
    )
    if anchored_day == current_day and anchored_start is not None and offset_matches:
        daily_start_balance = float(anchored_start)
        daily_start_balance_source = "persisted_broker_risk_day_anchor"
    else:
        # Reconstruct the exact balance at broker rollover from every balance-
        # affecting MT5 deal since the risk-day start. This remains stable across
        # restarts and includes separately booked commissions/fees/adjustments.
        daily_start_balance = balance - float(daily["net_balance_change_since_day_start"])
        daily_start_balance_source = "reconstructed_from_balance_minus_all_day_balance_changes"
        risk_state["daily_anchor_utc_day"] = current_day
        risk_state["daily_anchor_start_balance"] = float(daily_start_balance)
        risk_state["daily_anchor_created_at"] = utc_now()
        risk_state["daily_anchor_reset_offset_hours"] = float(effective_offset)

    daily_pct = float(contract.get("daily_drawdown_pct", 0.0) or 0.0)
    daily_limit_amount = float(daily_start_balance) * daily_pct
    daily_floor = float(daily_start_balance) - daily_limit_amount

    # Daily loss is P&L-based and equity-enforced:
    # remaining = allowance + (current equity - broker-day starting balance).
    daily_realized_balance_change = balance - float(daily_start_balance)
    daily_floating_pnl = broker_equity - balance
    daily_total_pnl = broker_equity - float(daily_start_balance)
    daily_pnl_reconciliation_error = daily_total_pnl - (
        daily_realized_balance_change + daily_floating_pnl
    )
    actual_daily_equity = broker_equity
    actual_daily_loss_remaining = daily_limit_amount + daily_total_pnl

    # Conservative new-trade admission remains separate: it asks what the
    # balance would be if all existing positions ultimately close at their SL.
    projected_daily_equity_proxy = equity_proxy
    projected_daily_total_pnl = projected_daily_equity_proxy - float(daily_start_balance)
    projected_daily_loss_remaining = daily_limit_amount + projected_daily_total_pnl

    daily = {
        **daily,
        "daily_start_balance": float(daily_start_balance),
        "daily_start_balance_source": daily_start_balance_source,
        "daily_drawdown_pct": daily_pct,
        "daily_limit_amount": daily_limit_amount,
        "daily_floor": daily_floor,
        "daily_realized_balance_change": daily_realized_balance_change,
        "daily_floating_pnl": daily_floating_pnl,
        "daily_total_pnl": daily_total_pnl,
        "daily_pnl_reconciliation_error": daily_pnl_reconciliation_error,
        "actual_daily_loss_remaining": actual_daily_loss_remaining,
        "projected_daily_loss_remaining_after_open_stops": projected_daily_loss_remaining,
    }

    lockouts = risk_state.setdefault("symbol_risk_lockout_utc_day_by_asset", {})
    if bool(contract.get("daily_symbol_risk_rule_enabled")):
        closed_by_asset = daily.get("closed_losses_by_asset", {}) or {}
        open_by_asset = open_risk.get("risk_by_asset", {}) or {}
        stress_mult = float(contract.get("symbol_risk_stress_multiplier", DEFAULT_SYMBOL_RISK_STRESS_MULTIPLIER))
        legal_cap = float(contract.get("legal_symbol_risk_amount"))
        for asset in sorted(set(closed_by_asset) | set(open_by_asset)):
            closed_loss = float(closed_by_asset.get(asset, 0.0))
            open_stop = float(open_by_asset.get(asset, 0.0))
            if (
                closed_loss + open_stop >= legal_cap - 1e-9
                or closed_loss + stress_mult * open_stop >= legal_cap - 1e-9
            ):
                lockouts[str(asset)] = daily["utc_day"]
    else:
        lockouts.clear()

    context = {
        **contract,
        "account_login": login,
        "account_server": server,
        "balance": balance,
        "broker_equity": broker_equity,
        "total_open_stop_risk": total_open,
        # Legacy balance-HWM field retained for old audit consumers only.
        "realized_balance_high_watermark": safe_float(
            risk_state.get("realized_balance_high_watermark"),
            starting_capital,
        ),
        "equity_high_watermark": equity_hwm,
        "equity_high_watermark_source": hwm_source,
        "max_overall_loss_pct": max_overall_loss_pct,
        "trailing_distance_amount_at_hwm": trailing_distance_amount_at_hwm,
        "percentage_trailing_floor_before_stop_cap": percentage_trailing_floor,
        "live_trailing_floor": floor,
        "actual_trailing_buffer": actual_trailing_buffer,
        "projected_trailing_equity_proxy": projected_trailing_equity_proxy,
        "projected_trailing_buffer_after_open_stops": projected_trailing_buffer,
        "equity_proxy": equity_proxy,
        # Legacy alias intentionally remains the projected buffer because the
        # allocator throttle tiers were simulated on this basis.
        "remaining_trailing_buffer": remaining_buffer,
        "effective_daily_reset_offset_hours": float(effective_offset),
        "effective_daily_reset_offset_source": offset_source,
        "daily_start_balance": daily_start_balance,
        "daily_start_balance_source": daily_start_balance_source,
        "daily_drawdown_pct": daily_pct,
        "daily_limit_amount": daily_limit_amount,
        "daily_floor": daily_floor,
        "daily_realized_balance_change": daily_realized_balance_change,
        "daily_realized_trading_pnl": float(daily.get("net_realized_trading_pnl", 0.0)),
        "daily_floating_pnl": daily_floating_pnl,
        "daily_total_pnl": daily_total_pnl,
        "daily_pnl_reconciliation_error": daily_pnl_reconciliation_error,
        "daily_actual_equity": actual_daily_equity,
        "actual_daily_loss_remaining": actual_daily_loss_remaining,
        # Legacy alias now explicitly means actual equity-based remaining.
        "daily_loss_remaining": actual_daily_loss_remaining,
        "daily_equity_proxy": projected_daily_equity_proxy,
        "projected_daily_equity_proxy": projected_daily_equity_proxy,
        "projected_daily_total_pnl": projected_daily_total_pnl,
        "projected_daily_loss_remaining": projected_daily_loss_remaining,
        "daily_snapshot": daily,
        "symbol_risk_lockout_utc_day_by_asset": dict(lockouts),
    }
    risk_state.update({
        "account_login": login,
        "account_server": server,
        "risk_contract_hash": contract["risk_contract_hash"],
        "risk_contract_derivation_version": RISK_CONTRACT_DERIVATION_VERSION,
        # Preserve legacy field without allowing it to drive future trailing floors.
        "realized_balance_high_watermark": max(
            safe_float(risk_state.get("realized_balance_high_watermark"), starting_capital) or starting_capital,
            balance,
        ),
        "equity_high_watermark": equity_hwm,
        "equity_high_watermark_source": hwm_source,
        "current_utc_day": daily["utc_day"],
        "current_risk_day": daily["risk_day"],
        "effective_daily_reset_offset_hours": float(effective_offset),
        "effective_daily_reset_offset_source": offset_source,
        "daily_start_balance": daily_start_balance,
        "daily_start_balance_source": daily_start_balance_source,
        "last_daily_drawdown_pct": daily_pct,
        "last_daily_limit_amount": daily_limit_amount,
        "last_daily_floor": daily_floor,
        "last_daily_realized_balance_change": daily_realized_balance_change,
        "last_daily_floating_pnl": daily_floating_pnl,
        "last_daily_total_pnl": daily_total_pnl,
        "last_daily_actual_equity": actual_daily_equity,
        "last_actual_daily_loss_remaining": actual_daily_loss_remaining,
        "last_daily_loss_remaining": actual_daily_loss_remaining,
        "last_projected_daily_equity_proxy": projected_daily_equity_proxy,
        "last_projected_daily_loss_remaining": projected_daily_loss_remaining,
        "last_max_overall_loss_pct": max_overall_loss_pct,
        "last_trailing_distance_amount_at_hwm": trailing_distance_amount_at_hwm,
        "last_trailing_floor": floor,
        "last_actual_trailing_buffer": actual_trailing_buffer,
        "last_projected_trailing_equity_proxy": projected_trailing_equity_proxy,
        "last_projected_trailing_buffer": projected_trailing_buffer,
        "last_remaining_buffer": remaining_buffer,
        "last_history_sync_utc": utc_now(),
    })
    open_risk["prop_risk_contract"] = contract
    open_risk["prop_risk_context"] = context
    return context


def tier_multiplier(tiers: Any, reference: float, default: float = 1.0) -> float:
    if not tiers:
        return default
    parsed: list[tuple[float, float]] = []
    try:
        for item in tiers:
            if isinstance(item, dict):
                floor = safe_float(item.get("floor") or item.get("balance_floor") or item.get("threshold"), None)
                mult = safe_float(item.get("multiplier") or item.get("mult"), None)
            elif isinstance(item, (list, tuple)) and len(item) >= 2:
                floor = safe_float(item[0], None)
                mult = safe_float(item[1], None)
            else:
                continue
            if floor is not None and mult is not None:
                parsed.append((floor, mult))
    except Exception:
        return default
    if not parsed:
        return default
    multiplier = default
    for floor, mult in sorted(parsed, key=lambda x: x[0], reverse=True):
        if reference < floor:
            multiplier = mult
    return float(multiplier)


def throttle_multiplier(account: Any, manifest: dict[str, Any], open_risk: dict[str, Any] | None = None) -> tuple[float, str]:
    cfg = manifest.get("throttle_config", {}) or {}
    context = (open_risk or {}).get("prop_risk_context") or {}
    balance = float(account.balance)
    if context:
        actual_buffer = safe_float(context.get("actual_trailing_buffer"), None)
        projected_buffer = safe_float(
            context.get("projected_trailing_buffer_after_open_stops"),
            safe_float(context.get("remaining_trailing_buffer"), None),
        )
        if actual_buffer is None or projected_buffer is None:
            return 0.0, "missing_dynamic_trailing_buffer_for_pause_gate"
        if actual_buffer <= 0:
            return 0.0, f"actual_trailing_drawdown_breach:{actual_buffer:.2f}<=0"
        if projected_buffer <= 0:
            return 0.0, f"projected_trailing_stop_risk_limit_reached:{projected_buffer:.2f}<=0"
    else:
        # Legacy/static fallback only when allocator-derived dynamic context is unavailable.
        pause_below = safe_float(cfg.get("pause_below_balance"), None)
        if pause_below is not None and balance < pause_below:
            return 0.0, f"paused_below_balance_floor:{balance:.2f}<{pause_below:.2f}"
    basis = str(context.get("throttle_basis") or "").lower()
    if basis == "remaining_trailing_dd_buffer_usd_equity_proxy":
        reference = safe_float(context.get("remaining_trailing_buffer"), None)
        if reference is None:
            return 0.0, "missing_remaining_trailing_buffer_for_throttle"
        tiers = context.get("throttle_tiers") or cfg.get("throttle_tiers")
        return tier_multiplier(tiers, float(reference), default=1.0), "ok"
    reference = min(float(account.balance), float(account.equity))
    return tier_multiplier(cfg.get("throttle_tiers"), reference, default=1.0), "ok"



def target_lock_multiplier(account: Any, manifest: dict[str, Any]) -> tuple[float, str]:
    cfg = manifest.get("target_lock_config", {}) or {}
    reference = max(float(account.balance), float(account.equity))
    return tier_multiplier(cfg.get("target_lock_tiers"), reference, default=1.0), "ok"


def compute_candidate_sizing(
    signal: dict[str, Any],
    manifest: dict[str, Any],
    edge: dict[str, Any],
    account: Any,
    open_risk: dict[str, Any],
) -> CandidateSizing:
    root_caps = manifest.get("risk_caps", {}) or {}
    edge_caps = edge.get("risk_caps", {}) or {}
    base_pct = float(edge_caps.get("base_portfolio_risk_budget_pct", root_caps.get("base_portfolio_risk_budget_pct", 0.0)))
    max_single_pct = float(edge_caps.get("max_single_trade_risk_pct", root_caps.get("max_single_trade_risk_pct", base_pct)))
    portfolio_weight = safe_float(signal.get("portfolio_weight"), safe_float(edge.get("portfolio_weight"), None))
    if portfolio_weight is None or portfolio_weight <= 0:
        raise RuntimeError("invalid_portfolio_weight")
    afml = safe_float(signal.get("afml_bet_size"), None)
    if afml is None or afml <= 0:
        raise RuntimeError("invalid_afml_bet_size")
    throttle, throttle_reason = throttle_multiplier(account, manifest, open_risk)
    if throttle <= 0:
        raise RuntimeError(throttle_reason)
    target_lock, lock_reason = target_lock_multiplier(account, manifest)
    if target_lock <= 0:
        raise RuntimeError(lock_reason)
    target_before_cap = base_pct * float(portfolio_weight) * float(afml) * float(throttle) * float(target_lock)
    target_pct = min(target_before_cap, max_single_pct)
    # Steps 08-11 size target and overlap caps from realized balance.
    risk_base = float(account.balance)
    target_usd = risk_base * target_pct
    max_single_usd = risk_base * max_single_pct

    max_total = risk_base * float(edge_caps.get("max_total_open_risk_pct", root_caps.get("max_total_open_risk_pct", 0.0)))
    max_asset = risk_base * float(edge_caps.get("max_asset_open_risk_pct", root_caps.get("max_asset_open_risk_pct", 0.0)))
    max_family = risk_base * float(edge_caps.get("max_family_open_risk_pct", root_caps.get("max_family_open_risk_pct", 0.0)))
    max_edge = risk_base * float(edge_caps.get("max_edge_open_risk_pct", root_caps.get("max_edge_open_risk_pct", 0.0)))

    asset = str(signal.get("asset"))
    family = str(signal.get("family"))
    edge_id = str(signal.get("edge_id"))
    remaining_total = max(0.0, max_total - float(open_risk.get("total_open_risk_usd", 0.0)))
    remaining_asset = max(0.0, max_asset - float(open_risk.get("risk_by_asset", {}).get(asset, 0.0)))
    remaining_family = max(0.0, max_family - float(open_risk.get("risk_by_family", {}).get(family, 0.0)))
    remaining_edge = max(0.0, max_edge - float(open_risk.get("risk_by_edge", {}).get(edge_id, 0.0)))

    return CandidateSizing(
        base_portfolio_risk_budget_pct=base_pct,
        portfolio_weight=float(portfolio_weight),
        afml_bet_size=float(afml),
        throttle_multiplier=float(throttle),
        target_lock_multiplier=float(target_lock),
        target_risk_pct_before_cap=float(target_before_cap),
        target_risk_pct=float(target_pct),
        target_risk_usd=float(target_usd),
        max_single_risk_usd=float(max_single_usd),
        remaining_total_cap_usd=float(remaining_total),
        remaining_asset_cap_usd=float(remaining_asset),
        remaining_family_cap_usd=float(remaining_family),
        remaining_edge_cap_usd=float(remaining_edge),
    )


def get_signal_price(signal: dict[str, Any], exec_plan: dict[str, Any]) -> float | None:
    for key in ["signal_price", "entry_price", "bar_close"]:
        val = safe_float(signal.get(key), None)
        if val is not None and val > 0:
            return val
    for key in ["signal_price", "entry_price"]:
        val = safe_float(exec_plan.get(key), None)
        if val is not None and val > 0:
            return val
    return None


def planned_distances(signal: dict[str, Any], exec_plan: dict[str, Any], side_value: int) -> tuple[float | None, float | None, str]:
    for src in [exec_plan, signal]:
        dsl = safe_float(src.get("planned_sl_distance_price"), None)
        dtp = safe_float(src.get("planned_tp_distance_price"), None)
        if dsl is not None and dtp is not None and dsl > 0 and dtp > 0:
            return dsl, dtp, "planned_distance_contract"
    signal_price = get_signal_price(signal, exec_plan)
    sl = safe_float(exec_plan.get("planned_stop_loss"), safe_float(signal.get("planned_stop_loss"), None))
    tp = safe_float(exec_plan.get("planned_take_profit"), safe_float(signal.get("planned_take_profit"), None))
    if signal_price is not None and sl is not None and tp is not None:
        if int(side_value) == 1:
            dsl = signal_price - sl
            dtp = tp - signal_price
        else:
            dsl = sl - signal_price
            dtp = signal_price - tp
        if dsl > 0 and dtp > 0:
            return float(dsl), float(dtp), "derived_from_planned_levels"
    return None, None, "missing_or_invalid_planned_distance"


def allowed_entry_drift_price(asset: str, static_limit: float, sl_distance: float | None) -> float:
    """Return the live entry-drift allowance for a signal.

    The default remains the static per-asset drift limit. For assets configured
    in ``PORTFOLIO_ENTRY_DRIFT_FRACTION_OF_SL_BY_ASSET``, the bot may allow a
    slightly wider drift proportional to the planned SL distance, capped by
    ``PORTFOLIO_ENTRY_DRIFT_MAX_CAP_PRICE_BY_ASSET``. This preserves the
    existing guard while avoiding unnecessary misses on wide-barrier XAUUSD
    signals.
    """
    try:
        allowed = float(static_limit)
    except Exception:
        allowed = 999999.0

    fraction = safe_float(ENTRY_DRIFT_FRACTION_OF_SL_BY_ASSET.get(str(asset)), 0.0) or 0.0
    if fraction > 0 and sl_distance is not None and sl_distance > 0:
        allowed = max(allowed, float(sl_distance) * float(fraction))

    cap = safe_float(ENTRY_DRIFT_MAX_CAP_PRICE_BY_ASSET.get(str(asset)), None)
    if cap is not None and cap > 0 and math.isfinite(cap):
        allowed = min(allowed, float(cap))

    return float(allowed)


def round_volume(volume: float, step: float, min_vol: float, max_vol: float, cap: float) -> float:
    """Return the normal ceil-to-step candidate volume.

    ``estimate_lot_and_risk`` preserves this ceil-first policy, then backs off
    only when the candidate's recalculated MT5 stop risk breaches the effective
    risk cap. This function itself does not floor normal orders.
    """
    volume = max(0.0, min(float(volume), float(max_vol), float(cap)))
    if step <= 0:
        step = 0.01

    decimals = 0
    s = f"{step:.10f}".rstrip("0")
    if "." in s:
        decimals = len(s.split(".")[-1])

    stepped = math.ceil((volume - 1e-12) / step) * step
    stepped = round(stepped, decimals)

    if stepped < min_vol:
        return 0.0
    if stepped > max_vol + 1e-12 or stepped > cap + 1e-12:
        return 0.0
    return stepped


def estimate_lot_and_risk(
    mt5: Any,
    symbol: str,
    side_value: int,
    entry_price: float,
    stop_loss: float,
    target_risk_usd: float,
    max_lot_cap: float,
    max_risk_usd: float | None = None,
) -> tuple[float, float, bool, str]:
    """Size with the existing minimum-lot fallback and ceil-first policy.

    When the normal ceil-to-step volume breaches ``max_risk_usd``, reduce the
    volume one broker step at a time until the largest safe executable volume is
    found. Reject only when no broker-valid volume fits, including the case where
    the broker minimum lot itself exceeds the effective risk cap.
    """
    info = mt5.symbol_info(symbol)
    if info is None:
        return 0.0, 0.0, False, "missing_symbol_info"
    otype = order_type_for_side(mt5, side_value)
    per_lot_profit = mt5.order_calc_profit(
        otype, symbol, 1.0, float(entry_price), float(stop_loss)
    )
    if per_lot_profit is None:
        return 0.0, 0.0, False, f"order_calc_profit_failed:{mt5.last_error()}"
    per_lot_loss = max(0.0, -float(per_lot_profit))
    if per_lot_loss <= 0:
        return 0.0, 0.0, False, "non_positive_per_lot_loss"

    min_vol = float(getattr(info, "volume_min", 0.01) or 0.01)
    step = float(getattr(info, "volume_step", 0.01) or 0.01)
    max_vol = float(getattr(info, "volume_max", 100.0) or 100.0)
    effective_cap = (
        float(target_risk_usd)
        if max_risk_usd is None
        else max(0.0, float(max_risk_usd))
    )
    if effective_cap <= 0:
        return 0.0, 0.0, False, "non_positive_effective_risk_cap"

    raw_lot = float(target_risk_usd) / per_lot_loss
    used_min_lot = False
    if raw_lot < min_vol:
        if not ALLOW_MIN_LOT_FALLBACK:
            return 0.0, 0.0, False, "raw_lot_below_min_and_fallback_disabled"
        volume = min_vol
        used_min_lot = True
        if volume > max_lot_cap or volume > max_vol:
            return 0.0, 0.0, True, "min_lot_above_lot_cap"
    else:
        volume = round_volume(raw_lot, step, min_vol, max_vol, max_lot_cap)
    if volume <= 0:
        return 0.0, 0.0, used_min_lot, "rounded_volume_zero"

    decimals = 0
    step_text = f"{step:.10f}".rstrip("0")
    if "." in step_text:
        decimals = len(step_text.split(".")[-1])

    while True:
        actual_profit = mt5.order_calc_profit(
            otype,
            symbol,
            float(volume),
            float(entry_price),
            float(stop_loss),
        )
        if actual_profit is None:
            return 0.0, 0.0, used_min_lot, f"actual_risk_calc_failed:{mt5.last_error()}"
        actual_risk = max(0.0, -float(actual_profit))
        if actual_risk <= 0:
            return 0.0, 0.0, used_min_lot, "non_positive_actual_risk"
        if actual_risk <= effective_cap + 1e-9:
            return float(volume), float(actual_risk), used_min_lot, "ok"

        # The minimum-lot fallback is intentionally preserved. If that smallest
        # executable lot is still above the hard cap, there is no safe trade.
        if volume <= min_vol + 1e-12:
            return (
                0.0,
                float(actual_risk),
                used_min_lot,
                f"broker_minimum_lot_exceeds_effective_risk_cap:{actual_risk:.2f}>{effective_cap:.2f}",
            )

        next_volume = round(float(volume) - step, decimals)
        if next_volume < min_vol - 1e-12:
            return (
                0.0,
                float(actual_risk),
                used_min_lot,
                f"no_broker_valid_volume_fits_effective_risk_cap:{actual_risk:.2f}>{effective_cap:.2f}",
            )
        volume = max(min_vol, next_volume)


def make_comment(asset: str, family: str, side_value: int, signal_id: str) -> str:
    """Build a short MT5-safe comment with a stable hash suffix.

    MT5 comments are too short to carry full edge_id. The full attribution is
    persisted in state maps keyed by this comment/order/deal/ticket. The hash
    suffix makes comments unique across signals, avoiding the old threshold-like
    suffix collision that could leave open positions bucketed as UNKNOWN.
    """
    side_letter = "L" if int(side_value) == 1 else "S"
    asset_code = compact_asset_code(asset)
    fam_code = compact_family_code(family)
    suffix = signal_hash_suffix(signal_id, length=6)
    return f"V2P|{asset_code}|{fam_code}|{side_letter}|{suffix}"[:31]


def hard_risk_cap_usd(sizing: CandidateSizing) -> float:
    """Smallest hard safety cap, excluding the model's desired target.

    Keeping this separate from ``target_risk_usd`` preserves the established
    broker-minimum fallback: a small model target may execute at the minimum lot
    when that lot remains below every true safety cap.
    """
    caps = [
        float(sizing.max_single_risk_usd),
        float(sizing.remaining_total_cap_usd),
        float(sizing.remaining_asset_cap_usd),
        float(sizing.remaining_family_cap_usd),
        float(sizing.remaining_edge_cap_usd),
    ]
    valid = [c for c in caps if math.isfinite(c)]
    if not valid:
        return 0.0
    return max(0.0, min(valid))


def cap_constrained_risk_target_usd(
    sizing: CandidateSizing,
    hard_cap_usd: float | None = None,
) -> float:
    """Desired target clipped by hard portfolio capacity, without redefining it."""
    hard_cap = hard_risk_cap_usd(sizing) if hard_cap_usd is None else float(hard_cap_usd)
    return max(0.0, min(float(sizing.target_risk_usd), hard_cap))


def _cap_breach_reason(
    *,
    name: str,
    actual_risk_usd: float,
    remaining_cap_usd: float,
    current_open_risk_usd: float,
) -> str | None:
    """Return absolute-vs-remaining cap breach reason.

    "Absolute" means the trade cannot fit even when the bucket has zero existing
    exposure. "Remaining" means it could fit the bucket's absolute cap, but
    current open positions have consumed too much of that bucket.
    """
    eps = 1e-9
    actual = float(actual_risk_usd)
    remaining = float(remaining_cap_usd)
    current = max(0.0, float(current_open_risk_usd))
    absolute = max(0.0, remaining + current)

    if actual <= remaining + eps:
        return None
    if current <= eps or actual > absolute + eps:
        return f"actual_risk_exceeds_absolute_{name}_cap:{actual:.2f}>{absolute:.2f}"
    return f"actual_risk_exceeds_remaining_{name}_cap:{actual:.2f}>{remaining:.2f}"


def build_order_plan(
    mt5: Any,
    signal: dict[str, Any],
    exec_plan: dict[str, Any],
    manifest: dict[str, Any],
    edge: dict[str, Any],
    account: Any,
    open_risk: dict[str, Any],
) -> tuple[OrderPlan | None, str]:
    asset = str(signal.get("asset"))
    symbol = str(signal.get("mt5_symbol") or settings.MT5_SYMBOL_MAP.get(asset, asset))
    family = str(signal.get("family") or edge.get("family") or "UNKNOWN")
    edge_id = str(signal.get("edge_id"))
    side_value = int(signal.get("side_value"))
    side_name = side_name_from_value(side_value)

    tick = mt5.symbol_info_tick(symbol)
    info = mt5.symbol_info(symbol)
    if tick is None or info is None:
        return None, "missing_tick_or_symbol_info"
    point = float(getattr(info, "point", 0.0) or 0.0)
    if point <= 0:
        return None, "invalid_symbol_point"

    spread_points = float((tick.ask - tick.bid) / point)
    max_spread = float(MAX_SPREAD_POINTS_BY_ASSET.get(asset, 999999.0))
    if spread_points > max_spread:
        return None, f"spread_too_high:{spread_points:.1f}>{max_spread:.1f}"

    signal_price = get_signal_price(signal, exec_plan)
    if signal_price is None:
        return None, "missing_signal_price"

    sl_dist, tp_dist, dist_source = planned_distances(signal, exec_plan, side_value)
    if sl_dist is None or tp_dist is None or sl_dist <= 0 or tp_dist <= 0:
        return None, dist_source

    entry_price = float(tick.ask if side_value == 1 else tick.bid)
    drift = abs(entry_price - signal_price)
    static_drift_limit = float(ENTRY_DRIFT_LIMIT_PRICE_BY_ASSET.get(asset, 999999.0))
    drift_limit = allowed_entry_drift_price(asset, static_drift_limit, sl_dist)
    if drift > drift_limit:
        return None, f"entry_drift_too_large:{drift:.5f}>{drift_limit:.5f}"

    stops_level_points = float(getattr(info, "trade_stops_level", 0) or 0)
    min_stop_distance = stops_level_points * point
    if ENFORCE_BROKER_MIN_STOP_LEVEL and min_stop_distance > 0 and sl_dist < min_stop_distance:
        if ALLOW_WIDEN_TO_BROKER_MIN_STOP:
            sl_dist = min_stop_distance
        else:
            return None, f"planned_stop_inside_broker_min_stop:{sl_dist:.5f}<{min_stop_distance:.5f}"

    if side_value == 1:
        stop_loss = entry_price - sl_dist
        take_profit = entry_price + tp_dist
    else:
        stop_loss = entry_price + sl_dist
        take_profit = entry_price - tp_dist
    digits = int(getattr(info, "digits", 2) or 2)
    entry_price = round(float(entry_price), digits)
    stop_loss = round(float(stop_loss), digits)
    take_profit = round(float(take_profit), digits)

    sizing = compute_candidate_sizing(signal, manifest, edge, account, open_risk)
    if sizing.target_risk_usd <= 0:
        return None, "non_positive_target_risk_usd"

    risk_base = float(account.balance)
    effective_hard_risk_cap_usd = hard_risk_cap_usd(sizing)
    cap_target_risk_usd = cap_constrained_risk_target_usd(
        sizing,
        effective_hard_risk_cap_usd,
    )
    risk_context = open_risk.get("prop_risk_context") or {}
    contract = open_risk.get("prop_risk_contract") or {}
    if risk_context:
        actual_trailing_buffer = float(risk_context.get("actual_trailing_buffer", 0.0))
        projected_trailing_buffer_before = float(
            risk_context.get(
                "projected_trailing_buffer_after_open_stops",
                risk_context.get("remaining_trailing_buffer", 0.0),
            )
        )
        if actual_trailing_buffer <= 0:
            return None, "actual_max_trailing_drawdown_breach"
        if projected_trailing_buffer_before <= 0:
            return None, "projected_trailing_stop_risk_limit_reached"
        if bool(contract.get("daily_drawdown_enabled")):
            if float(risk_context.get("actual_daily_loss_remaining", risk_context.get("daily_loss_remaining", 0.0))) <= 0:
                return None, "actual_daily_loss_limit_reached"
            if float(risk_context.get("projected_daily_loss_remaining", 0.0)) <= 0:
                return None, "projected_daily_stop_risk_limit_reached"
        closed_losses = float((risk_context.get("daily_snapshot") or {}).get("closed_losses_by_asset", {}).get(asset, 0.0))
        current_symbol_open = float(open_risk.get("risk_by_asset", {}).get(asset, 0.0))
        current_symbol_usage = closed_losses + current_symbol_open
        if bool(contract.get("daily_symbol_risk_rule_enabled")):
            current_day = str((risk_context.get("daily_snapshot") or {}).get("utc_day") or "")
            lockout_day = str((risk_context.get("symbol_risk_lockout_utc_day_by_asset") or {}).get(asset) or "")
            if current_day and lockout_day == current_day: return None, f"legal_daily_symbol_risk_lockout:{asset}:{current_day}"
            stress_mult = float(contract.get("symbol_risk_stress_multiplier", DEFAULT_SYMBOL_RISK_STRESS_MULTIPLIER))
            current_stressed_symbol_usage = closed_losses + stress_mult * current_symbol_open
            legal_symbol_cap = float(contract.get("legal_symbol_risk_amount")); live_internal_cap = float(contract.get("live_internal_symbol_risk_amount"))
            if current_symbol_usage >= legal_symbol_cap - 1e-9 or current_stressed_symbol_usage >= legal_symbol_cap - 1e-9:
                return None, f"legal_daily_symbol_risk_already_reached:raw={current_symbol_usage:.2f},stressed={current_stressed_symbol_usage:.2f}>={legal_symbol_cap:.2f}"
            if current_symbol_usage >= live_internal_cap - 1e-9: return None, f"internal_daily_symbol_risk_already_reached:{current_symbol_usage:.2f}>={live_internal_cap:.2f}"
        if bool(contract.get("trailing_buffer_admission_enabled")):
            remaining_buffer = float(
                risk_context.get(
                    "projected_trailing_buffer_after_open_stops",
                    risk_context.get("remaining_trailing_buffer", 0.0),
                )
            )
            fixed_reserve = float(contract.get("trailing_buffer_reserve_amount", 0.0))
            allowance = max(0.0, float(contract.get("trailing_buffer_cost_allowance_r", 0.0)))
            current_open = float(open_risk.get("total_open_risk_usd", 0.0))
            reserve_ceiling = (remaining_buffer - fixed_reserve - allowance * current_open) / (1.0 + allowance)
            effective_hard_risk_cap_usd = min(
                effective_hard_risk_cap_usd,
                max(0.0, reserve_ceiling),
            )
        if bool(contract.get("daily_drawdown_enabled")):
            projected_daily_remaining = max(
                0.0,
                float(
                    risk_context.get(
                        "projected_daily_loss_remaining",
                        risk_context.get("daily_loss_remaining", 0.0),
                    )
                ),
            )
            daily_ceiling = projected_daily_remaining
            if bool(contract.get("daily_buffer_admission_enabled")):
                daily_fixed = float(contract.get("daily_buffer_reserve_amount", 0.0))
                daily_allowance = max(
                    0.0,
                    float(contract.get("daily_buffer_cost_allowance_r", 0.0)),
                )
                current_open = float(open_risk.get("total_open_risk_usd", 0.0))
                daily_ceiling = (
                    projected_daily_remaining
                    - daily_fixed
                    - daily_allowance * current_open
                ) / (1.0 + daily_allowance)
            effective_hard_risk_cap_usd = min(
                effective_hard_risk_cap_usd,
                max(0.0, daily_ceiling),
            )
        if bool(contract.get("daily_symbol_risk_rule_enabled")):
            raw_symbol_ceiling = live_internal_cap - current_symbol_usage
            stressed_legal_ceiling = ((legal_symbol_cap - closed_losses) / stress_mult) - current_symbol_open
            effective_hard_risk_cap_usd = min(
                effective_hard_risk_cap_usd,
                max(0.0, min(raw_symbol_ceiling, stressed_legal_ceiling)),
            )
    if effective_hard_risk_cap_usd <= 0:
        return None, "no_remaining_risk_capacity"
    cap_target_risk_usd = min(
        cap_target_risk_usd,
        effective_hard_risk_cap_usd,
    )
    if cap_target_risk_usd <= 0:
        return None, "non_positive_cap_constrained_target_risk"
    cap_target_risk_pct = cap_target_risk_usd / risk_base if risk_base > 0 else 0.0

    max_lot_cap = float(MAX_LOT_CAP_BY_ASSET.get(asset, 100.0))
    volume, actual_risk_usd, used_min_lot, volume_reason = estimate_lot_and_risk(
        mt5=mt5,
        symbol=symbol,
        side_value=side_value,
        entry_price=entry_price,
        stop_loss=stop_loss,
        target_risk_usd=cap_target_risk_usd,
        max_lot_cap=max_lot_cap,
        max_risk_usd=effective_hard_risk_cap_usd,
    )
    if volume_reason != "ok":
        return None, volume_reason

    actual_risk_pct = actual_risk_usd / risk_base if risk_base > 0 else 0.0
    if actual_risk_usd > sizing.max_single_risk_usd + 1e-9:
        return None, f"actual_risk_exceeds_max_single:{actual_risk_usd:.2f}>{sizing.max_single_risk_usd:.2f}"

    current_total_risk = float(open_risk.get("total_open_risk_usd", 0.0))
    current_asset_risk = float(open_risk.get("risk_by_asset", {}).get(asset, 0.0))
    current_family_risk = float(open_risk.get("risk_by_family", {}).get(family, 0.0))
    current_edge_risk = float(open_risk.get("risk_by_edge", {}).get(edge_id, 0.0))

    breach = _cap_breach_reason(
        name="total",
        actual_risk_usd=actual_risk_usd,
        remaining_cap_usd=sizing.remaining_total_cap_usd,
        current_open_risk_usd=current_total_risk,
    )
    if breach:
        return None, breach
    breach = _cap_breach_reason(
        name="asset",
        actual_risk_usd=actual_risk_usd,
        remaining_cap_usd=sizing.remaining_asset_cap_usd,
        current_open_risk_usd=current_asset_risk,
    )
    if breach:
        return None, breach
    breach = _cap_breach_reason(
        name="family",
        actual_risk_usd=actual_risk_usd,
        remaining_cap_usd=sizing.remaining_family_cap_usd,
        current_open_risk_usd=current_family_risk,
    )
    if breach:
        return None, breach
    breach = _cap_breach_reason(
        name="edge",
        actual_risk_usd=actual_risk_usd,
        remaining_cap_usd=sizing.remaining_edge_cap_usd,
        current_open_risk_usd=current_edge_risk,
    )
    if breach:
        return None, breach

    actual_trailing_buffer_before = None
    projected_trailing_buffer_before = None
    projected_buffer = None
    required_reserve = None
    projected_daily_equity_proxy = None
    daily_loss_remaining_before = None
    actual_daily_loss_remaining_before = None
    projected_daily_loss_remaining_before = None
    symbol_closed_losses = None
    projected_symbol_usage = None
    projected_stressed_symbol_usage = None
    symbol_risk_stress_multiplier = None
    live_internal_symbol_risk_amount = None
    legal_symbol_risk_amount = None
    if risk_context:
        fixed_reserve = float(contract.get("trailing_buffer_reserve_amount", 0.0))
        allowance = max(0.0, float(contract.get("trailing_buffer_cost_allowance_r", 0.0)))
        projected_open_risk = float(open_risk.get("total_open_risk_usd", 0.0)) + actual_risk_usd
        required_reserve = fixed_reserve + allowance * projected_open_risk
        actual_trailing_buffer_before = float(risk_context.get("actual_trailing_buffer", 0.0))
        projected_trailing_buffer_before = float(
            risk_context.get(
                "projected_trailing_buffer_after_open_stops",
                risk_context.get("remaining_trailing_buffer", 0.0),
            )
        )
        projected_buffer = projected_trailing_buffer_before - actual_risk_usd
        if bool(contract.get("trailing_buffer_admission_enabled")) and projected_buffer < required_reserve - 1e-9:
            return None, f"projected_trailing_buffer_below_reserve:{projected_buffer:.2f}<{required_reserve:.2f}"
        actual_daily_loss_remaining_before = float(
            risk_context.get("actual_daily_loss_remaining", risk_context.get("daily_loss_remaining", 0.0))
        )
        projected_daily_loss_remaining_before = float(risk_context.get("projected_daily_loss_remaining", 0.0))
        # Backward-compatible alias retained for existing audit consumers.
        daily_loss_remaining_before = projected_daily_loss_remaining_before
        projected_daily_equity_proxy = float(risk_context.get("daily_equity_proxy", 0.0)) - actual_risk_usd
        daily_floor_value = float(risk_context.get("daily_floor", 0.0))
        projected_daily_buffer = projected_daily_equity_proxy - daily_floor_value
        if bool(contract.get("daily_buffer_admission_enabled")):
            daily_fixed = float(contract.get("daily_buffer_reserve_amount", 0.0))
            daily_allowance = max(
                0.0,
                float(contract.get("daily_buffer_cost_allowance_r", 0.0)),
            )
            required_daily_reserve = daily_fixed + daily_allowance * projected_open_risk
            if projected_daily_buffer < required_daily_reserve - 1e-9:
                return None, (
                    "projected_daily_buffer_below_reserve:"
                    f"{projected_daily_buffer:.2f}<{required_daily_reserve:.2f}"
                )
        elif bool(contract.get("daily_drawdown_enabled")) and projected_daily_equity_proxy < daily_floor_value - 1e-9:
            return None, f"projected_daily_stop_risk_breach:{projected_daily_equity_proxy:.2f}<{daily_floor_value:.2f}"
        symbol_closed_losses = float((risk_context.get("daily_snapshot") or {}).get("closed_losses_by_asset", {}).get(asset, 0.0))
        projected_symbol_usage = symbol_closed_losses + current_asset_risk + actual_risk_usd
        if bool(contract.get("daily_symbol_risk_rule_enabled")):
            symbol_risk_stress_multiplier = float(contract.get("symbol_risk_stress_multiplier", DEFAULT_SYMBOL_RISK_STRESS_MULTIPLIER))
            legal_symbol_risk_amount = float(contract.get("legal_symbol_risk_amount")); live_internal_symbol_risk_amount = float(contract.get("live_internal_symbol_risk_amount"))
            projected_stressed_symbol_usage = symbol_closed_losses + symbol_risk_stress_multiplier * (current_asset_risk + actual_risk_usd)
            if projected_symbol_usage > legal_symbol_risk_amount + 1e-9 or projected_stressed_symbol_usage > legal_symbol_risk_amount + 1e-9:
                return None, f"projected_legal_daily_symbol_risk_breach:raw={projected_symbol_usage:.2f},stressed={projected_stressed_symbol_usage:.2f}>{legal_symbol_risk_amount:.2f}"
            if projected_symbol_usage > live_internal_symbol_risk_amount + 1e-9: return None, f"projected_internal_daily_symbol_risk_cap:{projected_symbol_usage:.2f}>{live_internal_symbol_risk_amount:.2f}"

    root_caps = manifest.get("risk_caps", {}) or {}
    edge_caps = edge.get("risk_caps", {}) or {}
    count_asset = int(open_risk.get("count_by_asset", {}).get(asset, 0))
    count_edge = int(open_risk.get("count_by_edge", {}).get(edge_id, 0))
    max_asset_trades = int(edge_caps.get("max_open_trades_per_asset", root_caps.get("max_open_trades_per_asset", 999999)))
    max_edge_trades = int(edge_caps.get("max_open_trades_per_edge", root_caps.get("max_open_trades_per_edge", 999999)))
    if count_asset >= max_asset_trades:
        return None, f"max_open_trades_per_asset_reached:{asset}:{count_asset}>={max_asset_trades}"
    if count_edge >= max_edge_trades:
        return None, f"max_open_trades_per_edge_reached:{edge_id}:{count_edge}>={max_edge_trades}"

    # Backward-compatible static fallback only when no allocator-sourced contract is available.
    prop_rules = {} if risk_context else (manifest.get("prop_rules", {}) or manifest.get("risk_config", {}).get("prop_rules", {}) or {})
    floor = safe_float(prop_rules.get("static_drawdown_floor"), None)
    target_balance = safe_float(contract.get("profit_target_balance"), None) if risk_context else safe_float(prop_rules.get("target_balance"), None)
    if floor is not None:
        if float(account.balance) <= floor:
            return None, f"balance_below_static_floor:{account.balance:.2f}<={floor:.2f}"
        if float(account.equity) <= floor:
            return None, f"equity_below_static_floor:{account.equity:.2f}<={floor:.2f}"
        worst_case_equity = float(account.equity) - float(open_risk.get("total_open_risk_usd", 0.0)) - actual_risk_usd
        if worst_case_equity <= floor + STATIC_FLOOR_BUFFER_USD:
            return None, f"worst_case_equity_too_close_to_floor:{worst_case_equity:.2f}<={floor + STATIC_FLOOR_BUFFER_USD:.2f}"
    if BLOCK_NEW_TRADES_AT_OR_ABOVE_TARGET and target_balance is not None:
        if float(account.balance) >= target_balance or float(account.equity) >= target_balance:
            return None, f"target_balance_reached:{target_balance:.2f}"

    otype = order_type_for_side(mt5, side_value)
    return OrderPlan(
        signal_id=str(signal.get("signal_id")),
        edge_id=edge_id,
        asset=asset,
        symbol=symbol,
        family=family,
        side_name=side_name,
        side_value=side_value,
        order_type_name="BUY" if side_value == 1 else "SELL",
        order_type=otype,
        entry_price=entry_price,
        signal_price=float(signal_price),
        stop_loss=stop_loss,
        take_profit=take_profit,
        sl_distance=float(sl_dist),
        tp_distance=float(tp_dist),
        model_target_risk_pct=sizing.target_risk_pct,
        model_target_risk_usd=sizing.target_risk_usd,
        target_risk_pct=cap_target_risk_pct,
        target_risk_usd=cap_target_risk_usd,
        actual_risk_usd=actual_risk_usd,
        actual_risk_pct=actual_risk_pct,
        volume=volume,
        used_min_lot_fallback=used_min_lot,
        spread_points=spread_points,
        entry_drift_price=drift,
        deviation_points=int(DEVIATION_POINTS_BY_ASSET.get(asset, 100)),
        magic=MAGIC_NUMBER,
        comment=make_comment(asset, family, side_value, str(signal.get("signal_id"))),
        type_filling=get_fill_type(mt5, symbol),
        geometry_hash=str(exec_plan.get("geometry_hash") or "") or None,
        pt_multiplier=float(exec_plan.get("pt_multiplier")),
        sl_multiplier=float(exec_plan.get("sl_multiplier")),
        reward_risk_ratio=float(exec_plan.get("reward_risk_ratio") or (float(exec_plan.get("pt_multiplier")) / float(exec_plan.get("sl_multiplier")))),
        vertical_horizon_bars=safe_int(exec_plan.get("vertical_horizon_bars"), None),
        risk_contract_hash=str(contract.get("risk_contract_hash") or "") or None,
        trailing_floor=safe_float(risk_context.get("live_trailing_floor"), None),
        actual_trailing_buffer_before=actual_trailing_buffer_before,
        remaining_trailing_buffer_before=projected_trailing_buffer_before,
        projected_trailing_buffer_before=projected_trailing_buffer_before,
        projected_trailing_buffer_after=projected_buffer,
        required_trailing_buffer_reserve=required_reserve,
        daily_loss_remaining_before=daily_loss_remaining_before,
        actual_daily_loss_remaining_before=actual_daily_loss_remaining_before,
        projected_daily_loss_remaining_before=projected_daily_loss_remaining_before,
        projected_daily_equity_proxy=projected_daily_equity_proxy,
        symbol_closed_losses_usd=symbol_closed_losses,
        projected_symbol_risk_usd=projected_symbol_usage,
        symbol_risk_stress_multiplier=symbol_risk_stress_multiplier,
        projected_stressed_symbol_risk_usd=projected_stressed_symbol_usage,
        live_internal_symbol_risk_amount=live_internal_symbol_risk_amount,
        legal_symbol_risk_amount=legal_symbol_risk_amount,
        execution_plan_hash=str(signal.get("execution_plan_hash") or exec_plan.get("execution_plan_hash") or "") or None,
        live_manifest_hash=str(signal.get("live_manifest_hash") or "") or None,
        edge_manifest_hash=str(signal.get("edge_manifest_hash") or "") or None,
        bar_policy_hash=str(signal.get("bar_policy_hash") or "") or None,
    ), "ok"


def audit_row(
    stage: str,
    status: str,
    reason: str,
    signal: dict[str, Any] | None = None,
    plan: OrderPlan | None = None,
    account: Any = None,
    open_risk: dict[str, Any] | None = None,
    result: Any = None,
    error: str | None = None,
    live_armed: bool | None = None,
    live_blockers: list[str] | None = None,
) -> dict[str, Any]:
    sig = signal or {}
    row = {
        "created_at": utc_now(),
        "bot_version": BOT_VERSION,
        "execution_mode": EXECUTION_MODE,
        "enable_order_send": ENABLE_ORDER_SEND,
        "live_armed": live_armed,
        "live_blockers": "; ".join(live_blockers or []),
        "stage": stage,
        "status": status,
        "reason": reason,
        "signal_id": sig.get("signal_id"),
        "event_time": sig.get("event_time"),
        "edge_id": sig.get("edge_id"),
        "asset": sig.get("asset"),
        "symbol": sig.get("mt5_symbol"),
        "family": sig.get("family"),
        "side_value": sig.get("side_value"),
        "calibrated_probability": sig.get("calibrated_probability"),
        "final_live_threshold": sig.get("final_live_threshold"),
        "afml_bet_size": sig.get("afml_bet_size"),
        "portfolio_weight": sig.get("portfolio_weight"),
        "signal_price": sig.get("signal_price"),
        "execution_plan_ready": sig.get("execution_plan_ready"),
        "execution_plan_hash": sig.get("execution_plan_hash"),
        "live_manifest_hash": sig.get("live_manifest_hash"),
        "edge_manifest_hash": sig.get("edge_manifest_hash"),
        "bar_policy_hash": sig.get("bar_policy_hash"),
        "account_balance": getattr(account, "balance", None) if account is not None else None,
        "account_equity": getattr(account, "equity", None) if account is not None else None,
        "open_risk_total_usd": (open_risk or {}).get("total_open_risk_usd"),
        "unknown_open_risk_count": len((open_risk or {}).get("unknown_risk_positions", [])),
        "risk_contract_hash": ((open_risk or {}).get("prop_risk_context") or {}).get("risk_contract_hash"),
        "account_rule_profile": ((open_risk or {}).get("prop_risk_context") or {}).get("account_rule_profile"),
        "realized_balance_high_watermark": ((open_risk or {}).get("prop_risk_context") or {}).get("realized_balance_high_watermark"),
        "equity_high_watermark": ((open_risk or {}).get("prop_risk_context") or {}).get("equity_high_watermark"),
        "max_overall_loss_pct": ((open_risk or {}).get("prop_risk_context") or {}).get("max_overall_loss_pct"),
        "trailing_distance_amount_at_hwm": ((open_risk or {}).get("prop_risk_context") or {}).get("trailing_distance_amount_at_hwm"),
        "live_trailing_floor": ((open_risk or {}).get("prop_risk_context") or {}).get("live_trailing_floor"),
        "actual_trailing_buffer": ((open_risk or {}).get("prop_risk_context") or {}).get("actual_trailing_buffer"),
        "projected_trailing_equity_proxy": ((open_risk or {}).get("prop_risk_context") or {}).get("projected_trailing_equity_proxy"),
        "projected_trailing_buffer_after_open_stops": ((open_risk or {}).get("prop_risk_context") or {}).get("projected_trailing_buffer_after_open_stops"),
        "remaining_trailing_buffer": ((open_risk or {}).get("prop_risk_context") or {}).get("remaining_trailing_buffer"),
        "daily_start_balance": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_start_balance"),
        "daily_start_balance_source": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_start_balance_source"),
        "daily_drawdown_pct": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_drawdown_pct"),
        "daily_limit_amount": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_limit_amount"),
        "daily_floor": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_floor"),
        "daily_realized_balance_change": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_realized_balance_change"),
        "daily_realized_trading_pnl": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_realized_trading_pnl"),
        "daily_floating_pnl": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_floating_pnl"),
        "daily_total_pnl": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_total_pnl"),
        "daily_actual_equity": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_actual_equity"),
        "actual_daily_loss_remaining": ((open_risk or {}).get("prop_risk_context") or {}).get("actual_daily_loss_remaining"),
        "daily_loss_remaining": ((open_risk or {}).get("prop_risk_context") or {}).get("daily_loss_remaining"),
        "projected_daily_equity_proxy": ((open_risk or {}).get("prop_risk_context") or {}).get("projected_daily_equity_proxy"),
        "projected_daily_loss_remaining": ((open_risk or {}).get("prop_risk_context") or {}).get("projected_daily_loss_remaining"),
        "retcode": getattr(result, "retcode", None) if result is not None else None,
        "broker_comment": getattr(result, "comment", None) if result is not None else None,
        "order": getattr(result, "order", None) if result is not None else None,
        "deal": getattr(result, "deal", None) if result is not None else None,
        "error": error,
    }
    if plan is not None:
        row.update({f"plan_{k}": v for k, v in asdict(plan).items()})
    return row


def write_status(
    state: dict[str, Any],
    account: Any,
    open_risk: dict[str, Any],
    live_armed: bool,
    live_blockers: list[str],
    extra: dict[str, Any] | None = None,
) -> None:
    payload = {
        "updated_at": utc_now(),
        "bot_version": BOT_VERSION,
        "execution_mode": EXECUTION_MODE,
        "enable_order_send": ENABLE_ORDER_SEND,
        "real_order_send_armed": live_armed,
        "live_blockers": live_blockers,
        "approved_signals_csv": str(APPROVED_SIGNALS_CSV),
        "account": {
            "login": getattr(account, "login", None) if account is not None else None,
            "balance": getattr(account, "balance", None) if account is not None else None,
            "equity": getattr(account, "equity", None) if account is not None else None,
            "margin_free": getattr(account, "margin_free", None) if account is not None else None,
        },
        "open_risk": open_risk,
        "state_counters": state.get("counters", {}),
        "telegram": {
            **telegram_config_snapshot(),
            "last_send": state.get("last_telegram_send"),
        },
        **(extra or {}),
    }
    write_json(LATEST_STATUS_JSON, payload)


def clear_terminal() -> None:
    try:
        os.system("cls" if os.name == "nt" else "clear")
    except Exception:
        pass


def print_heartbeat(account: Any, open_risk: dict[str, Any], pending_count: int, last_action: str, live_armed: bool, live_blockers: list[str]) -> None:
    clear_terminal()
    print("=" * 100)
    print(f"V2 PORTFOLIO EXECUTION BOT | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | mode={EXECUTION_MODE} | order_send={live_armed}")
    print("=" * 100)
    if account is not None:
        print(f"ACCOUNT: balance={account.balance:.2f} equity={account.equity:.2f} free_margin={account.margin_free:.2f}")
    print(f"OPEN RISK: total=${open_risk.get('total_open_risk_usd', 0.0):.2f} | unknown={len(open_risk.get('unknown_risk_positions', []))}")
    ctx = open_risk.get("prop_risk_context") or {}
    if ctx:
        print(
            "PROP RISK: "
            f"trailing_pct={100.0 * ctx.get('max_overall_loss_pct', 0.0):.2f}% "
            f"equity_hwm=${ctx.get('equity_high_watermark', 0.0):.2f} "
            f"floor=${ctx.get('live_trailing_floor', 0.0):.2f} "
            f"actual_buffer=${ctx.get('actual_trailing_buffer', 0.0):.2f} "
            f"after_open_stops=${ctx.get('projected_trailing_buffer_after_open_stops', ctx.get('remaining_trailing_buffer', 0.0)):.2f} "
            f"daily_pct={100.0 * ctx.get('daily_drawdown_pct', 0.0):.2f}% "
            f"daily_allowance=${ctx.get('daily_limit_amount', 0.0):.2f} "
            f"daily_pnl=${ctx.get('daily_total_pnl', 0.0):.2f} "
            f"daily_actual_remaining=${ctx.get('actual_daily_loss_remaining', ctx.get('daily_loss_remaining', 0.0)):.2f} "
            f"daily_after_open_stops=${ctx.get('projected_daily_loss_remaining', 0.0):.2f}"
        )
    print(f"PENDING APPROVED SIGNALS: {pending_count}")
    print(f"APPROVED CSV: {APPROVED_SIGNALS_CSV}")
    print(f"LAST ACTION: {last_action}")
    if live_blockers:
        print("LIVE BLOCKERS: " + "; ".join(live_blockers[:4]))
    print("=" * 100)


def risk_inflation(plan: OrderPlan) -> float:
    if plan.target_risk_usd > 0:
        return float(plan.actual_risk_usd) / float(plan.target_risk_usd)
    return float("inf")


def risk_inflation_display(plan: OrderPlan) -> str:
    value = risk_inflation(plan)
    if math.isfinite(value):
        return f"{value:.2f}x"
    return "inf"


def submit_order(mt5: Any, plan: OrderPlan, type_filling: int | None = None):
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": plan.symbol,
        "volume": float(plan.volume),
        "type": int(plan.order_type),
        "price": float(plan.entry_price),
        "sl": float(plan.stop_loss),
        "tp": float(plan.take_profit),
        "deviation": int(plan.deviation_points),
        "magic": int(plan.magic),
        "comment": plan.comment,
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": int(plan.type_filling if type_filling is None else type_filling),
    }
    return mt5.order_send(request)


def submit_order_with_filling_retry(
    mt5: Any,
    plan: OrderPlan,
    logger: Any,
    state: dict[str, Any],
) -> tuple[Any, list[dict[str, Any]]]:
    """Submit order and retry alternate filling modes only after invalid fill.

    This keeps the execution plan, risk, lot, entry, SL/TP, deviation, magic, and
    comment unchanged. Only the MT5 type_filling is retried when the broker
    explicitly rejects the previous attempt for unsupported/invalid filling mode.
    """
    attempts: list[dict[str, Any]] = []
    last_result: Any = None

    reconciled = reconcile_prior_transient_order(mt5, plan, state, logger)
    if reconciled is not None:
        attempts.append({
            "attempt": 0,
            "type_filling": int(plan.type_filling),
            "retcode": int(getattr(reconciled, "retcode", mt5.TRADE_RETCODE_DONE)),
            "retcode_name": "TRADE_RETCODE_DONE",
            "comment": getattr(reconciled, "comment", "reconciled_after_transient_result"),
            "order": getattr(reconciled, "order", None),
            "deal": getattr(reconciled, "deal", None),
            "reconciled": True,
        })
        return reconciled, attempts

    for idx, type_filling in enumerate(filling_mode_candidates(mt5, plan.symbol, plan.type_filling, state), start=1):
        result = submit_order(mt5, plan, type_filling=type_filling)
        last_result = result
        attempt = summarize_order_attempt(mt5, result, type_filling)
        attempt["attempt"] = idx
        attempts.append(attempt)

        logger.info(
            "ORDER_SEND_ATTEMPT signal_id=%s symbol=%s type_filling=%s retcode=%s retcode_name=%s comment=%s attempt=%s",
            plan.signal_id,
            plan.symbol,
            type_filling,
            attempt.get("retcode"),
            attempt.get("retcode_name"),
            attempt.get("comment"),
            idx,
        )

        if result is not None and int(getattr(result, "retcode", -1)) == int(mt5.TRADE_RETCODE_DONE):
            plan.type_filling = int(type_filling)
            remember_filling_mode(state, plan.symbol, type_filling)
            return result, attempts

        if not is_invalid_fill_result(mt5, result):
            return result, attempts

    if attempts:
        plan.type_filling = int(attempts[-1]["type_filling"])
    return last_result, attempts


def position_open_time_utc(position: Any) -> pd.Timestamp | None:
    """Return the broker-reported position open time as a canonical UTC timestamp."""
    time_msc = safe_int(getattr(position, "time_msc", None), None)
    if time_msc is not None and time_msc > 0:
        try:
            return pd.Timestamp(time_msc, unit="ms", tz="UTC")
        except Exception:
            pass
    time_seconds = safe_int(getattr(position, "time", None), None)
    if time_seconds is not None and time_seconds > 0:
        try:
            return pd.Timestamp(time_seconds, unit="s", tz="UTC")
        except Exception:
            pass
    return None


def update_position_metadata_after_order(mt5: Any, state: dict[str, Any], plan: OrderPlan, signal: dict[str, Any], result: Any) -> None:
    """Persist full edge metadata for the new MT5 position.

    This function intentionally does more than the old ticket-only map:
    - registers comment/order/deal/signal maps immediately;
    - retries position lookup because MT5 may expose the new position slightly
      after order_send returns;
    - stores ticket metadata once the broker position becomes visible.

    The execution/risk logic is unchanged; this only makes future open-risk
    snapshots correctly bucket positions by full edge_id.
    """
    metadata = make_position_metadata(plan, signal, result)
    register_position_metadata(
        state,
        metadata,
        comment=plan.comment,
        order=getattr(result, "order", None),
        deal=getattr(result, "deal", None),
        signal_id=plan.signal_id,
    )

    retries = max(int(getattr(settings, "PORTFOLIO_POSITION_METADATA_CAPTURE_RETRIES", 6)), 1)
    sleep_seconds = max(float(getattr(settings, "PORTFOLIO_POSITION_METADATA_CAPTURE_SLEEP_SECONDS", 0.25)), 0.0)

    try:
        for attempt in range(retries):
            positions = mt5.positions_get(symbol=plan.symbol)
            if positions is None:
                positions = []
            matches = [
                p for p in positions
                if int(getattr(p, "magic", 0)) == int(plan.magic)
                and str(getattr(p, "comment", "")) == plan.comment
            ]
            if not matches:
                # Some brokers modify/truncate comments. Use a conservative
                # fallback: same symbol, magic, side, volume and near entry.
                for p in positions:
                    try:
                        same_magic = int(getattr(p, "magic", 0)) == int(plan.magic)
                        same_volume = abs(float(getattr(p, "volume", 0.0)) - float(plan.volume)) <= 1e-9
                        same_side = position_order_type(mt5, int(getattr(p, "type", -999))) == int(plan.order_type)
                        same_entry = abs(float(getattr(p, "price_open", 0.0)) - float(plan.entry_price)) <= max(1e-6, abs(plan.entry_price) * 1e-5)
                        if same_magic and same_volume and same_side and same_entry:
                            matches.append(p)
                    except Exception:
                        continue
            if matches:
                for pos in matches:
                    ticket = getattr(pos, "ticket", None)
                    pos_comment = getattr(pos, "comment", plan.comment)
                    pos_identifier = getattr(pos, "identifier", None)
                    enriched_metadata = dict(metadata)
                    broker_open_time = position_open_time_utc(pos)
                    if broker_open_time is not None:
                        enriched_metadata["position_open_time"] = broker_open_time.isoformat()
                    enriched_metadata["metadata_captured_at"] = utc_now()
                    register_position_metadata(
                        state,
                        enriched_metadata,
                        ticket=ticket,
                        comment=pos_comment or plan.comment,
                        order=getattr(result, "order", None) or pos_identifier,
                        deal=getattr(result, "deal", None),
                        signal_id=plan.signal_id,
                    )
                return
            if sleep_seconds > 0 and attempt < retries - 1:
                time.sleep(sleep_seconds)
    except Exception:
        # Metadata capture must not affect already-executed orders.
        pass


def live_bars_path_for_asset(asset: str) -> Path:
    return settings.LIVE_BARS_DIR / f"{asset}_live_standard_quote_tick_bars.csv"



def pending_live_bar_asset_dir(asset: str) -> Path:
    return PENDING_LIVE_BAR_DIR / str(asset).upper()


def _read_pending_live_bars_for_executor(
    asset: str,
    logger: Any,
) -> tuple[pd.DataFrame, str | None]:
    directory = pending_live_bar_asset_dir(asset)
    if not directory.exists():
        return pd.DataFrame(), None
    records: list[dict[str, Any]] = []
    for path in sorted(directory.glob("*.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if str(payload.get("schema_version") or "") != "v2_pending_live_bar_v1":
                return pd.DataFrame(), f"unsupported_pending_bar_schema:{path.name}"
            record = payload.get("record")
            if not isinstance(record, dict):
                return pd.DataFrame(), f"invalid_pending_bar_record:{path.name}"
            records.append(record)
        except FileNotFoundError:
            # Compaction may delete a journal between directory enumeration and
            # read. The canonical CSV then already contains that row.
            continue
        except Exception as exc:
            logger.warning(
                "VERTICAL_EXIT_PENDING_BAR_READ_DEFERRED asset=%s path=%s error=%s:%s",
                asset,
                path,
                type(exc).__name__,
                exc,
            )
            return pd.DataFrame(), f"{type(exc).__name__}:{exc}"
    return pd.DataFrame(records), None


def _merge_executor_live_bar_sources(
    base: pd.DataFrame,
    pending: pd.DataFrame,
) -> pd.DataFrame:
    frames = [
        frame.copy()
        for frame in (base, pending)
        if isinstance(frame, pd.DataFrame) and not frame.empty
    ]
    if not frames:
        return pd.DataFrame()
    out = pd.concat(frames, ignore_index=True, sort=False)
    if "Datetime" not in out.columns:
        return out
    parsed = _parse_mixed_utc(out["Datetime"])
    out = out.loc[parsed.notna()].copy()
    out["_merge_datetime_utc"] = parsed.loc[parsed.notna()].values
    out = (
        out.sort_values("_merge_datetime_utc", kind="mergesort")
        .drop_duplicates(subset=["_merge_datetime_utc"], keep="last")
        .drop(columns=["_merge_datetime_utc"])
        .reset_index(drop=True)
    )
    return out



def _read_live_bars_with_retry(asset: str, logger: Any) -> tuple[pd.DataFrame | None, str | None]:
    path = live_bars_path_for_asset(asset)
    last_error: Exception | None = None
    base = pd.DataFrame()

    if path.exists():
        for attempt in range(1, LIVE_BAR_READ_RETRIES + 1):
            try:
                base = pd.read_csv(path)
                last_error = None
                break
            except (
                pd.errors.EmptyDataError,
                pd.errors.ParserError,
                FileNotFoundError,
                PermissionError,
                OSError,
            ) as exc:
                last_error = exc
                if attempt < LIVE_BAR_READ_RETRIES:
                    time.sleep(LIVE_BAR_READ_RETRY_SECONDS * attempt)
        if last_error is not None:
            error_text = f"{type(last_error).__name__}:{last_error}"
            logger.warning(
                "VERTICAL_EXIT_BAR_READ_DEFERRED asset=%s path=%s attempts=%s error=%s",
                asset,
                path,
                LIVE_BAR_READ_RETRIES,
                error_text,
            )
            return None, error_text

    pending, pending_error = _read_pending_live_bars_for_executor(asset, logger)
    if pending_error:
        return None, f"pending_live_bar_read_failed:{pending_error}"
    return _merge_executor_live_bar_sources(base, pending), None


def _read_dashboard_bar_ack(asset: str, logger: Any) -> dict[str, Any]:
    """Read the dashboard's latest closed-bar acknowledgement atomically.

    Prefer the small, immediately published bar-ack file.  Fall back to the
    complete dashboard status for backward compatibility.  Both paths retain
    the existing bounded retry/fail-closed behavior.
    """
    sources = (
        (DASHBOARD_BAR_ACK_JSON, "dashboard_bar_ack"),
        (DASHBOARD_STATUS_JSON, "dashboard_status_fallback"),
    )
    payload: dict[str, Any] | None = None
    source_name: str | None = None
    errors: list[str] = []
    for path, name in sources:
        if not path.exists():
            errors.append(f"{name}:missing")
            continue
        last_error: Exception | None = None
        for attempt in range(1, VERTICAL_BARRIER_STATUS_READ_RETRIES + 1):
            try:
                payload = read_json_object(path)
                source_name = name
                last_error = None
                break
            except Exception as exc:
                last_error = exc
                if attempt < VERTICAL_BARRIER_STATUS_READ_RETRIES:
                    time.sleep(LIVE_BAR_READ_RETRY_SECONDS * attempt)
        if payload is not None:
            break
        errors.append(
            f"{name}:{type(last_error).__name__}:{last_error}"
            if last_error else f"{name}:unknown"
        )

    if payload is None:
        return {
            "ok": False,
            "reason": "dashboard_ack_read_failed:" + "|".join(errors[-4:]),
            "latest_live": None,
            "status_updated_at": None,
            "continuity_status": None,
            "ack_source": None,
        }

    continuity = (payload.get("asset_continuity") or {}).get(str(asset).upper())
    if not isinstance(continuity, dict):
        return {
            "ok": False,
            "reason": "dashboard_asset_continuity_missing",
            "latest_live": None,
            "status_updated_at": payload.get("updated_at"),
            "continuity_status": None,
            "ack_source": source_name,
        }

    continuity_status = str(continuity.get("status") or "")
    latest_live = ensure_utc_timestamp(continuity.get("latest_live"))
    policy_ok = (
        payload.get("live_policy_ready") is True
        and str(payload.get("policy_gate_status") or "").upper() == "POLICY_PASS"
    )
    continuity_ok = continuity_status.upper().startswith("PASS")
    if latest_live is None:
        reason = "dashboard_latest_live_missing_or_invalid"
    elif not policy_ok:
        reason = "dashboard_policy_not_ready"
    elif not continuity_ok:
        reason = f"dashboard_continuity_not_pass:{continuity_status or 'missing'}"
    else:
        reason = "ok"

    return {
        "ok": reason == "ok",
        "reason": reason,
        "latest_live": latest_live,
        "latest_live_refreshed_at": continuity.get("latest_live_refreshed_at"),
        "status_updated_at": payload.get("updated_at"),
        "continuity_status": continuity_status,
        "policy_gate_status": payload.get("policy_gate_status"),
        "live_policy_ready": payload.get("live_policy_ready"),
        "ack_source": source_name,
        "ack_schema_version": payload.get("schema_version"),
    }


def _retry_dashboard_ack_until(
    asset: str,
    target_timestamp: pd.Timestamp,
    logger: Any,
) -> dict[str, Any]:
    """Give the dashboard's immediate bar-ack write a brief chance to catch up."""
    latest: dict[str, Any] = {
        "ok": False,
        "reason": "dashboard_ack_catchup_not_attempted",
        "latest_live": None,
    }
    for attempt in range(1, VERTICAL_BARRIER_ACK_CATCHUP_RETRIES + 1):
        latest = _read_dashboard_bar_ack(asset, logger)
        acknowledged = latest.get("latest_live")
        if (
            latest.get("ok")
            and isinstance(acknowledged, pd.Timestamp)
            and acknowledged >= target_timestamp
        ):
            latest["catchup_attempts"] = attempt
            return latest
        if attempt < VERTICAL_BARRIER_ACK_CATCHUP_RETRIES:
            time.sleep(VERTICAL_BARRIER_ACK_CATCHUP_SLEEP_SECONDS)
    latest["catchup_attempts"] = VERTICAL_BARRIER_ACK_CATCHUP_RETRIES
    return latest



def _parse_mixed_utc(values: Any) -> pd.Series:
    raw = values if isinstance(values, pd.Series) else pd.Series(values)
    try:
        parsed = pd.to_datetime(raw, utc=True, errors="coerce", format="mixed")
        # Older pandas releases may treat "mixed" as a literal format and
        # silently coerce every valid ISO value to NaT instead of raising.
        if bool(raw.notna().any()) and not bool(parsed.notna().any()):
            return pd.to_datetime(raw, utc=True, errors="coerce")
        return parsed
    except (TypeError, ValueError):
        return pd.to_datetime(raw, utc=True, errors="coerce")


def vertical_barrier_progress(
    asset: str,
    event_time: Any,
    logger: Any,
    *,
    position_open_time: Any = None,
    now_utc: Any = None,
) -> dict[str, Any]:
    """Return a fail-closed, dashboard-acknowledged vertical-barrier count.

    The model event timestamp remains the horizon anchor. Only unique,
    executable, non-gap-healed UTC bars acknowledged by the dashboard are
    counted. Future, malformed, conflicting, or unacknowledged rows defer the
    exit. This function never changes feature/event/geometry mathematics.
    """
    start = ensure_utc_timestamp(event_time)
    now_ts = ensure_utc_timestamp(now_utc) if now_utc is not None else utc_now_ts()
    open_ts = ensure_utc_timestamp(position_open_time)
    base: dict[str, Any] = {
        "asset": str(asset).upper(),
        "event_time": start.isoformat() if start is not None else None,
        "position_open_time": open_ts.isoformat() if open_ts is not None else None,
        "checked_at": now_ts.isoformat() if now_ts is not None else utc_now(),
        "count": None,
        "status": "deferred",
        "reason": None,
        "dashboard_latest_live": None,
        "first_eligible_bar": None,
        "latest_eligible_bar": None,
        "first_post_fill_bar": None,
        "bars_after_position_open": 0,
        "future_rows": 0,
        "unacknowledged_rows": 0,
        "invalid_datetime_rows": 0,
        "invalid_closed_at_rows": 0,
        "duplicate_datetime_rows": 0,
        "conflicting_duplicate_rows": 0,
        "non_monotonic_input": False,
        "eligible_rows": 0,
    }
    if start is None:
        base["reason"] = "invalid_event_time"
        return base
    if now_ts is None:
        base["reason"] = "invalid_current_time"
        return base

    df, read_error = _read_live_bars_with_retry(asset, logger)
    if df is None:
        base["reason"] = f"live_bar_read_failed:{read_error or 'unknown'}"
        return base
    if df.empty:
        base.update({"count": 0, "status": "ready", "reason": "no_live_bars"})
        return base
    if "Datetime" not in df.columns:
        base["reason"] = "live_bar_datetime_column_missing"
        return base

    ack = _read_dashboard_bar_ack(asset, logger)
    latest_ack = ack.get("latest_live")
    base.update({
        "dashboard_latest_live": (
            latest_ack.isoformat() if isinstance(latest_ack, pd.Timestamp) else None
        ),
        "dashboard_status_updated_at": ack.get("status_updated_at"),
        "dashboard_latest_live_refreshed_at": ack.get("latest_live_refreshed_at"),
        "dashboard_continuity_status": ack.get("continuity_status"),
    })
    if VERTICAL_BARRIER_REQUIRE_DASHBOARD_ACK and not ack.get("ok"):
        base["reason"] = f"dashboard_ack_unavailable:{ack.get('reason')}"
        return base
    if latest_ack is None:
        # Optional compatibility path when acknowledgement is disabled locally.
        latest_ack = now_ts

    work = df.copy()
    work["_DatetimeUTC"] = _parse_mixed_utc(work["Datetime"])
    if "Closed_At" in work.columns:
        work["_ClosedAtUTC"] = _parse_mixed_utc(work["Closed_At"])
    else:
        work["_ClosedAtUTC"] = work["_DatetimeUTC"]

    work["_Executable"] = work.get(
        "Executable", pd.Series(True, index=work.index)
    ).apply(lambda x: safe_bool(x, False))
    work["_GapHealed"] = work.get(
        "Gap_Healed", pd.Series(False, index=work.index)
    ).apply(lambda x: safe_bool(x, False))

    relevant = work["_Executable"] & (~work["_GapHealed"])
    base["invalid_datetime_rows"] = int((relevant & work["_DatetimeUTC"].isna()).sum())
    base["invalid_closed_at_rows"] = int((relevant & work["_ClosedAtUTC"].isna()).sum())
    if base["invalid_datetime_rows"] or base["invalid_closed_at_rows"]:
        base["reason"] = "invalid_executable_bar_timestamps"
        return base

    relevant_times = work.loc[relevant, "_DatetimeUTC"]
    base["non_monotonic_input"] = bool(not relevant_times.is_monotonic_increasing)
    if base["non_monotonic_input"]:
        base["reason"] = "non_monotonic_executable_bar_timestamps"
        return base

    tolerance = pd.Timedelta(seconds=VERTICAL_BARRIER_FUTURE_TOLERANCE_SECONDS)
    future_mask = relevant & (
        (work["_DatetimeUTC"] > now_ts + tolerance)
        | (work["_ClosedAtUTC"] > now_ts + tolerance)
    )
    base["future_rows"] = int(future_mask.sum())
    if base["future_rows"]:
        base["reason"] = "future_executable_bar_rows_detected"
        return base

    # Closed_At may be slightly rounded relative to Datetime, but it must never
    # materially precede the bar close timestamp.
    impossible_close_mask = relevant & (
        work["_ClosedAtUTC"] + tolerance < work["_DatetimeUTC"]
    )
    if bool(impossible_close_mask.any()):
        base["reason"] = "bar_closed_at_precedes_datetime"
        base["invalid_closed_at_rows"] = int(impossible_close_mask.sum())
        return base

    unack_mask = relevant & (work["_DatetimeUTC"] > latest_ack)
    base["unacknowledged_rows"] = int(unack_mask.sum())
    if base["unacknowledged_rows"]:
        target_ack = pd.Timestamp(work.loc[unack_mask, "_DatetimeUTC"].max())
        catchup = _retry_dashboard_ack_until(asset, target_ack, logger)
        refreshed_ack = catchup.get("latest_live")
        base["dashboard_ack_catchup_attempts"] = catchup.get("catchup_attempts")
        if (
            catchup.get("ok")
            and isinstance(refreshed_ack, pd.Timestamp)
            and refreshed_ack >= target_ack
        ):
            latest_ack = refreshed_ack
            base.update({
                "dashboard_latest_live": refreshed_ack.isoformat(),
                "dashboard_status_updated_at": catchup.get("status_updated_at"),
                "dashboard_latest_live_refreshed_at": catchup.get("latest_live_refreshed_at"),
                "dashboard_continuity_status": catchup.get("continuity_status"),
            })
            unack_mask = relevant & (work["_DatetimeUTC"] > latest_ack)
            base["unacknowledged_rows"] = int(unack_mask.sum())
        if base["unacknowledged_rows"]:
            base["reason"] = "bar_rows_ahead_of_dashboard_ack"
            return base

    canonical = work.loc[
        relevant
        & (work["_DatetimeUTC"] <= latest_ack)
        & (work["_DatetimeUTC"] <= now_ts + tolerance)
    ].copy()

    duplicate_mask = canonical.duplicated(subset=["_DatetimeUTC"], keep=False)
    base["duplicate_datetime_rows"] = int(duplicate_mask.sum())
    if base["duplicate_datetime_rows"]:
        dup = canonical.loc[duplicate_mask].copy()
        compare_cols = [
            c for c in [
                "Open", "High", "Low", "Close", "Ticks", "Threshold",
                "_Executable", "_GapHealed",
            ] if c in dup.columns
        ]
        conflicting = 0
        for _, group in dup.groupby("_DatetimeUTC", sort=False):
            if compare_cols and len(group[compare_cols].drop_duplicates()) > 1:
                conflicting += len(group)
        base["conflicting_duplicate_rows"] = int(conflicting)
        if conflicting:
            base["reason"] = "conflicting_duplicate_bar_rows"
            return base
        canonical = canonical.drop_duplicates(subset=["_DatetimeUTC"], keep="last")

    canonical = canonical.sort_values("_DatetimeUTC", kind="mergesort")
    eligible = canonical.loc[canonical["_DatetimeUTC"] > start].copy()
    count = int(len(eligible))
    base["count"] = count
    base["eligible_rows"] = count
    if count:
        base["first_eligible_bar"] = pd.Timestamp(
            eligible["_DatetimeUTC"].iloc[0]
        ).isoformat()
        base["latest_eligible_bar"] = pd.Timestamp(
            eligible["_DatetimeUTC"].iloc[-1]
        ).isoformat()

    if open_ts is not None:
        post_fill = eligible.loc[eligible["_DatetimeUTC"] > open_ts]
        base["bars_after_position_open"] = int(len(post_fill))
        if not post_fill.empty:
            base["first_post_fill_bar"] = pd.Timestamp(
                post_fill["_DatetimeUTC"].iloc[0]
            ).isoformat()

    base.update({"status": "ready", "reason": "ok"})
    return base


def executable_bars_since(
    asset: str,
    event_time: Any,
    logger: Any,
) -> int | None:
    """Backward-compatible count API using the new causal barrier verifier."""
    progress = vertical_barrier_progress(asset, event_time, logger)
    return int(progress["count"]) if progress.get("status") == "ready" else None


def submit_position_close_with_filling_retry(
    mt5: Any,
    position: Any,
    asset: str,
    magic: int,
    comment: str,
    logger: Any,
    state: dict[str, Any],
    volume_override: float | None = None,
) -> tuple[Any, list[dict[str, Any]]]:
    symbol = str(getattr(position, "symbol"))
    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        return None, [{"reason": "missing_symbol_tick"}]
    is_buy = int(getattr(position, "type")) == int(getattr(mt5, "POSITION_TYPE_BUY", 0))
    order_type = int(mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY)
    price = float(tick.bid if is_buy else tick.ask)
    attempts: list[dict[str, Any]] = []
    last = None
    for idx, fill in enumerate(filling_mode_candidates(mt5, symbol, None, state), start=1):
        request = {
            "action": mt5.TRADE_ACTION_DEAL, "symbol": symbol,
            "volume": float(volume_override if volume_override is not None else getattr(position, "volume")), "type": order_type,
            "position": int(getattr(position, "ticket")), "price": price,
            "deviation": int(DEVIATION_POINTS_BY_ASSET.get(asset, 100)),
            "magic": int(magic), "comment": str(comment)[:31],
            "type_time": mt5.ORDER_TIME_GTC, "type_filling": int(fill),
        }
        last = mt5.order_send(request)
        rec = summarize_order_attempt(mt5, last, int(fill)); rec["attempt"] = idx
        attempts.append(rec)
        logger.info("VERTICAL_EXIT_ATTEMPT ticket=%s symbol=%s attempt=%s fill=%s retcode=%s comment=%s", getattr(position, "ticket", None), symbol, idx, fill, rec.get("retcode"), rec.get("comment"))
        if last is not None and int(getattr(last, "retcode", -1)) == int(mt5.TRADE_RETCODE_DONE):
            remember_filling_mode(state, symbol, fill)
            return last, attempts
        if not is_invalid_fill_result(mt5, last):
            return last, attempts
    return last, attempts


def enforce_vertical_horizon_exits(mt5: Any, manifest: dict[str, Any], state: dict[str, Any], live_armed: bool, logger: Any) -> list[str]:
    """Close managed live positions when their verified vertical barrier expires."""
    if not live_armed:
        return []
    positions = mt5.positions_get() or []
    actions: list[str] = []
    for position in positions:
        meta, source = resolve_position_metadata(position, state)
        horizon = safe_int(meta.get("vertical_horizon_bars"), None)
        event_time = meta.get("entry_event_time") or meta.get("event_time")
        asset = str(meta.get("asset") or "")
        edge_id = str(meta.get("edge_id") or "")
        if horizon is None or horizon <= 0 or not event_time or not asset or not edge_id or edge_id == "UNKNOWN":
            continue

        ticket = str(getattr(position, "ticket", ""))
        broker_open_ts = position_open_time_utc(position)
        if broker_open_ts is None:
            broker_open_ts = ensure_utc_timestamp(meta.get("position_open_time"))
        progress = vertical_barrier_progress(
            asset,
            event_time,
            logger,
            position_open_time=broker_open_ts,
        )
        progress_record = {
            **progress,
            "ticket": ticket,
            "edge_id": edge_id,
            "vertical_horizon_bars": horizon,
            "metadata_source": source,
        }
        state.setdefault("vertical_barrier_last_progress_by_ticket", {})[ticket] = progress_record

        if progress.get("status") != "ready":
            counts = state.setdefault("vertical_bar_read_deferred_count_by_asset", {})
            counts[asset] = int(counts.get(asset, 0) or 0) + 1
            deferred = {
                "created_at": utc_now(),
                **progress_record,
            }
            history = state.setdefault("vertical_barrier_deferred_history", [])
            # Avoid adding the identical asset/ticket/reason every one-second poll.
            last = history[-1] if history else {}
            same_as_last = (
                str(last.get("ticket")) == ticket
                and str(last.get("reason")) == str(progress.get("reason"))
                and str(last.get("dashboard_latest_live")) == str(progress.get("dashboard_latest_live"))
            )
            if not same_as_last:
                history.append(deferred)
                state["vertical_barrier_deferred_history"] = history[-200:]
                logger.warning(
                    "VERTICAL_EXIT_DEFERRED ticket=%s asset=%s edge=%s horizon=%s reason=%s "
                    "event_time=%s position_open_time=%s dashboard_latest_live=%s "
                    "future_rows=%s unacknowledged_rows=%s invalid_datetime_rows=%s "
                    "duplicate_rows=%s conflicting_duplicates=%s",
                    ticket,
                    asset,
                    edge_id,
                    horizon,
                    progress.get("reason"),
                    progress.get("event_time"),
                    progress.get("position_open_time"),
                    progress.get("dashboard_latest_live"),
                    progress.get("future_rows"),
                    progress.get("unacknowledged_rows"),
                    progress.get("invalid_datetime_rows"),
                    progress.get("duplicate_datetime_rows"),
                    progress.get("conflicting_duplicate_rows"),
                )
            continue

        elapsed = int(progress.get("count") or 0)
        if elapsed < horizon:
            continue

        # Preserve the event-time horizon anchor, but never submit an immediate
        # close based solely on bars that predate the actual broker fill.
        if (
            VERTICAL_BARRIER_REQUIRE_POST_FILL_BAR
            and broker_open_ts is not None
            and int(progress.get("bars_after_position_open") or 0) <= 0
        ):
            counts = state.setdefault("vertical_bar_read_deferred_count_by_asset", {})
            counts[asset] = int(counts.get(asset, 0) or 0) + 1
            deferred = {
                "created_at": utc_now(),
                **progress_record,
                "reason": "no_post_fill_bar",
            }
            history = state.setdefault("vertical_barrier_deferred_history", [])
            last = history[-1] if history else {}
            same_as_last = (
                str(last.get("ticket")) == ticket
                and str(last.get("reason")) == "no_post_fill_bar"
                and str(last.get("dashboard_latest_live")) == str(progress.get("dashboard_latest_live"))
            )
            if not same_as_last:
                history.append(deferred)
                state["vertical_barrier_deferred_history"] = history[-200:]
                logger.warning(
                    "VERTICAL_EXIT_DEFERRED ticket=%s asset=%s edge=%s horizon=%s "
                    "reason=no_post_fill_bar event_time=%s position_open_time=%s "
                    "elapsed=%s dashboard_latest_live=%s",
                    ticket,
                    asset,
                    edge_id,
                    horizon,
                    progress.get("event_time"),
                    progress.get("position_open_time"),
                    elapsed,
                    progress.get("dashboard_latest_live"),
                )
            continue

        key = f"{ticket}|{edge_id}|{horizon}"
        if key in state.setdefault("vertical_exit_notification_keys", []):
            continue
        result, attempts = submit_position_close_with_filling_retry(
            mt5,
            position,
            asset,
            MAGIC_NUMBER,
            f"V2VH|{asset}|{signal_hash_suffix(edge_id)}",
            logger,
            state,
        )
        success = (
            result is not None
            and int(getattr(result, "retcode", -1)) == int(mt5.TRADE_RETCODE_DONE)
        )
        reason = (
            "vertical_barrier_exit_executed"
            if success
            else (
                "vertical_barrier_exit_rejected:"
                f"{getattr(result, 'retcode', None)}:{getattr(result, 'comment', None)}"
            )
        )
        row = {
            "created_at": utc_now(),
            "bot_version": BOT_VERSION,
            "stage": "vertical_exit",
            "status": "executed" if success else "order_rejected",
            "reason": reason,
            "ticket": ticket,
            "edge_id": edge_id,
            "asset": asset,
            "vertical_horizon_bars": horizon,
            "executable_bars_elapsed": elapsed,
            "event_time": progress.get("event_time"),
            "position_open_time": progress.get("position_open_time"),
            "dashboard_latest_live": progress.get("dashboard_latest_live"),
            "first_eligible_bar": progress.get("first_eligible_bar"),
            "latest_eligible_bar": progress.get("latest_eligible_bar"),
            "first_post_fill_bar": progress.get("first_post_fill_bar"),
            "bars_after_position_open": progress.get("bars_after_position_open"),
            "future_rows": progress.get("future_rows"),
            "unacknowledged_rows": progress.get("unacknowledged_rows"),
            "duplicate_datetime_rows": progress.get("duplicate_datetime_rows"),
            "metadata_source": source,
            "order_send_attempts_json": json.dumps(
                attempts, default=str, sort_keys=True
            ),
            "retcode": getattr(result, "retcode", None) if result is not None else None,
            "broker_comment": (
                getattr(result, "comment", None) if result is not None else None
            ),
        }
        append_rows_csv(EXECUTION_AUDIT_CSV, [row])
        if success:
            state["vertical_exit_notification_keys"].append(key)
            state["vertical_exit_notification_keys"] = state[
                "vertical_exit_notification_keys"
            ][-1000:]
            if SEND_EXECUTION_TELEGRAM:
                send_telegram_logged(
                    logger,
                    state,
                    "vertical_exit",
                    (
                        "⏱️ V2 VERTICAL BARRIER EXIT\n"
                        f"{asset} | {edge_id}\n"
                        f"ticket={ticket} bars={elapsed}/{horizon}\n"
                        f"event={progress.get('event_time')}\n"
                        f"latest_bar={progress.get('latest_eligible_bar')}"
                    ),
                )
        actions.append(reason)
    return actions


def find_position_for_filled_plan(mt5: Any, state: dict[str, Any], plan: OrderPlan, result: Any) -> Any | None:
    """Locate the broker position created/expanded by this order without changing entry flow."""
    result_order = str(getattr(result, "order", "") or "")
    result_deal = str(getattr(result, "deal", "") or "")
    for attempt in range(max(int(POST_FILL_POSITION_LOOKUP_RETRIES), 1)):
        positions = mt5.positions_get(symbol=plan.symbol) or []
        exact: list[Any] = []
        fallback: list[Any] = []
        for pos in positions:
            try:
                meta, _ = resolve_position_metadata(pos, state)
                if str(meta.get("signal_id") or "") == plan.signal_id:
                    exact.append(pos); continue
                identifier = str(getattr(pos, "identifier", "") or "")
                ticket = str(getattr(pos, "ticket", "") or "")
                if result_order and result_order in {identifier, ticket}:
                    exact.append(pos); continue
                if result_deal and result_deal in {identifier, ticket}:
                    exact.append(pos); continue
                same_magic = int(getattr(pos, "magic", 0)) == int(plan.magic)
                same_side = position_order_type(mt5, int(getattr(pos, "type", -999))) == int(plan.order_type)
                if same_magic and same_side:
                    fallback.append(pos)
            except Exception:
                continue
        candidates = exact or fallback
        if candidates:
            return max(candidates, key=lambda p: (int(getattr(p, "time_msc", 0) or 0), int(getattr(p, "time", 0) or 0), int(getattr(p, "ticket", 0) or 0)))
        if attempt < POST_FILL_POSITION_LOOKUP_RETRIES - 1:
            time.sleep(max(float(POST_FILL_POSITION_LOOKUP_SLEEP_SECONDS), 0.0))
    return None


def symbol_risk_protection_snapshot(asset: str, open_risk: dict[str, Any]) -> dict[str, Any]:
    context = open_risk.get("prop_risk_context") or {}; contract = open_risk.get("prop_risk_contract") or {}
    closed = float((context.get("daily_snapshot") or {}).get("closed_losses_by_asset", {}).get(asset, 0.0)); open_stop = float(open_risk.get("risk_by_asset", {}).get(asset, 0.0))
    enabled = bool(contract.get("daily_symbol_risk_rule_enabled")); multiplier = float(contract.get("symbol_risk_stress_multiplier", DEFAULT_SYMBOL_RISK_STRESS_MULTIPLIER))
    return {"enabled": enabled, "closed_losses_usd": closed, "open_stop_risk_usd": open_stop, "raw_usage_usd": closed + open_stop, "stressed_usage_usd": closed + multiplier * open_stop, "stress_multiplier": multiplier, "live_internal_cap_usd": contract.get("live_internal_symbol_risk_amount"), "legal_cap_usd": contract.get("legal_symbol_risk_amount")}


def post_fill_risk_guard(mt5: Any, manifest: dict[str, Any], state: dict[str, Any], plan: OrderPlan, signal: dict[str, Any], result: Any, logger: Any) -> dict[str, Any]:
    """Recheck actual MT5 exposure after fill and reduce only the newly-filled volume on breach."""
    if not POST_FILL_RISK_CHECK_ENABLED: return {"status": "disabled", "breach": False}
    account = mt5.account_info()
    if account is None:
        # A successful fill that cannot be verified is treated fail-closed. We can
        # still locate the newly-created/expanded position without account_info()
        # and reduce only the volume introduced by this plan.
        record = {
            "status": "account_info_unavailable",
            "breach": True,
            "breach_reasons": ["post_fill_account_info_unavailable"],
        }
        position = find_position_for_filled_plan(mt5, state, plan, result)
        if position is None or not POST_FILL_EMERGENCY_REDUCE_ENABLED:
            record.update({
                "close_attempted": False,
                "close_success": False,
                "reason": "post_fill_position_not_found_or_emergency_reduce_disabled",
            })
            return record
        reduce_volume = min(float(plan.volume), float(getattr(position, "volume", plan.volume)))
        result_close, attempts = submit_position_close_with_filling_retry(
            mt5, position, plan.asset, MAGIC_NUMBER,
            f"V2PF|{plan.asset}|{signal_hash_suffix(plan.signal_id)}", logger, state,
            volume_override=reduce_volume,
        )
        success = (
            result_close is not None
            and int(getattr(result_close, "retcode", -1)) == int(mt5.TRADE_RETCODE_DONE)
        )
        record.update({
            "close_attempted": True,
            "close_success": success,
            "close_retcode": getattr(result_close, "retcode", None) if result_close is not None else None,
            "close_comment": getattr(result_close, "comment", None) if result_close is not None else None,
            "close_attempts": attempts,
            "position_ticket": getattr(position, "ticket", None),
            "reduced_volume": reduce_volume,
        })
        append_rows_csv(EXECUTION_AUDIT_CSV, [{
            "created_at": utc_now(),
            "bot_version": BOT_VERSION,
            "stage": "post_fill_risk_guard",
            "status": "emergency_reduced" if success else "emergency_reduce_failed",
            "reason": "post_fill_account_info_unavailable",
            "signal_id": plan.signal_id,
            "edge_id": plan.edge_id,
            "asset": plan.asset,
            "symbol": plan.symbol,
            "close_retcode": record.get("close_retcode"),
            "close_comment": record.get("close_comment"),
            "position_ticket": record.get("position_ticket"),
            "reduced_volume": record.get("reduced_volume"),
            "order_send_attempts_json": json.dumps(attempts, default=str, sort_keys=True),
        }])
        if SEND_REJECTION_TELEGRAM:
            send_telegram_logged(
                logger, state, "post_fill_risk_guard",
                f"🚨 V2 POST-FILL VERIFICATION UNAVAILABLE\n{plan.asset} | {plan.edge_id}\n"
                f"emergency_reduce_success={success}",
            )
        return record
    fresh_open = get_open_risk_snapshot(mt5, manifest, state, logger)
    context = attach_prop_risk_context(mt5, manifest, account, fresh_open, state)
    contract = fresh_open.get("prop_risk_contract") or {}

    root_caps = manifest.get("risk_caps") or {}
    edge_lookup = selected_edge_lookup(manifest)
    selected_edge = edge_lookup.get(plan.edge_id) or {}
    edge_caps = selected_edge.get("risk_caps") or {}

    def _effective_cap(name: str, default: float = 1.0) -> float:
        return float(edge_caps.get(name, root_caps.get(name, default)))

    balance = float(account.balance)
    total = float(fresh_open.get("total_open_risk_usd", 0.0))
    asset_risk = float(fresh_open.get("risk_by_asset", {}).get(plan.asset, 0.0))
    family_risk = float(fresh_open.get("risk_by_family", {}).get(plan.family, 0.0))
    edge_risk = float(fresh_open.get("risk_by_edge", {}).get(plan.edge_id, 0.0))
    count_asset = int(fresh_open.get("count_by_asset", {}).get(plan.asset, 0))
    count_edge = int(fresh_open.get("count_by_edge", {}).get(plan.edge_id, 0))

    total_cap_usd = balance * _effective_cap("max_total_open_risk_pct")
    asset_cap_usd = balance * _effective_cap("max_asset_open_risk_pct")
    family_cap_usd = balance * _effective_cap("max_family_open_risk_pct")
    edge_cap_usd = balance * _effective_cap("max_edge_open_risk_pct")
    max_asset_trades = int(edge_caps.get(
        "max_open_trades_per_asset",
        root_caps.get("max_open_trades_per_asset", 999999),
    ))
    max_edge_trades = int(edge_caps.get(
        "max_open_trades_per_edge",
        root_caps.get("max_open_trades_per_edge", 999999),
    ))

    projected_open = total
    required_reserve = (
        float(contract.get("trailing_buffer_reserve_amount", 0.0))
        + float(contract.get("trailing_buffer_cost_allowance_r", 0.0)) * projected_open
    )
    actual_trailing_buffer = float(context.get("actual_trailing_buffer", 0.0))
    projected_trailing_buffer = float(
        context.get(
            "projected_trailing_buffer_after_open_stops",
            context.get("remaining_trailing_buffer", 0.0),
        )
    )

    reasons = []
    if total > total_cap_usd + 1e-9:
        reasons.append("total_open_risk_cap")
    if asset_risk > asset_cap_usd + 1e-9:
        reasons.append("asset_open_risk_cap")
    if family_risk > family_cap_usd + 1e-9:
        reasons.append("family_open_risk_cap")
    if edge_risk > edge_cap_usd + 1e-9:
        reasons.append("edge_open_risk_cap")
    if count_asset > max_asset_trades:
        reasons.append("max_open_trades_per_asset")
    if count_edge > max_edge_trades:
        reasons.append("max_open_trades_per_edge")
    if actual_trailing_buffer <= 1e-9:
        reasons.append("actual_max_trailing_drawdown_breach")
    if (
        bool(contract.get("trailing_buffer_admission_enabled"))
        and projected_trailing_buffer < required_reserve - 1e-9
    ):
        reasons.append("projected_trailing_buffer_reserve")
    if bool(contract.get("daily_drawdown_enabled")):
        if float(context.get("actual_daily_loss_remaining", context.get("daily_loss_remaining", 0.0))) <= 1e-9:
            reasons.append("actual_daily_drawdown_breach")
        if float(context.get("projected_daily_loss_remaining", 0.0)) <= 1e-9:
            reasons.append("projected_daily_stop_risk_breach")
    symbol = symbol_risk_protection_snapshot(plan.asset, fresh_open)
    if symbol["enabled"]:
        live_cap=float(symbol["live_internal_cap_usd"]); legal=float(symbol["legal_cap_usd"])
        if symbol["raw_usage_usd"] > live_cap + 1e-9 or symbol["raw_usage_usd"] > legal + 1e-9 or symbol["stressed_usage_usd"] > legal + 1e-9: reasons.append("funded_symbol_risk")
    breach=bool(reasons)
    record = {
        "status": "breach" if breach else "pass",
        "breach": breach,
        "breach_reasons": reasons,
        "total_open_risk_usd": total,
        "asset_open_risk_usd": asset_risk,
        "family_open_risk_usd": family_risk,
        "edge_open_risk_usd": edge_risk,
        "total_open_risk_cap_usd": total_cap_usd,
        "asset_open_risk_cap_usd": asset_cap_usd,
        "family_open_risk_cap_usd": family_cap_usd,
        "edge_open_risk_cap_usd": edge_cap_usd,
        "count_asset": count_asset,
        "count_edge": count_edge,
        "max_open_trades_per_asset": max_asset_trades,
        "max_open_trades_per_edge": max_edge_trades,
        "edge_specific_caps_applied": bool(edge_caps),
        "equity_high_watermark": context.get("equity_high_watermark"),
        "max_overall_loss_pct": context.get("max_overall_loss_pct"),
        "live_trailing_floor": context.get("live_trailing_floor"),
        "actual_trailing_buffer": actual_trailing_buffer,
        "projected_trailing_equity_proxy": context.get("projected_trailing_equity_proxy"),
        "projected_trailing_buffer_after_open_stops": projected_trailing_buffer,
        "remaining_trailing_buffer": context.get("remaining_trailing_buffer"),
        "required_trailing_buffer_reserve": required_reserve,
        "daily_drawdown_pct": context.get("daily_drawdown_pct"),
        "daily_limit_amount": context.get("daily_limit_amount"),
        "daily_total_pnl": context.get("daily_total_pnl"),
        "actual_daily_loss_remaining": context.get("actual_daily_loss_remaining"),
        "projected_daily_loss_remaining": context.get("projected_daily_loss_remaining"),
        "daily_equity_proxy": context.get("daily_equity_proxy"),
        "daily_floor": context.get("daily_floor"),
        "symbol_risk": symbol,
    }
    if not breach: return record
    if symbol["enabled"] and "funded_symbol_risk" in reasons:
        day=str((context.get("daily_snapshot") or {}).get("utc_day") or "")
        if day: state.setdefault("prop_risk_state", {}).setdefault("symbol_risk_lockout_utc_day_by_asset", {})[plan.asset]=day
    position=find_position_for_filled_plan(mt5,state,plan,result)
    if position is None or not POST_FILL_EMERGENCY_REDUCE_ENABLED:
        record.update({"close_attempted":False,"close_success":False,"reason":"post_fill_position_not_found_or_emergency_reduce_disabled"}); return record
    reduce_volume=min(float(plan.volume),float(getattr(position,"volume",plan.volume)))
    result_close,attempts=submit_position_close_with_filling_retry(mt5,position,plan.asset,MAGIC_NUMBER,f"V2PF|{plan.asset}|{signal_hash_suffix(plan.signal_id)}",logger,state,volume_override=reduce_volume)
    success=result_close is not None and int(getattr(result_close,"retcode",-1))==int(mt5.TRADE_RETCODE_DONE)
    record.update({"close_attempted":True,"close_success":success,"close_retcode":getattr(result_close,"retcode",None) if result_close is not None else None,"close_comment":getattr(result_close,"comment",None) if result_close is not None else None,"close_attempts":attempts,"position_ticket":getattr(position,"ticket",None),"reduced_volume":reduce_volume})
    append_rows_csv(EXECUTION_AUDIT_CSV,[{"created_at":utc_now(),"bot_version":BOT_VERSION,"stage":"post_fill_risk_guard","status":"emergency_reduced" if success else "emergency_reduce_failed","reason":"post_fill_risk_breach:"+",".join(reasons),"signal_id":plan.signal_id,"edge_id":plan.edge_id,"asset":plan.asset,"symbol":plan.symbol,**{k:v for k,v in record.items() if k not in {"close_attempts","symbol_risk"}},"symbol_risk_json":json.dumps(symbol,default=str,sort_keys=True),"order_send_attempts_json":json.dumps(attempts,default=str,sort_keys=True)}])
    if SEND_REJECTION_TELEGRAM: send_telegram_logged(logger,state,"post_fill_risk_guard",f"🚨 V2 POST-FILL RISK BREACH\n{plan.asset} | {plan.edge_id}\nreasons={','.join(reasons)} emergency_reduce_success={success}")
    return record


def process_signal(
    mt5: Any,
    manifest: dict[str, Any],
    policy: dict[str, Any],
    edge_lookup: dict[str, dict[str, Any]],
    current_hashes: dict[str, str | None],
    state: dict[str, Any],
    signal: dict[str, Any],
    live_armed: bool,
    live_blockers: list[str],
    logger: Any,
) -> str:
    account = mt5.account_info()
    if account is None:
        reason = "missing_account_info"
        append_rows_csv(EXECUTION_AUDIT_CSV, [audit_row("account", "transient_wait", reason, signal=signal, live_armed=live_armed, live_blockers=live_blockers)])
        state["counters"]["transient_waits"] += 1
        send_signal_issue_telegram_once(
            logger,
            state,
            signal=signal,
            stage="account",
            status="transient_wait",
            reason=reason,
            live_armed=live_armed,
            live_blockers=live_blockers,
        )
        return reason

    ok, reason, exec_plan = validate_signal_contract(signal, edge_lookup, current_hashes, require_execution_allowed_for_live=live_armed)
    if not ok:
        mark_terminal(state, str(signal.get("signal_id")), "blocked", reason)
        clear_transient_order_retry(state, str(signal.get("signal_id")))
        row = audit_row("validate", "blocked", reason, signal=signal, account=account, live_armed=live_armed, live_blockers=live_blockers)
        append_rows_csv(EXECUTION_AUDIT_CSV, [row])
        append_rows_csv(REJECTED_SIGNALS_CSV, [row], dedup_cols=["signal_id", "reason"])
        state["counters"]["blocked"] += 1
        if SEND_REJECTION_TELEGRAM:
            send_telegram_logged(
                logger,
                state,
                "validation_block",
                f"❌ V2 signal blocked\n{signal.get('edge_id')} {signal.get('asset')}\n{reason}",
            )
        return reason
    assert exec_plan is not None
    edge = edge_lookup[str(signal.get("edge_id"))]
    open_risk = get_open_risk_snapshot(mt5, manifest, state, logger)
    try:
        attach_prop_risk_context(mt5, manifest, account, open_risk, state)
    except Exception as exc:
        reason = f"prop_risk_context_unavailable:{type(exc).__name__}:{exc}"
        row = audit_row("prop_risk", "transient_wait", reason, signal=signal, account=account, open_risk=open_risk, live_armed=live_armed, live_blockers=live_blockers)
        append_rows_csv(EXECUTION_AUDIT_CSV, [row])
        state["counters"]["transient_waits"] += 1
        send_signal_issue_telegram_once(logger, state, signal=signal, stage="prop_risk", status="transient_wait", reason=reason, account=account, open_risk=open_risk, live_armed=live_armed, live_blockers=live_blockers)
        return reason
    if BLOCK_IF_UNKNOWN_OPEN_RISK and open_risk.get("unknown_risk_positions"):
        reason = f"unknown_open_position_risk_count:{len(open_risk['unknown_risk_positions'])}"
        row = audit_row("open_risk", "transient_wait", reason, signal=signal, account=account, open_risk=open_risk, live_armed=live_armed, live_blockers=live_blockers)
        append_rows_csv(EXECUTION_AUDIT_CSV, [row])
        state["counters"]["transient_waits"] += 1
        send_signal_issue_telegram_once(
            logger,
            state,
            signal=signal,
            stage="open_risk",
            status="transient_wait",
            reason=reason,
            account=account,
            open_risk=open_risk,
            live_armed=live_armed,
            live_blockers=live_blockers,
        )
        return reason

    plan, plan_reason = build_order_plan(mt5, signal, exec_plan, manifest, edge, account, open_risk)
    if plan is None:
        transient_prefixes = [
            "spread_too_high", "entry_drift_too_large", "max_open_trades",
            "actual_risk_exceeds_remaining", "worst_case_equity_too_close_to_floor",
            "target_balance_reached", "paused_below_balance_floor", "missing_tick_or_symbol_info",
            "trailing_drawdown_buffer_exhausted", "actual_daily_loss_limit_reached",
            "projected_daily_stop_risk_limit_reached",
            "legal_daily_symbol_risk_already_reached", "internal_daily_symbol_risk_already_reached",
            "legal_daily_symbol_risk_lockout",
            "projected_trailing_buffer_below_reserve", "projected_daily_stop_risk_breach",
            "projected_legal_daily_symbol_risk_breach", "projected_internal_daily_symbol_risk_cap",
        ]
        is_transient = any(str(plan_reason).startswith(p) for p in transient_prefixes)
        status = "transient_wait" if is_transient else "blocked"
        row = audit_row("plan", status, plan_reason, signal=signal, account=account, open_risk=open_risk, live_armed=live_armed, live_blockers=live_blockers)
        append_rows_csv(EXECUTION_AUDIT_CSV, [row])
        if is_transient:
            state["counters"]["transient_waits"] += 1
        else:
            mark_terminal(state, str(signal.get("signal_id")), "blocked", plan_reason)
            clear_transient_order_retry(state, str(signal.get("signal_id")))
            append_rows_csv(REJECTED_SIGNALS_CSV, [row], dedup_cols=["signal_id", "reason"])
            state["counters"]["blocked"] += 1
        send_signal_issue_telegram_once(
            logger,
            state,
            signal=signal,
            stage="plan",
            status=status,
            reason=plan_reason,
            account=account,
            open_risk=open_risk,
            live_armed=live_armed,
            live_blockers=live_blockers,
        )
        return plan_reason

    if not live_armed:
        reason = "paper_mode_or_live_not_armed_no_order_send"
        row = audit_row("paper_execute", "paper_executed", reason, signal=signal, plan=plan, account=account, open_risk=open_risk, live_armed=live_armed, live_blockers=live_blockers)
        append_rows_csv(EXECUTION_AUDIT_CSV, [row])
        append_rows_csv(EXECUTED_TRADES_CSV, [row], dedup_cols=["signal_id"])
        append_jsonl(BOT_OUTPUT_DIR / "portfolio_executed_trades.jsonl", [row])
        mark_terminal(state, plan.signal_id, "paper_executed", reason, {"plan": asdict(plan)})
        clear_transient_order_retry(state, plan.signal_id)
        state["counters"]["paper_trades"] += 1
        if SEND_EXECUTION_TELEGRAM:
            send_telegram_logged(
                logger,
                state,
                "paper_trade",
                f"🧪 V2 PAPER PORTFOLIO TRADE\n"
                f"{plan.asset} {plan.side_name.upper()} | {plan.edge_id}\n"
                f"p={safe_float(signal.get('calibrated_probability'), 0.0):.4f} thr={safe_float(signal.get('final_live_threshold'), 0.0):.4f}\n"
                f"risk model_target=${plan.model_target_risk_usd:.2f} sizing_target=${plan.target_risk_usd:.2f} broker_actual=${plan.actual_risk_usd:.2f}\n"
                f"actual_pct={plan.actual_risk_pct:.4%} inflation={risk_inflation_display(plan)} min_lot={plan.used_min_lot_fallback}\n"
                f"vol={plan.volume} entry={plan.entry_price} SL={plan.stop_loss} TP={plan.take_profit}",
            )
        return reason

    row = audit_row("submit", "submitting", "sending_order", signal=signal, plan=plan, account=account, open_risk=open_risk, live_armed=live_armed, live_blockers=live_blockers)
    append_rows_csv(EXECUTION_AUDIT_CSV, [row])
    result, order_attempts = submit_order_with_filling_retry(mt5, plan, logger, state)
    if result is not None and int(result.retcode) == int(mt5.TRADE_RETCODE_DONE):
        reason = "order_executed"
        update_position_metadata_after_order(mt5, state, plan, signal, result)
        post_fill = post_fill_risk_guard(mt5, manifest, state, plan, signal, result, logger)
        if post_fill.get("breach"):
            reason = (
                "order_executed_post_fill_risk_breach_emergency_reduced"
                if post_fill.get("close_success")
                else "order_executed_post_fill_risk_breach_reduce_failed"
            )
        row = audit_row("result", "executed", reason, signal=signal, plan=plan, account=account, open_risk=open_risk, result=result, live_armed=live_armed, live_blockers=live_blockers)
        row["post_fill_risk_guard_json"] = json.dumps(post_fill, default=str, sort_keys=True)
        row["order_send_attempts_json"] = json.dumps(order_attempts, default=str, sort_keys=True)
        append_rows_csv(EXECUTION_AUDIT_CSV, [row])
        append_rows_csv(EXECUTED_TRADES_CSV, [row], dedup_cols=["signal_id"])
        append_jsonl(BOT_OUTPUT_DIR / "portfolio_executed_trades.jsonl", [row])
        mark_terminal(state, plan.signal_id, "executed", reason, {
            "plan": asdict(plan), "retcode": int(result.retcode),
            "order_send_attempts": order_attempts, "post_fill_risk_guard": post_fill,
        })
        clear_transient_order_retry(state, plan.signal_id)
        state["counters"]["live_trades"] += 1
        if SEND_EXECUTION_TELEGRAM:
            send_telegram_logged(
                logger,
                state,
                "live_trade",
                f"✅ V2 PORTFOLIO TRADE EXECUTED\n"
                f"{plan.asset} {plan.side_name.upper()} | {plan.edge_id}\n"
                f"risk model_target=${plan.model_target_risk_usd:.2f} sizing_target=${plan.target_risk_usd:.2f} broker_actual=${plan.actual_risk_usd:.2f}\n"
                f"actual_pct={plan.actual_risk_pct:.4%} inflation={risk_inflation_display(plan)} min_lot={plan.used_min_lot_fallback}\n"
                f"vol={plan.volume} entry={plan.entry_price} SL={plan.stop_loss} TP={plan.take_profit}\n"
                f"order={getattr(result, 'order', '')} deal={getattr(result, 'deal', '')}",
            )
        return reason

    retcode = getattr(result, "retcode", None) if result is not None else None
    retname = get_retcode_name(mt5, retcode)
    broker_comment = getattr(result, "comment", "order_send returned None") if result is not None else "order_send returned None"
    attempts_text = json.dumps(order_attempts, default=str, sort_keys=True)

    transient_reason = transient_order_result_reason(mt5, result)
    if transient_reason is not None:
        retry = record_transient_order_retry(state, plan, result, transient_reason)
        reason = (
            f"transient_order_retry:{transient_reason}; "
            f"attempt_count={retry['attempt_count']}; "
            f"next_retry_at={retry['next_retry_at']}; "
            f"filling_attempts={attempts_text}"
        )
        row = audit_row(
            "result",
            "transient_wait",
            reason,
            signal=signal,
            plan=plan,
            account=account,
            open_risk=open_risk,
            result=result,
            live_armed=live_armed,
            live_blockers=live_blockers,
        )
        row["order_send_attempts_json"] = attempts_text
        row["transient_retry_json"] = json.dumps(retry, default=str, sort_keys=True)
        append_rows_csv(EXECUTION_AUDIT_CSV, [row])
        state["counters"]["transient_waits"] += 1
        send_signal_issue_telegram_once(
            logger,
            state,
            signal=signal,
            stage="order_send",
            status="transient_wait",
            reason=reason,
            account=account,
            open_risk=open_risk,
            live_armed=live_armed,
            live_blockers=live_blockers,
        )
        return reason

    reason = f"order_rejected:{retcode}:{retname}:{broker_comment}; filling_attempts={attempts_text}"
    row = audit_row("result", "order_rejected", reason, signal=signal, plan=plan, account=account, open_risk=open_risk, result=result, live_armed=live_armed, live_blockers=live_blockers)
    row["order_send_attempts_json"] = attempts_text
    append_rows_csv(EXECUTION_AUDIT_CSV, [row])
    append_rows_csv(REJECTED_SIGNALS_CSV, [row], dedup_cols=["signal_id", "reason"])
    mark_terminal(state, plan.signal_id, "order_rejected", reason, {"plan": asdict(plan), "retcode": retcode, "order_send_attempts": order_attempts})
    clear_transient_order_retry(state, plan.signal_id)
    state["counters"]["blocked"] += 1
    if SEND_REJECTION_TELEGRAM:
        send_telegram_logged(
            logger,
            state,
            "order_rejected",
            f"❌ V2 PORTFOLIO ORDER REJECTED\n{plan.asset} {plan.side_name.upper()} {plan.edge_id}\n{reason}",
        )
    return reason


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true", help="Run one polling cycle, then exit.")
    parser.add_argument("--max-loops", type=int, default=None, help="Stop after N loops.")
    args = parser.parse_args()

    ensure_runtime_dirs()
    logger = setup_logger("portfolio_execution_bot", LOG_PATH)
    logger.info("=" * 100)
    logger.info("V2 PORTFOLIO EXECUTION BOT version=%s mode=%s enable_order_send=%s", BOT_VERSION, EXECUTION_MODE, ENABLE_ORDER_SEND)
    logger.info(
        "STAGE_AWARE_POST_FILL_GUARD account_stage=%s funded_symbol_stress_multiplier=%s post_fill_check=%s emergency_reduce=%s",
        getattr(settings, "PORTFOLIO_ACCOUNT_STAGE", "challenge"),
        DEFAULT_SYMBOL_RISK_STRESS_MULTIPLIER, POST_FILL_RISK_CHECK_ENABLED, POST_FILL_EMERGENCY_REDUCE_ENABLED,
    )
    logger.info("=" * 100)
    tg_config = telegram_config_snapshot()
    logger.info(
        "TELEGRAM_CONFIG token_present=%s token_length=%s chat_ids_count=%s masked_chat_ids=%s "
        "requests_available=%s startup_enabled=%s execution_enabled=%s rejection_enabled=%s",
        tg_config["token_present"],
        tg_config["token_length"],
        tg_config["chat_ids_count"],
        tg_config["masked_chat_ids"],
        tg_config["requests_available"],
        tg_config["send_startup_enabled"],
        tg_config["send_execution_enabled"],
        tg_config["send_rejection_enabled"],
    )

    if EXECUTION_MODE not in {"paper", "live"}:
        raise RuntimeError(f"Invalid PORTFOLIO_EXECUTION_MODE={EXECUTION_MODE}. Use 'paper' or 'live'.")

    manifest = load_live_manifest()
    policy = load_live_bar_policy()
    validate_live_manifest(manifest)
    edge_lookup = selected_edge_lookup(manifest)
    current_hashes = {
        "live_manifest_hash": hash_or_none(settings.LIVE_MANIFEST_PATH),
        "bar_policy_hash": hash_or_none(LIVE_BAR_POLICY_PATH),
        "selected_variant_contract_hash": manifest.get("selected_variant_contract_hash"),
    }
    live_armed, live_blockers = real_order_send_armed(manifest, policy)
    if EXECUTION_MODE == "live" and not live_armed:
        logger.warning("LIVE_MODE_REQUESTED_BUT_NOT_ARMED — bot will NOT send real orders. blockers=%s", live_blockers)

    state = load_state()
    state["last_manifest_hash"] = current_hashes.get("live_manifest_hash")
    state["last_bar_policy_hash"] = current_hashes.get("bar_policy_hash")

    mt5 = None
    last_action = "starting"
    last_heartbeat = 0.0
    loops = 0
    shutdown_event = threading.Event()
    previous_signal_handlers: dict[int, Any] = {}

    def _request_shutdown(signum: int, _frame: Any) -> None:
        if not shutdown_event.is_set():
            logger.info(
                "Shutdown requested by signal=%s. Current operation will finish before state is saved.",
                signum,
            )
        shutdown_event.set()

    for sig_name in ("SIGINT", "SIGTERM"):
        sig = getattr(signal, sig_name, None)
        if sig is None:
            continue
        try:
            previous_signal_handlers[int(sig)] = signal.getsignal(sig)
            signal.signal(sig, _request_shutdown)
        except (ValueError, OSError):
            pass

    try:
        mt5, account = init_mt5()
        logger.info(
            "MT5_CONNECTED login=%s balance=%.2f equity=%.2f server=%s",
            getattr(account, "login", ""),
            float(getattr(account, "balance", 0.0)),
            float(getattr(account, "equity", 0.0)),
            getattr(account, "server", ""),
        )
        select_symbols(mt5, manifest, logger)
        if SEND_STARTUP_TELEGRAM:
            send_telegram_logged(
                logger,
                state,
                "startup",
                f"🤖 V2 PORTFOLIO EXECUTION BOT ONLINE\nmode={EXECUTION_MODE} order_send={live_armed}\nversion={BOT_VERSION}",
            )

        while not shutdown_event.is_set():
            loops += 1
            try:
                # Reload manifest/policy hashes every loop so stale signals are blocked after config changes.
                manifest = load_live_manifest()
                policy = load_live_bar_policy()
                validate_live_manifest(manifest)
                edge_lookup = selected_edge_lookup(manifest)
                current_hashes = {
                    "live_manifest_hash": hash_or_none(settings.LIVE_MANIFEST_PATH),
                    "bar_policy_hash": hash_or_none(LIVE_BAR_POLICY_PATH),
                    "selected_variant_contract_hash": manifest.get("selected_variant_contract_hash"),
                }
                live_armed, live_blockers = real_order_send_armed(manifest, policy)

                account = mt5.account_info()
                open_risk = get_open_risk_snapshot(mt5, manifest, state, logger)
                attach_prop_risk_context(mt5, manifest, account, open_risk, state)
                vertical_actions = enforce_vertical_horizon_exits(mt5, manifest, state, live_armed, logger)
                if vertical_actions:
                    last_action = vertical_actions[-1]
                    account = mt5.account_info() or account
                    open_risk = get_open_risk_snapshot(mt5, manifest, state, logger)
                    attach_prop_risk_context(mt5, manifest, account, open_risk, state)
                df = read_approved_signal_rows(logger)
                rows = candidate_rows(df, state)
                state["counters"]["seen_candidates"] += len(rows)

                if time.time() - last_heartbeat >= HEARTBEAT_SECONDS:
                    print_heartbeat(account, open_risk, len(rows), last_action, live_armed, live_blockers)
                    write_status(state, account, open_risk, live_armed, live_blockers, {
                        "pending_candidate_count": len(rows),
                        "last_action": last_action,
                        "loop": loops,
                        "live_manifest_hash": current_hashes.get("live_manifest_hash"),
                        "bar_policy_hash": current_hashes.get("bar_policy_hash"),
                    })
                    save_state(state)
                    last_heartbeat = time.time()

                if rows:
                    logger.info("CANDIDATES_PENDING count=%s", len(rows))
                for signal_row in rows:
                    if shutdown_event.is_set():
                        break
                    last_action = process_signal(
                        mt5,
                        manifest,
                        policy,
                        edge_lookup,
                        current_hashes,
                        state,
                        signal_row,
                        live_armed,
                        live_blockers,
                        logger,
                    )
                    save_state(state)

                if args.once or (args.max_loops is not None and loops >= args.max_loops):
                    break
                shutdown_event.wait(POLL_SECONDS)
            except KeyboardInterrupt:
                logger.info("KeyboardInterrupt received. Finishing shutdown.")
                shutdown_event.set()
                save_state(state)
                break
            except Exception as exc:
                state["counters"]["errors"] += 1
                last_action = f"loop_error:{type(exc).__name__}:{exc}"
                logger.error("LOOP_ERROR %s", last_action)
                logger.error(traceback.format_exc())
                save_state(state)
                if args.once:
                    raise
                shutdown_event.wait(3)
    finally:
        shutdown_event.set()
        save_state(state)
        if mt5 is not None:
            shutdown_mt5(mt5)
        for sig_value, previous in previous_signal_handlers.items():
            try:
                signal.signal(sig_value, previous)
            except (ValueError, OSError):
                pass
        save_state(state)
        logger.info(
            "Execution bot stopped cleanly. State saved: %s pending_transient_retries=%s",
            STATE_PATH,
            len(state.get("transient_order_retry_by_signal", {})),
        )


if __name__ == "__main__":
    main()
