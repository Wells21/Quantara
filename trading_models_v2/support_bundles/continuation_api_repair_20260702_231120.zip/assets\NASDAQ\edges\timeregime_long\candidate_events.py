"""
Candidate event generation for NASDAQ/timeregime_long.

V1 source:
- NASDAQ/time-regime-independent-edge/4_time_regime_event_sampling.py

Core V1 idea:
- Build same-hour time-of-day statistical bias from past-only Bar_Return history.
- Confirm activity with a price-only Bar_Volatility_Bps ratio against its own past median.
- Block rollover hours.
- Time_Regime_Event_Type is directional: +1 positive time bias, -1 negative time bias.

V2 side-specialization:
- This module generates raw +/- time-regime events.
- primary_side.py filters this edge to Time_Regime_Event_Type=+1 -> side=+1 long.
- Time-regime fields are event/control/context fields, not generic model-schema features.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

EDGE_ID = "NASDAQ/timeregime_long"
SIDE_VALUE = 1
CANDIDATE_EVENT_GENERATOR = "timeregime_long_v1_time_regime_statistical_bias_candidate_events"

MIN_GAP_BARS = 3
BIAS_WINDOW = 60
TIME_TSTAT_THRESHOLD = 0.50
VOLATILITY_RATIO_THRESHOLD = 1.10
MIN_OBS = 20
EVENT_VOL_LOOKBACK = 50
EVENT_VOL_EWM_SPAN = 100
MIN_VOL = 1e-8
EPS = 1e-12

EVENT_CONTEXT_COLUMNS = [
    "Event_Vol",
    "Hour_UTC",
    "Day_Of_Week",
    "Time_Bucket",
    "Bar_Return",
    "Time_Bias_Mean",
    "Time_Bias_Std",
    "Time_Bias_TStat",
    "Volatility_Ratio",
    "Time_Regime_Event_Type",
    "Body_Direction",
    "Body_Share",
    "Close_Location",
    "Regime_State",
    "Regime_Entropy",
    "Regime_Duration",
    "Prob_State_0",
    "Prob_State_1",
    "Prob_State_2",
    "Prob_State_3",
]


class CandidateEventError(RuntimeError):
    """Raised when candidate event generation must fail closed."""


def time_bucket(hour: int) -> str:
    if 0 <= int(hour) < 7:
        return "asia"
    if 7 <= int(hour) < 12:
        return "london"
    if 12 <= int(hour) < 17:
        return "ny_overlap"
    if 17 <= int(hour) < 22:
        return "late_ny"
    return "rollover"


def _required_event_columns() -> list[str]:
    return [
        "Datetime",
        "Bar_Start",
        "edge_id",
        "side",
        "Event_Vol",
        "event_id",
        "candidate_event_generator",
        "Time_Regime_Event_Type",
        "Time_Bias_TStat",
        "Volatility_Ratio",
        "Time_Bucket",
        "event_known_after_close",
        "uses_future_information",
    ]


def _forbidden_event_columns() -> set[str]:
    return {
        "meta_label",
        "t1",
        "barrier_hit",
        "resolution_source",
        "entry_price",
        "pt_price",
        "sl_price",
        "realized_r",
        "raw_probability",
        "calibrated_probability",
        "afml_bet_size",
        "approved_signal",
        "Proxy_Value",
        "Tick_Activity_Ratio",
        "Proxy_Value_Ratio",
        "Activity_Impulse",
    }


def _normalize_feature_input(features: pd.DataFrame) -> pd.DataFrame:
    required = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close", "Bar_Volatility_Bps"]
    missing = [col for col in required if col not in features.columns]
    if missing:
        raise CandidateEventError(f"Input features missing required time-regime columns: {missing}")

    df = features.copy()
    df["Datetime"] = pd.to_datetime(df["Datetime"], utc=True, errors="coerce")
    df["Bar_Start"] = pd.to_datetime(df["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open",
        "High",
        "Low",
        "Close",
        "Bar_Volatility_Bps",
        "Regime_State",
        "Regime_Entropy",
        "Regime_Duration",
        "Prob_State_0",
        "Prob_State_1",
        "Prob_State_2",
        "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in df.columns]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=required).copy()
    df = df.sort_values("Datetime").reset_index(drop=True)
    if df.empty:
        raise CandidateEventError("Input features are empty after normalization.")
    return df


def add_v1_time_regime_features(features: pd.DataFrame) -> pd.DataFrame:
    """Add V1 Step 4 time-regime event fields.

    Same-hour bias statistics are shifted by one observation inside each hour
    group, so the current event bar never sees its own return.
    """

    out = _normalize_feature_input(features)
    open_ = out["Open"].astype("float64")
    high = out["High"].astype("float64")
    low = out["Low"].astype("float64")
    close = out["Close"].astype("float64")

    out["Hour_UTC"] = out["Datetime"].dt.hour.astype("int64")
    out["Day_Of_Week"] = out["Datetime"].dt.dayofweek.astype("int64")
    out["Time_Bucket"] = out["Hour_UTC"].map(time_bucket)
    out["Bar_Return"] = np.log((close + EPS) / (close.shift(1) + EPS))

    grouped = out.groupby("Hour_UTC", group_keys=False)["Bar_Return"]
    out["Time_Bias_Mean"] = grouped.transform(
        lambda x: x.shift(1).rolling(BIAS_WINDOW, min_periods=MIN_OBS).mean()
    )
    out["Time_Bias_Std"] = grouped.transform(
        lambda x: x.shift(1).rolling(BIAS_WINDOW, min_periods=MIN_OBS).std()
    )
    out["Time_Bias_TStat"] = out["Time_Bias_Mean"] / (
        (out["Time_Bias_Std"] + EPS) / np.sqrt(float(BIAS_WINDOW))
    )

    out["Volatility_Ratio"] = out["Bar_Volatility_Bps"] / (
        out["Bar_Volatility_Bps"].rolling(100).median().shift(1) + EPS
    )

    bar_range = (high - low).clip(lower=EPS)
    body = close - open_
    out["Body_Direction"] = np.sign(body)
    out["Body_Share"] = body.abs() / (bar_range + EPS)
    out["Close_Location"] = (close - low) / (bar_range + EPS)

    ret = np.log((close + EPS) / (close.shift(EVENT_VOL_LOOKBACK) + EPS))
    out["Event_Vol"] = ret.ewm(span=EVENT_VOL_EWM_SPAN, adjust=False).std().clip(lower=MIN_VOL)

    out["Time_Regime_Event_Type"] = 0
    long_mask = (
        (out["Time_Bias_TStat"] >= TIME_TSTAT_THRESHOLD)
        & (out["Volatility_Ratio"] >= VOLATILITY_RATIO_THRESHOLD)
        & (out["Time_Bucket"] != "rollover")
    )
    short_mask = (
        (out["Time_Bias_TStat"] <= -TIME_TSTAT_THRESHOLD)
        & (out["Volatility_Ratio"] >= VOLATILITY_RATIO_THRESHOLD)
        & (out["Time_Bucket"] != "rollover")
    )
    out.loc[long_mask, "Time_Regime_Event_Type"] = 1
    out.loc[short_mask, "Time_Regime_Event_Type"] = -1

    out.replace([np.inf, -np.inf], np.nan, inplace=True)
    return out


def _extract_v1_spaced_time_regime_events(
    features: pd.DataFrame,
    *,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    if min_gap_bars < 0:
        raise CandidateEventError("min_gap_bars must be >= 0")
    if "Time_Regime_Event_Type" not in features.columns:
        raise CandidateEventError("Feature table missing Time_Regime_Event_Type")

    selected_indices: list[int] = []
    last_event_i = -10**9
    event_types = pd.to_numeric(features["Time_Regime_Event_Type"], errors="coerce").to_numpy(dtype="float64")

    for i, event_type in enumerate(event_types):
        if not np.isfinite(event_type) or event_type == 0:
            continue
        if i - last_event_i < min_gap_bars:
            continue
        selected_indices.append(i)
        last_event_i = i

    if not selected_indices:
        return features.iloc[[]].copy()
    return features.iloc[selected_indices].copy().reset_index(drop=True)


def _validate_candidate_events(events: pd.DataFrame) -> None:
    missing = [col for col in _required_event_columns() if col not in events.columns]
    if missing:
        raise CandidateEventError(f"Candidate events missing required columns: {missing}")
    if events.empty:
        raise CandidateEventError("Candidate event generator produced zero timeregime_long events.")

    forbidden_present = sorted(_forbidden_event_columns().intersection(events.columns))
    if forbidden_present:
        raise CandidateEventError(f"Candidate events contain forbidden research/live-decision or volume-proxy columns: {forbidden_present}")
    if not (events["edge_id"] == EDGE_ID).all():
        raise CandidateEventError("Candidate events contain unexpected edge_id values.")
    sides = pd.to_numeric(events["side"], errors="coerce")
    if not sides.isin([-1, 1]).all():
        raise CandidateEventError("Time-regime raw candidate sides must be +/-1 from Time_Regime_Event_Type.")
    if not (events["candidate_event_generator"] == CANDIDATE_EVENT_GENERATOR).all():
        raise CandidateEventError("Candidate events contain unexpected generator values.")
    event_types = pd.to_numeric(events["Time_Regime_Event_Type"], errors="coerce")
    if not event_types.isin([-1, 1]).all():
        raise CandidateEventError("Time_Regime_Event_Type must be -1 or +1.")
    if (events["Time_Bucket"].astype(str) == "rollover").any():
        raise CandidateEventError("Rollover events must be blocked for timeregime_long.")
    if events["uses_future_information"].astype(bool).any():
        raise CandidateEventError("Candidate events must not use future information.")
    if not events["event_known_after_close"].astype(bool).all():
        raise CandidateEventError("Candidate events must be known after bar close.")
    if not np.isfinite(pd.to_numeric(events["Event_Vol"], errors="coerce").to_numpy(dtype="float64")).all():
        raise CandidateEventError("Candidate events contain non-finite Event_Vol values.")


def generate_v1_timeregime_long_candidate_events(
    features: pd.DataFrame,
    *,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    """Generate V1 Step 4 price-only time-regime events.

    This returns raw +/- time-regime events with side=Time_Regime_Event_Type.
    primary_side.py performs V2 long-only filtering.
    """

    expanded = add_v1_time_regime_features(features)
    spaced = _extract_v1_spaced_time_regime_events(expanded, min_gap_bars=min_gap_bars)
    if spaced.empty:
        spaced = pd.DataFrame(columns=["Datetime", "Bar_Start", *EVENT_CONTEXT_COLUMNS])

    keep_cols = [
        "Datetime", "Bar_Start", "Open", "High", "Low", "Close",
        *[col for col in EVENT_CONTEXT_COLUMNS if col in spaced.columns],
    ]
    events = spaced[[col for col in keep_cols if col in spaced.columns]].copy()

    events["edge_id"] = EDGE_ID
    events["side"] = pd.to_numeric(events["Time_Regime_Event_Type"], errors="coerce").astype("int64")
    events["event_id"] = events["Datetime"].apply(
        lambda ts: f"{EDGE_ID}|{pd.Timestamp(ts).isoformat()}|time_regime"
    )
    events["candidate_event_generator"] = CANDIDATE_EVENT_GENERATOR
    events["event_known_after_close"] = True
    events["uses_future_information"] = False
    events["bias_window"] = int(BIAS_WINDOW)
    events["time_tstat_threshold"] = float(TIME_TSTAT_THRESHOLD)
    events["volatility_ratio_threshold"] = float(VOLATILITY_RATIO_THRESHOLD)
    events["min_gap_bars"] = int(min_gap_bars)
    events["event_vol_lookback"] = int(EVENT_VOL_LOOKBACK)
    events["event_vol_ewm_span"] = int(EVENT_VOL_EWM_SPAN)

    events["Datetime"] = pd.to_datetime(events["Datetime"], utc=True, errors="coerce")
    events["Bar_Start"] = pd.to_datetime(events["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open", "High", "Low", "Close", "side", "Event_Vol", "Hour_UTC", "Day_Of_Week",
        "Bar_Return", "Time_Bias_Mean", "Time_Bias_Std", "Time_Bias_TStat", "Volatility_Ratio",
        "Time_Regime_Event_Type", "Body_Direction", "Body_Share", "Close_Location",
        "Regime_State", "Regime_Entropy", "Regime_Duration",
        "Prob_State_0", "Prob_State_1", "Prob_State_2", "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in events.columns]:
        events[col] = pd.to_numeric(events[col], errors="coerce")
    events = events.dropna(
        subset=["Datetime", "Bar_Start", "Event_Vol", "Time_Regime_Event_Type", "Time_Bias_TStat", "Volatility_Ratio"]
    ).copy()
    events = events[events["side"].isin([-1, 1])].copy()
    events = events.sort_values("Datetime").reset_index(drop=True)

    ordered_cols = [
        "Datetime", "Bar_Start", "edge_id", "side", "Event_Vol", "event_id", "candidate_event_generator",
        "Time_Regime_Event_Type", "Time_Bias_TStat", "Volatility_Ratio", "Hour_UTC", "Day_Of_Week", "Time_Bucket",
        "Time_Bias_Mean", "Time_Bias_Std", "Bar_Return", "Body_Direction", "Body_Share", "Close_Location",
        "event_known_after_close", "uses_future_information",
        *[col for col in events.columns if col not in _required_event_columns() and col not in {
            "Hour_UTC", "Day_Of_Week", "Time_Bias_Mean", "Time_Bias_Std", "Bar_Return", "Body_Direction", "Body_Share", "Close_Location"
        }],
    ]
    events = events[[col for col in ordered_cols if col in events.columns]].copy()

    _validate_candidate_events(events)
    return events


def validate_candidate_events(events: pd.DataFrame) -> None:
    _validate_candidate_events(events)


def candidate_event_contract() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "candidate_event_generator": CANDIDATE_EVENT_GENERATOR,
        "event_logic": "past-only same-hour time bias + price-only volatility ratio activity gate",
        "bias_window": BIAS_WINDOW,
        "time_tstat_threshold": TIME_TSTAT_THRESHOLD,
        "volatility_ratio_threshold": VOLATILITY_RATIO_THRESHOLD,
        "min_gap_bars": MIN_GAP_BARS,
        "event_vol_lookback": EVENT_VOL_LOOKBACK,
        "event_vol_ewm_span": EVENT_VOL_EWM_SPAN,
        "side_rule_raw": "side = Time_Regime_Event_Type; primary_side.py filters +1 for timeregime_long",
        "price_only_event_gate": True,
        "forbidden_volume_proxy_inputs": ["Ticks", "Proxy_Value", "Tick_Activity_Ratio", "Proxy_Value_Ratio", "Activity_Impulse"],
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
        "v1_reference": "NASDAQ/time-regime-independent-edge/4_time_regime_event_sampling.py",
    }


if __name__ == "__main__":
    print("✅ NASDAQ/timeregime_long candidate_events.py import/self-contract check passed.")
    print(candidate_event_contract())
