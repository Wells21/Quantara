"""
Primary-side logic for NASDAQ/absorption_long.

This module ports V1 Step 5A absorption primary-side mapping into the V2 edge
package boundary.

V1 reference:
- Absorption_Event_Type +1 = upside displacement failed -> side -1 short.
- Absorption_Event_Type -1 = downside displacement failed -> side +1 long.

V2 side-specialization:
- absorption_long accepts long-side absorption events only.
- side is fixed to +1.
- accepted events must have Absorption_Event_Type=-1.
- no trend filter is added here because V1 5A did not use one.

V2 contract:
- FFD loader is provided here so feature_expansion.py can keep the same edge-local
  helper structure used by trend_long/trend_short.
- This module does not create labels, probabilities, AFML sizes, or approved signals.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

_THIS_FILE = Path(__file__).resolve()
_EDGE_ROOT = _THIS_FILE.parent
_V2_ROOT = _THIS_FILE.parents[4]
_REPO_ROOT = _THIS_FILE.parents[5]
for _path in (_EDGE_ROOT, _V2_ROOT, _REPO_ROOT):
    path_str = str(_path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from shared.ffd.verify_asset_ffd_manifest import verify_asset_ffd_manifest  # noqa: E402

EDGE_ID = "NASDAQ/absorption_long"
ASSET = "NASDAQ"
SIDE_VALUE = 1
ABSORPTION_EVENT_TYPE = -1
LIVE_BUFFER_BARS = 250

FORBIDDEN_PRIMARY_SIDE_COLUMNS = {
    "meta_label",
    "t1",
    "barrier_hit",
    "resolution_source",
    "entry_price",
    "pt_price",
    "sl_price",
    "realized_r",
    "raw_probability",
    "calibrated_probability",
    "afml_bet_size",
    "approved_signal",
}


class PrimarySideError(RuntimeError):
    """Raised when primary-side generation must fail closed."""


def load_verified_ffd_features(asset: str = ASSET) -> pd.DataFrame:
    """Load verified shared asset-level FFD features.

    This keeps absorption_long helper structure aligned with trend_long/trend_short:
    feature_expansion.py imports this function from the edge's primary_side.py.
    """

    verification = verify_asset_ffd_manifest(asset)
    path = _V2_ROOT / verification["features"]
    if not path.exists():
        raise PrimarySideError(f"Verified FFD features path does not exist: {path}")

    ffd = pd.read_csv(path)
    required = ["Datetime", "Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]
    missing = [col for col in required if col not in ffd.columns]
    if missing:
        raise PrimarySideError(f"FFD features missing required columns: {missing}")

    ffd["Datetime"] = pd.to_datetime(ffd["Datetime"], utc=True, errors="coerce")
    for col in ["Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]:
        ffd[col] = pd.to_numeric(ffd[col], errors="coerce")
    ffd = ffd.dropna(subset=required).copy()
    ffd = ffd.sort_values("Datetime").reset_index(drop=True)
    if ffd.empty:
        raise PrimarySideError("Verified FFD features are empty after normalization.")
    return ffd


def _validate_primary_side_input(events: pd.DataFrame) -> pd.DataFrame:
    required = ["Datetime", "edge_id", "side", "Absorption_Event_Type", "Event_Vol"]
    missing = [col for col in required if col not in events.columns]
    if missing:
        raise PrimarySideError(f"Primary-side input missing required columns: {missing}")

    forbidden_present = sorted(FORBIDDEN_PRIMARY_SIDE_COLUMNS.intersection(events.columns))
    if forbidden_present:
        raise PrimarySideError(
            f"Primary-side input contains forbidden research/live-decision columns: {forbidden_present}"
        )

    out = events.copy()
    out["Datetime"] = pd.to_datetime(out["Datetime"], utc=True, errors="coerce")
    if "Bar_Start" in out.columns:
        out["Bar_Start"] = pd.to_datetime(out["Bar_Start"], utc=True, errors="coerce")
    out["side"] = pd.to_numeric(out["side"], errors="coerce")
    out["Absorption_Event_Type"] = pd.to_numeric(out["Absorption_Event_Type"], errors="coerce")
    out["Event_Vol"] = pd.to_numeric(out["Event_Vol"], errors="coerce")
    out = out.dropna(subset=["Datetime", "side", "Absorption_Event_Type", "Event_Vol"]).copy()
    if out.empty:
        raise PrimarySideError("Primary-side input is empty after normalization.")
    if not (out["edge_id"] == EDGE_ID).all():
        bad = out.loc[out["edge_id"] != EDGE_ID, "edge_id"].unique().tolist()
        raise PrimarySideError(f"absorption_long primary side received wrong edge_id values: {bad}")
    return out.sort_values("Datetime").reset_index(drop=True)


def assign_absorption_long_primary_side(events: pd.DataFrame) -> pd.DataFrame:
    """Apply V1 Step 5A side mapping for the side-specialized long edge.

    Because candidate_events.py already emits only downside failed-displacement
    events, this function acts as a strict validation and fail-closed mapper.
    """

    out = _validate_primary_side_input(events)

    out["primary_side_rule"] = "Absorption_Event_Type=-1 -> side=+1 long"
    out["primary_side"] = np.where(out["Absorption_Event_Type"] == ABSORPTION_EVENT_TYPE, SIDE_VALUE, 0).astype("int64")
    out["primary_side_filter"] = (out["primary_side"] == SIDE_VALUE).astype("int64")
    out = out[out["primary_side_filter"] == 1].copy()

    if out.empty:
        raise PrimarySideError("No absorption_long events survived primary-side mapping.")
    if not (out["Absorption_Event_Type"] == ABSORPTION_EVENT_TYPE).all():
        raise PrimarySideError("absorption_long primary side must only accept Absorption_Event_Type=-1.")
    if not (out["primary_side"] == SIDE_VALUE).all():
        raise PrimarySideError("absorption_long primary_side must be +1 only.")

    out["side"] = SIDE_VALUE
    return out.sort_values("Datetime").reset_index(drop=True)


def filter_long_events_with_primary_side(events: pd.DataFrame, features: pd.DataFrame | None = None) -> pd.DataFrame:
    """Public runtime hook for absorption_long event filtering.

    The `features` argument is accepted for parity with trend edge runtime calls,
    but V1 absorption 5A does not need additional feature context beyond the
    event's Absorption_Event_Type.
    """

    return assign_absorption_long_primary_side(events)


def validate_primary_side_events(events: pd.DataFrame) -> None:
    out = assign_absorption_long_primary_side(events)
    if out.empty:
        raise PrimarySideError("Validated absorption_long primary-side output is empty.")


def primary_side_config() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "side_value": SIDE_VALUE,
        "absorption_event_type": ABSORPTION_EVENT_TYPE,
        "side_rule": "Absorption_Event_Type=-1 -> side=+1 long",
        "uses_verified_shared_ffd": True,
        "live_buffer_bars": LIVE_BUFFER_BARS,
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
        "v1_reference": "NASDAQ/absorption-independent-edge/5a_absorption_primary_side_engine.py",
        "structure_parity": "edge-local primary_side.py with verified FFD loader, like trend_long/trend_short",
    }


if __name__ == "__main__":
    print("✅ NASDAQ/absorption_long primary_side.py import/self-contract check passed.")
    print(primary_side_config())
