"""
02_train_meta_model_optuna.py

V2 Step 02: V1-style final meta-model training with Optuna for the current edge package.

Blueprint boundary
------------------
This script trains the final raw-probability meta-model using selected features
from Step 01. It does NOT calibrate probability and does NOT select the final
live trading threshold.

Two supported run modes
-----------------------
1) Repo mode, from trading_models_v2:

    python ./assets/<ASSET>/edges/<FAMILY>_<SIDE>/research/02_train_meta_model_optuna.py

2) Flat Colab mode, from /content:

    Upload these files directly into /content:
        02_train_meta_model_optuna.py
        <edge_stem>_model_rows.csv
        <edge_stem>_selected_features.json
        feature_schema.json

    Then run:
        !python /content/02_train_meta_model_optuna.py

    Output files will be written directly into /content for easy download.

V1 logic preserved
------------------
- selected features from Step 01
- XGBoost binary meta-model
- Optuna tuning
- CPCV split generation
- manual t1 overlap purge
- manual embargo
- MLDP weights = class_weight_mode * Event_Vol * average_uniqueness
- train-fold-only F1 threshold selection for CPCV objective
- final model trained on all selected-feature rows

V2 additions
------------
- flat Colab mode
- feature_schema.json validation
- explicit trial/fold console progress so long Colab runs do not look frozen
- model remains non-deployable until OOF, sigmoid calibration, calibrated
  threshold sweep, runtime score wiring, and replay audit pass
- portable side/barrier contract checks inferred from edge folder or flat filenames
"""

from __future__ import annotations

import json
import warnings
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import optuna
import pandas as pd
import xgboost as xgb
from sklearn.metrics import f1_score, precision_score, recall_score
from sklearn.utils.class_weight import compute_sample_weight

try:
    from skfolio.model_selection import CombinatorialPurgedCV
except Exception as exc:  # pragma: no cover
    CombinatorialPurgedCV = None
    SKFOLIO_IMPORT_ERROR = exc
else:
    SKFOLIO_IMPORT_ERROR = None

warnings.filterwarnings("ignore")
optuna.logging.set_verbosity(optuna.logging.WARNING)

# =============================================================================
# CONFIG
# =============================================================================

THIS_FILE = Path(__file__).resolve()
CWD = Path.cwd().resolve()


def _looks_like_colab_root(path: Path) -> bool:
    return str(path).replace("\\", "/").rstrip("/") == "/content"


def _side_value_from_name(side: str) -> int:
    if side == "long":
        return 1
    if side == "short":
        return -1
    raise ValueError(f"Unsupported edge side: {side!r}. Expected 'long' or 'short'.")


def _parse_edge_segment(edge_segment: str) -> tuple[str, str]:
    family, sep, side = edge_segment.rpartition("_")
    if not sep or not family or side not in {"long", "short"}:
        raise ValueError(
            f"Cannot parse edge segment {edge_segment!r}. Expected '<family>_long' or '<family>_short'."
        )
    return family, side


def _context_from_edge_root(edge_root: Path) -> dict[str, Any]:
    asset = edge_root.parent.parent.name
    family, side = _parse_edge_segment(edge_root.name)
    edge_stem = f"{asset.lower()}_{family}_{side}"
    return {
        "asset": asset,
        "family": family,
        "side": side,
        "side_value": _side_value_from_name(side),
        "edge_id": f"{asset}/{family}_{side}",
        "edge_stem": edge_stem,
        "study_name": f"{edge_stem}_meta_model_xgb_f1_optuna",
    }


def _context_from_edge_stem(edge_stem: str) -> dict[str, Any]:
    parts = edge_stem.split("_")
    if len(parts) < 3:
        raise ValueError(f"Cannot parse edge stem {edge_stem!r}. Expected '<asset>_<family>_<side>'.")
    asset = parts[0].upper()
    side = parts[-1]
    family = "_".join(parts[1:-1])
    if side not in {"long", "short"} or not family:
        raise ValueError(f"Cannot parse edge stem {edge_stem!r}. Expected '<asset>_<family>_<side>'.")
    return {
        "asset": asset,
        "family": family,
        "side": side,
        "side_value": _side_value_from_name(side),
        "edge_id": f"{asset}/{family}_{side}",
        "edge_stem": edge_stem,
        "study_name": f"{edge_stem}_meta_model_xgb_f1_optuna",
    }


def _single_file(pattern: str, description: str) -> Path | None:
    matches = sorted(CWD.glob(pattern))
    if len(matches) == 0:
        return None
    if len(matches) > 1:
        raise ValueError(f"Flat mode found multiple {description} files for pattern {pattern!r}: {matches}")
    return matches[0]


def _resolve_paths() -> tuple[str, Path, Path, Path, Path, Path, dict[str, Any]]:
    flat_model_rows = _single_file("*_model_rows.csv", "model-row")
    flat_selected_features = _single_file("*_selected_features.json", "selected-feature")
    flat_feature_schema = CWD / "feature_schema.json"
    if _looks_like_colab_root(CWD) and flat_model_rows is not None and flat_selected_features is not None and flat_feature_schema.exists():
        rows_stem = flat_model_rows.name.removesuffix("_model_rows.csv")
        features_stem = flat_selected_features.name.removesuffix("_selected_features.json")
        if rows_stem != features_stem:
            raise ValueError(
                f"Flat mode edge stem mismatch: model rows stem={rows_stem!r}, selected features stem={features_stem!r}"
            )
        context = _context_from_edge_stem(rows_stem)
        return "flat_colab", CWD, CWD, flat_model_rows, flat_selected_features, flat_feature_schema, context

    edge_root = THIS_FILE.parents[1]
    v2_root = THIS_FILE.parents[5]
    context = _context_from_edge_root(edge_root)
    edge_stem = context["edge_stem"]
    model_rows_path = edge_root / "artifacts" / "research_dataset" / f"{edge_stem}_model_rows.csv"
    selected_features_path = edge_root / "artifacts" / "feature_surgery" / f"{edge_stem}_selected_features.json"
    feature_schema_path = edge_root / "contracts" / "feature_schema.json"
    return "repo", v2_root, edge_root, model_rows_path, selected_features_path, feature_schema_path, context


RUN_MODE, V2_ROOT, EDGE_ROOT, MODEL_ROWS_PATH, SELECTED_FEATURES_PATH, FEATURE_SCHEMA_PATH, EDGE_CONTEXT = _resolve_paths()
ASSET = EDGE_CONTEXT["asset"]
FAMILY = EDGE_CONTEXT["family"]
SIDE = EDGE_CONTEXT["side"]
SIDE_VALUE = EDGE_CONTEXT["side_value"]
EDGE_ID = EDGE_CONTEXT["edge_id"]
EDGE_STEM = EDGE_CONTEXT["edge_stem"]
STUDY_NAME = EDGE_CONTEXT["study_name"]

OUTPUT_DIR = CWD if RUN_MODE == "flat_colab" else EDGE_ROOT / "artifacts" / "model"

MODEL_OUTPUT = OUTPUT_DIR / f"{EDGE_STEM}_meta_model.pkl"
BEST_PARAMS_OUTPUT = OUTPUT_DIR / f"{EDGE_STEM}_meta_model_best_params.json"
FEATURE_IMPORTANCE_OUTPUT = OUTPUT_DIR / f"{EDGE_STEM}_meta_model_feature_importance.csv"
OPTUNA_TRIALS_OUTPUT = OUTPUT_DIR / f"{EDGE_STEM}_meta_model_optuna_trials.csv"
MANIFEST_OUTPUT = OUTPUT_DIR / "model_training_manifest.json"

TARGET_COL = "meta_label"
T1_COL = "t1"
EVENT_VOL_COL = "Event_Vol"
TIME_COL = "Datetime"

LEAKAGE_COLS = {
    TARGET_COL,
    T1_COL,
    "barrier_hit",
    "Bar_Start",
    "entry_price",
    "pt_price",
    "sl_price",
    "realized_r",
    "resolution_source",
    "raw_probability",
    "calibrated_probability",
    "afml_bet_size",
    "approved_signal",
}

# CPCV split generation only. Actual t1 overlap purge is manual below.
N_FOLDS = 5
N_TEST_FOLDS = 2
PURGED_SIZE = 0
EMBARGO_SIZE = 0
MANUAL_EMBARGO_SIZE = 100

# Optuna. Keep V1 default as 30. In Colab, edit N_TRIALS lower if debugging.
N_TRIALS = 30
OPTUNA_TIMEOUT = None
PRINT_FOLD_PROGRESS = True
PRINT_PARAMS_PER_TRIAL = True

F1_THRESHOLD_GRID = np.round(np.arange(0.30, 0.81, 0.01), 2)
RANDOM_STATE = 42


class MetaModelTrainingError(RuntimeError):
    """Raised when Step 02 must fail closed."""


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def json_default(obj: Any) -> Any:
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, pd.Timestamp):
        return obj.isoformat()
    return str(obj)


def save_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, default=json_default) + "\n", encoding="utf-8")


def display_path(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(V2_ROOT.resolve())).replace("\\", "/")
    except Exception:
        return str(path.resolve()).replace("\\", "/")


def load_json(path: Path) -> Any:
    if not path.exists():
        raise MetaModelTrainingError(f"Missing JSON file: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def get_xgb_device_kwargs() -> dict[str, Any]:
    try:
        major = int(xgb.__version__.split(".")[0])
    except Exception:
        major = 2
    if major >= 2:
        return {"tree_method": "hist", "device": "cuda"}
    return {"tree_method": "gpu_hist"}


def make_model(params: dict[str, Any]) -> xgb.XGBClassifier:
    model_params = {k: v for k, v in params.items() if k != "class_weight_mode"}
    return xgb.XGBClassifier(
        objective="binary:logistic",
        eval_metric="aucpr",
        random_state=RANDOM_STATE,
        n_jobs=-1,
        **get_xgb_device_kwargs(),
        **model_params,
    )


def fit_model_safely(model: xgb.XGBClassifier, x_train: pd.DataFrame, y_train: pd.Series, sample_weight: np.ndarray) -> xgb.XGBClassifier:
    try:
        model.fit(x_train, y_train, sample_weight=sample_weight)
        return model
    except Exception as exc:
        print(f"GPU/accelerated XGBoost fit failed; retrying on CPU. Reason: {exc}", flush=True)
        params = model.get_params()
        params.pop("device", None)
        params["tree_method"] = "hist"
        cpu_model = xgb.XGBClassifier(**params)
        cpu_model.fit(x_train, y_train, sample_weight=sample_weight)
        return cpu_model


def load_allowed_schema_features() -> set[str]:
    schema = load_json(FEATURE_SCHEMA_PATH)
    allowed = set()
    for row in schema.get("features", []):
        if (
            row.get("live_available") is True
            and row.get("allowed_for_model_input") is True
            and row.get("uses_future_information") is False
        ):
            allowed.add(str(row["feature_name"]))
    if not allowed:
        raise MetaModelTrainingError("No live-safe allowed model-input features found in feature_schema.json")
    return allowed


def load_selected_features() -> list[str]:
    features = load_json(SELECTED_FEATURES_PATH)
    if not isinstance(features, list) or not features:
        raise MetaModelTrainingError("Selected features JSON must be a non-empty list.")
    features = [str(f) for f in features]
    duplicates = sorted({f for f in features if features.count(f) > 1})
    if duplicates:
        raise MetaModelTrainingError(f"Duplicate selected features found: {duplicates}")
    bad = [f for f in features if f in LEAKAGE_COLS]
    if bad:
        raise MetaModelTrainingError(f"Selected features contain forbidden leakage columns: {bad}")
    allowed = load_allowed_schema_features()
    not_allowed = [f for f in features if f not in allowed]
    if not_allowed:
        raise MetaModelTrainingError(f"Selected features not allowed by feature_schema.json: {not_allowed}")
    return features


def _validate_edge_contract(df: pd.DataFrame) -> None:
    if "edge_id" in df.columns and not (df["edge_id"] == EDGE_ID).all():
        bad = df.loc[df["edge_id"] != EDGE_ID, "edge_id"].unique().tolist()
        raise MetaModelTrainingError(f"{EDGE_ID} model rows contain wrong edge_id values: {bad}")
    if "side" in df.columns and not (pd.to_numeric(df["side"], errors="coerce") == SIDE_VALUE).all():
        bad = df.loc[pd.to_numeric(df["side"], errors="coerce") != SIDE_VALUE, "side"].unique().tolist()
        raise MetaModelTrainingError(f"{EDGE_ID} model rows contain wrong side values: {bad}; expected {SIDE_VALUE}")
    if "pt_price" in df.columns and "entry_price" in df.columns:
        pt = pd.to_numeric(df["pt_price"], errors="coerce")
        entry = pd.to_numeric(df["entry_price"], errors="coerce")
        if SIDE_VALUE == 1 and not (pt > entry).all():
            raise MetaModelTrainingError(f"{EDGE_ID} model rows must have pt_price above entry_price for long edges.")
        if SIDE_VALUE == -1 and not (pt < entry).all():
            raise MetaModelTrainingError(f"{EDGE_ID} model rows must have pt_price below entry_price for short edges.")
    if "sl_price" in df.columns and "entry_price" in df.columns:
        sl = pd.to_numeric(df["sl_price"], errors="coerce")
        entry = pd.to_numeric(df["entry_price"], errors="coerce")
        if SIDE_VALUE == 1 and not (sl < entry).all():
            raise MetaModelTrainingError(f"{EDGE_ID} model rows must have sl_price below entry_price for long edges.")
        if SIDE_VALUE == -1 and not (sl > entry).all():
            raise MetaModelTrainingError(f"{EDGE_ID} model rows must have sl_price above entry_price for short edges.")


def load_dataset(selected_features: list[str]) -> pd.DataFrame:
    if not MODEL_ROWS_PATH.exists():
        raise MetaModelTrainingError(f"Missing model rows CSV: {MODEL_ROWS_PATH}")
    df = pd.read_csv(MODEL_ROWS_PATH)
    _validate_edge_contract(df)
    required = [TIME_COL, TARGET_COL, EVENT_VOL_COL, T1_COL, *selected_features]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise MetaModelTrainingError(f"Model rows missing required columns: {missing}")

    df[TIME_COL] = pd.to_datetime(df[TIME_COL], utc=True, errors="coerce")
    df[T1_COL] = pd.to_datetime(df[T1_COL], utc=True, errors="coerce")
    df[TARGET_COL] = pd.to_numeric(df[TARGET_COL], errors="coerce")
    df[EVENT_VOL_COL] = pd.to_numeric(df[EVENT_VOL_COL], errors="coerce")
    for col in selected_features:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    before = len(df)
    df = df.dropna(subset=[TIME_COL, T1_COL, TARGET_COL, EVENT_VOL_COL, *selected_features]).copy()
    after = len(df)
    if after == 0:
        raise MetaModelTrainingError("All rows dropped after selected-feature NaN filtering.")

    df[TARGET_COL] = df[TARGET_COL].astype(int)
    df = df.sort_values(TIME_COL).set_index(TIME_COL)
    if df[TARGET_COL].nunique() < 2:
        raise MetaModelTrainingError("meta_label has fewer than two classes.")

    print(f"Rows before selected-feature NaN filter: {before:,}", flush=True)
    print(f"Rows after selected-feature NaN filter : {after:,}", flush=True)
    return df


def compute_uniqueness(df: pd.DataFrame) -> np.ndarray:
    if len(df) == 0:
        return np.array([], dtype=float)
    work = df[[T1_COL]].copy().sort_index()
    work[T1_COL] = pd.to_datetime(work[T1_COL], utc=True, errors="coerce")
    n = len(work)
    index_ns = pd.DatetimeIndex(work.index).astype("int64").to_numpy()
    t1_series = work[T1_COL]
    start_pos = np.arange(n, dtype=int)
    end_pos = start_pos.copy()

    valid_t1 = ~t1_series.isna()
    if valid_t1.any():
        t1_ns = pd.DatetimeIndex(t1_series.loc[valid_t1]).astype("int64").to_numpy()
        raw_end_pos = np.searchsorted(index_ns, t1_ns, side="right") - 1
        raw_end_pos = np.clip(raw_end_pos, 0, n - 1)
        end_pos[np.where(valid_t1.values)[0]] = raw_end_pos

    end_pos = np.maximum(end_pos, start_pos)
    diff = np.zeros(n + 1, dtype=float)
    np.add.at(diff, start_pos, 1.0)
    np.add.at(diff, end_pos + 1, -1.0)
    concurrency = np.cumsum(diff[:-1])
    inv_concurrency = np.divide(1.0, concurrency, out=np.ones_like(concurrency), where=concurrency > 0)
    prefix = np.concatenate([[0.0], np.cumsum(inv_concurrency)])
    lengths = (end_pos - start_pos + 1).astype(float)
    uniqueness_sorted = (prefix[end_pos + 1] - prefix[start_pos]) / lengths
    uniqueness_sorted = np.nan_to_num(uniqueness_sorted, nan=1.0, posinf=1.0, neginf=1.0)
    return pd.Series(uniqueness_sorted, index=work.index).reindex(df.index).fillna(1.0).to_numpy(dtype=float)


def compute_class_weights(y: pd.Series, class_weight_mode: str) -> np.ndarray:
    if class_weight_mode == "none":
        return np.ones(len(y), dtype=float)
    if class_weight_mode == "balanced":
        return compute_sample_weight(class_weight="balanced", y=y)
    base = compute_sample_weight(class_weight="balanced", y=y)
    pos_multiplier_map = {
        "pos_up_1.25": 1.25,
        "pos_up_1.50": 1.50,
        "pos_up_2.00": 2.00,
    }
    if class_weight_mode not in pos_multiplier_map:
        raise MetaModelTrainingError(f"Unknown class_weight_mode: {class_weight_mode}")
    out = np.asarray(base, dtype=float).copy()
    out[np.asarray(y).astype(int) == 1] *= pos_multiplier_map[class_weight_mode]
    return out


def make_train_weights(df: pd.DataFrame, y: pd.Series, train_idx: np.ndarray, class_weight_mode: str) -> np.ndarray:
    train_idx = np.asarray(train_idx, dtype=int)
    y_train = y.iloc[train_idx]
    train_df = df.iloc[train_idx].copy()
    class_w = compute_class_weights(y_train, class_weight_mode=class_weight_mode)
    magnitude = np.maximum(pd.to_numeric(train_df[EVENT_VOL_COL], errors="coerce").fillna(0.0).to_numpy(dtype=float), 1e-8)
    uniq = compute_uniqueness(train_df)
    final_w = class_w * magnitude * uniq
    mean_w = np.mean(final_w)
    if not np.isfinite(mean_w) or mean_w <= 0:
        return np.ones(len(train_idx), dtype=float)
    return final_w / mean_w


def flatten_cv_indices(idx: Any) -> np.ndarray:
    if isinstance(idx, np.ndarray):
        return np.unique(idx.astype(int))
    if hasattr(idx, "__iter__"):
        parts = []
        for part in idx:
            parts.append(np.atleast_1d(part).astype(int))
        return np.unique(np.concatenate(parts)) if parts else np.array([], dtype=int)
    return np.array([int(idx)])


def purge_train_overlaps(train_idx: np.ndarray, test_idx: np.ndarray, index: pd.Index, t1: pd.Series) -> np.ndarray:
    train_idx = np.asarray(train_idx, dtype=int)
    test_idx = np.asarray(test_idx, dtype=int)
    if len(train_idx) == 0 or len(test_idx) == 0:
        return train_idx
    train_starts = index[train_idx].values.astype("datetime64[ns]")
    train_ends = t1.iloc[train_idx].values.astype("datetime64[ns]")
    test_starts = index[test_idx].values.astype("datetime64[ns]")
    test_ends = t1.iloc[test_idx].values.astype("datetime64[ns]")
    keep_mask = np.ones(len(train_idx), dtype=bool)
    for i in range(len(train_idx)):
        overlaps = (train_starts[i] <= test_ends) & (train_ends[i] >= test_starts)
        if overlaps.any():
            keep_mask[i] = False
    return train_idx[keep_mask]


def apply_embargo(train_idx: np.ndarray, test_idx: np.ndarray, n_samples: int, embargo_size: int) -> np.ndarray:
    train_idx = np.asarray(train_idx, dtype=int)
    test_idx = np.sort(np.unique(np.asarray(test_idx, dtype=int)))
    if len(train_idx) == 0 or len(test_idx) == 0 or embargo_size <= 0:
        return train_idx
    keep_mask = np.ones(len(train_idx), dtype=bool)
    block_ends = []
    for i in range(1, len(test_idx)):
        if test_idx[i] != test_idx[i - 1] + 1:
            block_ends.append(test_idx[i - 1])
    block_ends.append(test_idx[-1])
    for block_end in block_ends:
        embargo_start = block_end + 1
        embargo_end = min(embargo_start + embargo_size, n_samples)
        keep_mask &= (train_idx < embargo_start) | (train_idx >= embargo_end)
    return train_idx[keep_mask]


def get_positive_class_proba(model: xgb.XGBClassifier, x_data: pd.DataFrame) -> np.ndarray:
    proba = model.predict_proba(x_data)
    if proba.shape[1] == 1:
        cls = int(model.classes_[0])
        return np.ones(len(x_data), dtype=float) if cls == 1 else np.zeros(len(x_data), dtype=float)
    class_to_col = {int(cls): i for i, cls in enumerate(model.classes_)}
    if 1 not in class_to_col:
        return np.zeros(len(x_data), dtype=float)
    return proba[:, class_to_col[1]]


def find_best_f1_threshold(y_true: pd.Series, proba: np.ndarray) -> tuple[float, float]:
    y_arr = np.asarray(y_true).astype(int)
    best_thr = 0.50
    best_f1 = -np.inf
    for thr in F1_THRESHOLD_GRID:
        pred = (proba >= thr).astype(int)
        score = f1_score(y_arr, pred, zero_division=0)
        if score > best_f1:
            best_f1 = float(score)
            best_thr = float(thr)
    return best_thr, best_f1


def score_at_threshold(y_true: pd.Series, proba: np.ndarray, threshold: float) -> dict[str, float]:
    pred = (proba >= threshold).astype(int)
    return {
        "f1": float(f1_score(y_true, pred, zero_division=0)),
        "precision": float(precision_score(y_true, pred, zero_division=0)),
        "recall": float(recall_score(y_true, pred, zero_division=0)),
    }


def evaluate_params_cpcv(
    df: pd.DataFrame,
    x_data: pd.DataFrame,
    y: pd.Series,
    params: dict[str, Any],
    *,
    trial_number: int | None = None,
) -> tuple[float, list[dict[str, Any]]]:
    if CombinatorialPurgedCV is None:
        raise MetaModelTrainingError(
            "skfolio.model_selection.CombinatorialPurgedCV is required. "
            f"Original import error: {SKFOLIO_IMPORT_ERROR}"
        )
    class_weight_mode = params.get("class_weight_mode", "balanced")
    cv = CombinatorialPurgedCV(
        n_folds=N_FOLDS,
        n_test_folds=N_TEST_FOLDS,
        purged_size=PURGED_SIZE,
        embargo_size=EMBARGO_SIZE,
    )
    f1_scores = []
    fold_rows = []
    label = f"Trial {trial_number}" if trial_number is not None else "Trial"

    for split_num, (train_idx, test_idx) in enumerate(cv.split(x_data), start=1):
        train_idx = flatten_cv_indices(train_idx)
        test_idx = flatten_cv_indices(test_idx)
        raw_train_rows = len(train_idx)
        raw_test_rows = len(test_idx)
        train_idx = purge_train_overlaps(train_idx, test_idx, df.index, df[T1_COL])
        train_idx = apply_embargo(train_idx, test_idx, len(df), MANUAL_EMBARGO_SIZE)

        if len(train_idx) == 0 or len(test_idx) == 0:
            print(
                f"{label} | fold {split_num:02d}: skipped after purge/embargo "
                f"raw_train={raw_train_rows:,} raw_test={raw_test_rows:,}",
                flush=True,
            )
            continue

        x_train = x_data.iloc[train_idx]
        x_test = x_data.iloc[test_idx]
        y_train = y.iloc[train_idx]
        y_test = y.iloc[test_idx]
        if y_train.nunique() < 2:
            print(f"{label} | fold {split_num:02d}: skipped because train fold has one class", flush=True)
            continue

        weights = make_train_weights(df=df, y=y, train_idx=train_idx, class_weight_mode=class_weight_mode)
        model = fit_model_safely(make_model(params), x_train, y_train, weights)
        train_proba = get_positive_class_proba(model, x_train)
        best_thr, train_f1 = find_best_f1_threshold(y_train, train_proba)
        test_proba = get_positive_class_proba(model, x_test)
        metrics = score_at_threshold(y_test, test_proba, best_thr)
        f1_scores.append(metrics["f1"])
        row = {
            "split_num": split_num,
            "raw_train_rows": int(raw_train_rows),
            "raw_test_rows": int(raw_test_rows),
            "train_rows_after_purge_embargo": int(len(train_idx)),
            "test_rows": int(len(test_idx)),
            "best_train_threshold": float(best_thr),
            "train_f1_at_threshold": float(train_f1),
            "test_f1": metrics["f1"],
            "test_precision": metrics["precision"],
            "test_recall": metrics["recall"],
        }
        fold_rows.append(row)
        if PRINT_FOLD_PROGRESS:
            running_mean = float(np.mean(f1_scores))
            print(
                f"{label} | fold {split_num:02d}: "
                f"train={len(train_idx):,} test={len(test_idx):,} "
                f"thr={best_thr:.2f} train_f1={train_f1:.4f} "
                f"test_f1={metrics['f1']:.4f} "
                f"precision={metrics['precision']:.4f} recall={metrics['recall']:.4f} "
                f"running_mean_f1={running_mean:.4f}",
                flush=True,
            )

    if not f1_scores:
        return -np.inf, fold_rows
    return float(np.mean(f1_scores)), fold_rows


def optuna_objective(trial: optuna.Trial, df: pd.DataFrame, x_data: pd.DataFrame, y: pd.Series) -> float:
    params = {
        "n_estimators": trial.suggest_int("n_estimators", 250, 1000),
        "max_depth": trial.suggest_int("max_depth", 2, 6),
        "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.08, log=True),
        "min_child_weight": trial.suggest_float("min_child_weight", 5.0, 100.0, log=True),
        "subsample": trial.suggest_float("subsample", 0.55, 0.95),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.55, 0.95),
        "gamma": trial.suggest_float("gamma", 0.0, 8.0),
        "reg_alpha": trial.suggest_float("reg_alpha", 1e-4, 10.0, log=True),
        "reg_lambda": trial.suggest_float("reg_lambda", 1e-3, 30.0, log=True),
        "class_weight_mode": trial.suggest_categorical(
            "class_weight_mode",
            ["none", "balanced", "pos_up_1.25", "pos_up_1.50", "pos_up_2.00"],
        ),
    }
    print("\n" + "-" * 80, flush=True)
    print(f"START TRIAL {trial.number + 1}/{N_TRIALS}", flush=True)
    if PRINT_PARAMS_PER_TRIAL:
        print(f"Trial {trial.number + 1} params: {params}", flush=True)
    score, fold_rows = evaluate_params_cpcv(
        df=df,
        x_data=x_data,
        y=y,
        params=params,
        trial_number=trial.number + 1,
    )
    trial.set_user_attr("fold_rows", fold_rows)
    print(f"END TRIAL {trial.number + 1}/{N_TRIALS} | mean CPCV F1={score:.6f}", flush=True)
    return score


def optuna_progress_callback(study: optuna.Study, trial: optuna.trial.FrozenTrial) -> None:
    best = study.best_trial
    print(
        f"OPTUNA PROGRESS | completed={len(study.trials)}/{N_TRIALS} | "
        f"latest_trial={trial.number + 1} value={trial.value} | "
        f"best_trial={best.number + 1} best_f1={study.best_value:.6f}",
        flush=True,
    )


def train_final_model(df: pd.DataFrame, x_data: pd.DataFrame, y: pd.Series, best_params: dict[str, Any]) -> xgb.XGBClassifier:
    train_idx = np.arange(len(df))
    weights = make_train_weights(
        df=df,
        y=y,
        train_idx=train_idx,
        class_weight_mode=best_params.get("class_weight_mode", "balanced"),
    )
    return fit_model_safely(make_model(best_params), x_data, y, weights)


def get_feature_importance(model: xgb.XGBClassifier, feature_names: list[str]) -> pd.DataFrame:
    importances = model.feature_importances_
    return pd.DataFrame({"feature": feature_names, "importance": importances}).sort_values(
        "importance", ascending=False
    ).reset_index(drop=True)


def evaluate_final_training_threshold(model: xgb.XGBClassifier, x_data: pd.DataFrame, y: pd.Series) -> dict[str, Any]:
    proba = get_positive_class_proba(model, x_data)
    best_thr, best_f1 = find_best_f1_threshold(y, proba)
    metrics = score_at_threshold(y, proba, best_thr)
    return {
        "diagnostic_only": True,
        "best_train_f1_threshold": float(best_thr),
        "train_f1_at_best_threshold": float(best_f1),
        "train_precision_at_best_threshold": metrics["precision"],
        "train_recall_at_best_threshold": metrics["recall"],
        "note": "Diagnostic only. Final deployable threshold must come from calibrated OOF threshold sweep later.",
    }


def main() -> None:
    print("=" * 80, flush=True)
    print(f"V2 STEP 02: FINAL META-MODEL TRAINING WITH OPTUNA — {EDGE_ID}", flush=True)
    print("=" * 80, flush=True)
    print(f"Run mode: {RUN_MODE}", flush=True)
    print(f"Working directory: {CWD}", flush=True)
    print(f"Model rows: {MODEL_ROWS_PATH}", flush=True)
    print(f"Selected features: {SELECTED_FEATURES_PATH}", flush=True)
    print(f"Feature schema: {FEATURE_SCHEMA_PATH}", flush=True)
    print(f"Output directory: {OUTPUT_DIR}", flush=True)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    selected_features = load_selected_features()
    df = load_dataset(selected_features)
    x_data = df[selected_features].copy()
    y = df[TARGET_COL].copy()

    print(f"Date range: {df.index.min()} -> {df.index.max()}", flush=True)
    print(f"Rows used: {len(df):,}", flush=True)
    print(f"Selected feature count: {len(selected_features):,}", flush=True)
    print(f"Target mean: {y.mean():.6f}", flush=True)
    print(f"Optuna trials: {N_TRIALS}", flush=True)
    print(f"CPCV combinations expected: C({N_FOLDS}, {N_TEST_FOLDS}) = 10 folds per trial", flush=True)
    print(f"Manual t1 overlap purge: ON | manual embargo size: {MANUAL_EMBARGO_SIZE}", flush=True)
    print("F1 thresholds are train-fold-only diagnostics; final live threshold comes later after sigmoid calibration.", flush=True)

    print("\nRunning Optuna tuning with MLDP-style CPCV F1 objective...", flush=True)
    study = optuna.create_study(direction="maximize", study_name=STUDY_NAME)
    study.optimize(
        lambda trial: optuna_objective(trial, df=df, x_data=x_data, y=y),
        n_trials=N_TRIALS,
        timeout=OPTUNA_TIMEOUT,
        show_progress_bar=False,
        callbacks=[optuna_progress_callback],
    )

    best_params = study.best_trial.params
    best_score = float(study.best_value)
    best_fold_rows = study.best_trial.user_attrs.get("fold_rows", [])
    print(f"\nBest CPCV F1: {best_score:.6f}", flush=True)
    print("Best parameters:", flush=True)
    print(best_params, flush=True)

    trials_df = study.trials_dataframe()
    trials_df.to_csv(OPTUNA_TRIALS_OUTPUT, index=False)

    print("\nTraining final XGB model on all selected-feature rows...", flush=True)
    final_model = train_final_model(df=df, x_data=x_data, y=y, best_params=best_params)
    joblib.dump(final_model, MODEL_OUTPUT)

    feature_importance = get_feature_importance(final_model, selected_features)
    feature_importance.to_csv(FEATURE_IMPORTANCE_OUTPUT, index=False)
    save_json(BEST_PARAMS_OUTPUT, best_params)
    final_train_diag = evaluate_final_training_threshold(final_model, x_data, y)

    manifest = {
        "created_at": now_utc(),
        "edge_id": EDGE_ID,
        "run_mode": RUN_MODE,
        "script": display_path(THIS_FILE),
        "blueprint_stage": "raw_probability_model_training_before_oof_and_calibration",
        "feature_engineering_performed_here": False,
        "input_model_rows": display_path(MODEL_ROWS_PATH),
        "input_selected_features": display_path(SELECTED_FEATURES_PATH),
        "input_feature_schema": display_path(FEATURE_SCHEMA_PATH),
        "rows_used": int(len(df)),
        "date_start": str(df.index.min()),
        "date_end": str(df.index.max()),
        "target": TARGET_COL,
        "target_mean": float(y.mean()),
        "selected_feature_count": int(len(selected_features)),
        "selected_features": selected_features,
        "side_specialization": {
            "edge_side": SIDE,
            "side_value": SIDE_VALUE,
            "model_learns_direction": False,
        },
        "model_type": "XGBClassifier",
        "model_output_type": "raw_probability_model",
        "deployable": False,
        "deployability_blockers": [
            "OOF raw probability generation not yet complete",
            "sigmoid calibration not yet complete",
            "calibrated threshold sweep not yet complete",
            "runtime.py::score not yet wired to model/calibrator artifacts",
            "deployability replay audit not yet passed",
        ],
        "scoring": {
            "primary_metric": "f1",
            "optuna_direction": "maximize",
            "best_cpcv_f1": best_score,
            "threshold_selection": "best F1 threshold selected on train fold only, applied to test fold",
            "threshold_grid": F1_THRESHOLD_GRID.tolist(),
            "note": "These F1 thresholds are model-selection diagnostics only. Final live threshold must use calibrated_probability later.",
        },
        "cpcv": {
            "n_folds": N_FOLDS,
            "n_test_folds": N_TEST_FOLDS,
            "purged_size": PURGED_SIZE,
            "embargo_size": EMBARGO_SIZE,
            "manual_embargo_size": MANUAL_EMBARGO_SIZE,
            "mode": "manual_t1_overlap_purge_after_cpcv_split_generation",
            "best_trial_fold_rows": best_fold_rows,
        },
        "optuna": {
            "n_trials": N_TRIALS,
            "timeout": OPTUNA_TIMEOUT,
            "best_trial_number": int(study.best_trial.number),
            "best_params": best_params,
            "best_value": best_score,
        },
        "final_training_diagnostics": final_train_diag,
        "outputs": {
            "model": display_path(MODEL_OUTPUT),
            "best_params": display_path(BEST_PARAMS_OUTPUT),
            "feature_importance": display_path(FEATURE_IMPORTANCE_OUTPUT),
            "optuna_trials": display_path(OPTUNA_TRIALS_OUTPUT),
            "manifest": display_path(MANIFEST_OUTPUT),
        },
        "next_ordered_step": "03_generate_oof_predictions.py",
        "notes": [
            "This script ports V1 Step 6D into V2.",
            "It consumes exported V2 side-specialized model rows and Step 01 selected features only.",
            "It does not engineer new features.",
            "It trains a raw-probability model only.",
            "Final deployable threshold is not selected here.",
            "The next step must generate OOF raw probabilities for calibration and threshold evaluation.",
        ],
    }
    save_json(MANIFEST_OUTPUT, manifest)

    print("\n✅ V2 Optuna meta-model training completed.", flush=True)
    print(f"Rows used: {len(df):,}", flush=True)
    print(f"Selected features: {len(selected_features):,}", flush=True)
    print(f"Best CPCV F1: {best_score:.6f}", flush=True)
    print(f"Final diagnostic train threshold: {final_train_diag['best_train_f1_threshold']}", flush=True)
    print(f"Saved model: {MODEL_OUTPUT}", flush=True)
    print(f"Saved manifest: {MANIFEST_OUTPUT}", flush=True)
    print("Next ordered step: 03_generate_oof_predictions.py", flush=True)

    if RUN_MODE == "flat_colab":
        print("\nFlat Colab output files to download:", flush=True)
        for path in [
            MODEL_OUTPUT,
            BEST_PARAMS_OUTPUT,
            FEATURE_IMPORTANCE_OUTPUT,
            OPTUNA_TRIALS_OUTPUT,
            MANIFEST_OUTPUT,
        ]:
            print(f"  - {path}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except MetaModelTrainingError as exc:
        raise SystemExit(f"❌ {exc}") from exc
