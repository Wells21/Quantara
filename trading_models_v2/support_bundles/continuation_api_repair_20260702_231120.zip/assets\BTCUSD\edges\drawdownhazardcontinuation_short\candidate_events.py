"""Causal high-recall drawdown-hazard candidate events for BTCUSD shorts.

The edge estimates the empirical probability that a drawdown state makes a
meaningful new trough before a meaningful recovery. Historical observations
enter the online hazard table only after their outcome has resolved, so current
candidate events never use unresolved or future outcomes.
"""
from __future__ import annotations

from collections import defaultdict, deque
from typing import Any
import numpy as np
import pandas as pd

EDGE_ID = "BTCUSD/drawdownhazardcontinuation_short"
SIDE_VALUE = -1
RAW_SIDE_VALUE = 0
CANDIDATE_EVENT_GENERATOR = (
    "drawdownhazardcontinuation_short_v2_causal_resolved_history_hazard_impulses"
)
PRIMARY_PEAK_WINDOW = 100
SECONDARY_PEAK_WINDOWS = (50, 250)
SEVERITY_BASELINE_WINDOW = 1000
HAZARD_RESOLUTION_MAX_BARS = 250
HAZARD_OBSERVATION_GAP_BARS = 3
NEW_TROUGH_BUFFER_VOL = 0.25
RECOVERY_SUCCESS_FRACTION = 0.35
RECOVERY_ATTEMPT_FRACTION = 0.15
RECOVERY_FAILURE_FRACTION = 0.05
MIN_DRAWDOWN_SEVERITY_PERCENTILE = 0.50
MAX_RECOVERY_FRACTION = 0.40
MIN_HAZARD_PROBABILITY = 0.52
MIN_HAZARD_CELL_OBSERVATIONS = 30
MIN_EVENT_GAP_BARS = 3
HAZARD_PRIOR_ALPHA = 1.0
HAZARD_PRIOR_BETA = 1.0
EVENT_VOL_LOOKBACK = 50
EVENT_VOL_EWM_SPAN = 100
MIN_EVENT_VOL = 1e-8
EPS = 1e-12

EVENT_CONTEXT_COLUMNS = [
    "Event_Vol", "Drawdown_Hazard_Event", "Drawdown_Hazard_Active_State",
    "Drawdown_Hazard_State_Entry", "Drawdown_Hazard_Renewed_Impulse",
    "Negative_Event_Bar", "Log_Return_1", "Drawdown_Active",
    "Drawdown_Peak_50", "Drawdown_Peak_100", "Drawdown_Peak_250",
    "Drawdown_Depth_50", "Drawdown_Depth_100", "Drawdown_Depth_250",
    "Drawdown_Severity_100", "Drawdown_Severity_Percentile_100_Over_1000",
    "Bars_Since_Peak_100", "Time_Under_Water_100", "Drawdown_Trough",
    "Bars_Since_Trough", "Distance_From_Trough_ATR", "Recovery_Fraction",
    "Maximum_Recovery_Fraction", "Drawdown_Velocity_3",
    "Drawdown_Velocity_5", "Drawdown_Velocity_10",
    "Drawdown_Acceleration_3_10", "New_Trough_Bar",
    "New_Trough_Count_20", "New_Trough_Count_Since_Peak",
    "Trough_Renewal_Rate", "Failed_Recovery_Count",
    "Bars_Since_Last_Failed_Recovery", "Negative_Return_Fraction_20",
    "Negative_Return_Fraction_Since_Peak", "Cumulative_Return_Since_Peak",
    "Cumulative_Negative_Return_20", "Downside_Semivariance_20",
    "Downside_Upmove_Ratio_20", "Drawdown_Hazard_Probability",
    "Drawdown_Hazard_Cell_Count", "Drawdown_Hazard_Backoff_Level",
    "Drawdown_Hazard_Resolution_Lag", "Drawdown_Hazard_Global_Count",
    "Body_Direction", "Body_Share", "Close_Location", "Regime_State",
    "Regime_Entropy", "Regime_Duration", "Prob_State_0", "Prob_State_1",
    "Prob_State_2", "Prob_State_3",
]
_LAST_EVENT_DIAGNOSTICS: dict[str, Any] = {}


class CandidateEventError(RuntimeError):
    pass


def get_last_event_diagnostics() -> dict[str, Any]:
    return dict(_LAST_EVENT_DIAGNOSTICS)


def _forbidden_event_columns() -> set[str]:
    return {
        "meta_label", "label", "target", "t1", "barrier_hit",
        "resolution_source", "entry_price", "pt_price", "sl_price",
        "realized_r", "raw_probability", "calibrated_probability",
        "afml_bet_size", "approved_signal", "selected_threshold",
        "Ticks", "Proxy_Value", "Tick_Activity_Ratio", "Proxy_Value_Ratio",
        "Activity_Impulse",
    }


def _normalize_feature_input(features: pd.DataFrame) -> pd.DataFrame:
    required = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close"]
    missing = [column for column in required if column not in features.columns]
    if missing:
        raise CandidateEventError(f"Input features missing required columns: {missing}")
    out = features.copy()
    out["Datetime"] = pd.to_datetime(out["Datetime"], utc=True, errors="coerce")
    out["Bar_Start"] = pd.to_datetime(out["Bar_Start"], utc=True, errors="coerce")
    numeric = [
        "Open", "High", "Low", "Close", "ATR_14", "Regime_State",
        "Regime_Entropy", "Regime_Duration", "Prob_State_0", "Prob_State_1",
        "Prob_State_2", "Prob_State_3",
    ]
    for column in [name for name in numeric if name in out.columns]:
        out[column] = pd.to_numeric(out[column], errors="coerce")
    out = out.dropna(subset=required).sort_values("Datetime").reset_index(drop=True)
    out = out[
        (out["Open"] > 0) & (out["High"] > 0)
        & (out["Low"] > 0) & (out["Close"] > 0)
    ].copy()
    if out.empty:
        raise CandidateEventError("Input features are empty after normalization")
    return out


def _rolling_latest_peak(values: np.ndarray, window: int) -> tuple[np.ndarray, np.ndarray]:
    peaks = np.full(len(values), np.nan, dtype="float64")
    indices = np.full(len(values), -1, dtype="int64")
    queue: deque[int] = deque()
    for i, value in enumerate(values):
        while queue and queue[0] <= i - window:
            queue.popleft()
        while queue and values[queue[-1]] <= value:
            queue.pop()
        queue.append(i)
        peaks[i] = values[queue[0]]
        indices[i] = queue[0]
    return peaks, indices


def _rolling_percentile_current(values: np.ndarray) -> float:
    current = values[-1]
    history = values[:-1]
    history = history[np.isfinite(history)]
    if not np.isfinite(current) or history.size == 0:
        return np.nan
    return float(np.mean(history <= current))


def _new_episode_state(peak_price: float, peak_index: int) -> dict[str, Any]:
    return {
        "peak": float(peak_price),
        "peak_index": int(peak_index),
        "trough": float(peak_price),
        "trough_index": int(peak_index),
        "new_trough_count": 0,
        "failed_recovery_count": 0,
        "last_failed_index": -1,
        "maximum_recovery": 0.0,
        "attempt_active": False,
        "can_arm_attempt": True,
        "negative_count": 0,
    }


def _advance_episode_state(
    state: dict[str, Any], price: float, index: int, negative_return: bool,
) -> tuple[float, bool]:
    if negative_return:
        state["negative_count"] += 1
    peak = float(state["peak"])
    trough_before = float(state["trough"])
    denominator_before = peak - trough_before
    recovery_before = (
        (price - trough_before) / (denominator_before + EPS)
        if denominator_before > EPS else 0.0
    )
    if state["attempt_active"]:
        if recovery_before >= RECOVERY_SUCCESS_FRACTION:
            state["attempt_active"] = False
            state["can_arm_attempt"] = False
        elif recovery_before <= RECOVERY_FAILURE_FRACTION:
            state["failed_recovery_count"] += 1
            state["last_failed_index"] = int(index)
            state["attempt_active"] = False
            state["can_arm_attempt"] = False
    elif recovery_before < RECOVERY_ATTEMPT_FRACTION * 0.75:
        state["can_arm_attempt"] = True
    if (
        state["can_arm_attempt"]
        and RECOVERY_ATTEMPT_FRACTION <= recovery_before < RECOVERY_SUCCESS_FRACTION
    ):
        state["attempt_active"] = True
    new_trough = bool(price < trough_before - EPS)
    if new_trough:
        state["trough"] = float(price)
        state["trough_index"] = int(index)
        state["new_trough_count"] += 1
        state["maximum_recovery"] = 0.0
        state["attempt_active"] = False
        state["can_arm_attempt"] = True
        recovery = 0.0
    else:
        denominator = peak - float(state["trough"])
        recovery = (
            (price - float(state["trough"])) / (denominator + EPS)
            if denominator > EPS else 1.0
        )
        state["maximum_recovery"] = max(
            float(state["maximum_recovery"]), float(recovery)
        )
    return float(np.clip(recovery, 0.0, 2.0)), new_trough


def _build_path_features(out: pd.DataFrame) -> pd.DataFrame:
    close = out["Close"].to_numpy(dtype="float64")
    returns = out["Log_Return_1"].to_numpy(dtype="float64")
    peak50, _ = _rolling_latest_peak(close, 50)
    peak100, peak_index100 = _rolling_latest_peak(close, PRIMARY_PEAK_WINDOW)
    peak250, _ = _rolling_latest_peak(close, 250)
    out["Drawdown_Peak_50"] = peak50
    out["Drawdown_Peak_100"] = peak100
    out["Drawdown_Peak_250"] = peak250
    out["Drawdown_Depth_50"] = close / (peak50 + EPS) - 1.0
    out["Drawdown_Depth_100"] = close / (peak100 + EPS) - 1.0
    out["Drawdown_Depth_250"] = close / (peak250 + EPS) - 1.0
    severity = np.maximum(0.0, -out["Drawdown_Depth_100"].to_numpy(dtype="float64"))
    out["Drawdown_Severity_100"] = severity
    out["Drawdown_Active"] = severity > EPS

    n = len(out)
    trough = np.full(n, np.nan)
    trough_index = np.full(n, -1, dtype="int64")
    recovery = np.full(n, np.nan)
    maximum_recovery = np.full(n, np.nan)
    age = np.full(n, np.nan)
    new_trough_bar = np.zeros(n, dtype="int64")
    new_trough_count = np.zeros(n, dtype="int64")
    failed_count = np.zeros(n, dtype="int64")
    since_failed = np.full(n, np.nan)
    negative_fraction_since_peak = np.full(n, np.nan)
    current_peak_index = -1
    state: dict[str, Any] | None = None

    for i in range(n):
        peak_idx = int(peak_index100[i])
        if peak_idx != current_peak_index:
            current_peak_index = peak_idx
            state = _new_episode_state(float(peak100[i]), peak_idx)
            for k in range(peak_idx + 1, i + 1):
                rec, made_trough = _advance_episode_state(
                    state, float(close[k]), k, bool(returns[k] < 0)
                )
            if i == peak_idx:
                rec, made_trough = 1.0, False
        else:
            assert state is not None
            rec, made_trough = _advance_episode_state(
                state, float(close[i]), i, bool(returns[i] < 0)
            )
        assert state is not None
        trough[i] = float(state["trough"])
        trough_index[i] = int(state["trough_index"])
        recovery[i] = float(rec)
        maximum_recovery[i] = float(state["maximum_recovery"])
        age[i] = float(i - peak_idx)
        new_trough_bar[i] = int(made_trough)
        new_trough_count[i] = int(state["new_trough_count"])
        failed_count[i] = int(state["failed_recovery_count"])
        if int(state["last_failed_index"]) >= 0:
            since_failed[i] = float(i - int(state["last_failed_index"]))
        denominator = max(1, i - peak_idx)
        negative_fraction_since_peak[i] = float(state["negative_count"]) / denominator

    out["Drawdown_Trough"] = trough
    out["Bars_Since_Peak_100"] = age
    out["Time_Under_Water_100"] = np.where(out["Drawdown_Active"], age, 0.0)
    out["Bars_Since_Trough"] = np.arange(n) - trough_index
    out["Recovery_Fraction"] = recovery
    out["Maximum_Recovery_Fraction"] = maximum_recovery
    out["New_Trough_Bar"] = new_trough_bar
    out["New_Trough_Count_20"] = (
        pd.Series(new_trough_bar).rolling(20, min_periods=1).sum().to_numpy()
    )
    out["New_Trough_Count_Since_Peak"] = new_trough_count
    out["Trough_Renewal_Rate"] = new_trough_count / (age + 1.0)
    out["Failed_Recovery_Count"] = failed_count
    out["Bars_Since_Last_Failed_Recovery"] = since_failed
    out["Negative_Return_Fraction_Since_Peak"] = negative_fraction_since_peak
    return out


def _severity_bin(value: float) -> int:
    if not np.isfinite(value):
        return -1
    if value < 0.50:
        return 0
    if value < 0.75:
        return 1
    if value < 0.90:
        return 2
    return 3


def _age_bin(value: float) -> int:
    if not np.isfinite(value):
        return -1
    if value <= 10:
        return 0
    if value <= 30:
        return 1
    if value <= 80:
        return 2
    return 3


def _recovery_bin(value: float) -> int:
    if not np.isfinite(value):
        return -1
    if value <= 0.10:
        return 0
    if value <= 0.25:
        return 1
    if value <= 0.50:
        return 2
    return 3


def _resolve_hazard_observation(
    close: np.ndarray,
    start: int,
    peak: float,
    trough: float,
    event_vol: float,
) -> tuple[int, int] | None:
    if not all(np.isfinite([peak, trough, event_vol])) or peak <= trough or event_vol <= 0:
        return None
    continuation_price = trough * (1.0 - NEW_TROUGH_BUFFER_VOL * event_vol)
    recovery_price = trough + RECOVERY_SUCCESS_FRACTION * (peak - trough)
    end = min(len(close) - 1, start + HAZARD_RESOLUTION_MAX_BARS)
    for j in range(start + 1, end + 1):
        if close[j] <= continuation_price:
            return 1, j
        if close[j] >= recovery_price:
            return 0, j
    return None


def _update_counter(counter: dict[Any, list[float]], key: Any, outcome: int, lag: int) -> None:
    row = counter[key]
    row[0] += float(outcome)
    row[1] += 1.0
    row[2] += float(lag)


def _build_causal_hazard_features(out: pd.DataFrame) -> pd.DataFrame:
    close = out["Close"].to_numpy(dtype="float64")
    active = out["Drawdown_Active"].astype(bool).to_numpy()
    severity_pct = out["Drawdown_Severity_Percentile_100_Over_1000"].to_numpy(dtype="float64")
    age = out["Bars_Since_Peak_100"].to_numpy(dtype="float64")
    recovery = out["Recovery_Fraction"].to_numpy(dtype="float64")
    peak = out["Drawdown_Peak_100"].to_numpy(dtype="float64")
    trough = out["Drawdown_Trough"].to_numpy(dtype="float64")
    event_vol = out["Event_Vol"].to_numpy(dtype="float64")
    peak_indices = np.arange(len(out)) - age.astype("float64")
    buckets: list[list[tuple[int, int, int, int, int]]] = [
        [] for _ in range(len(out))
    ]
    last_observation = -10**9
    last_peak_marker = -1
    for i in range(len(out)):
        marker = int(peak_indices[i]) if np.isfinite(peak_indices[i]) else -1
        if marker != last_peak_marker:
            last_peak_marker = marker
            last_observation = -10**9
        if (
            not active[i] or not np.isfinite(severity_pct[i])
            or recovery[i] >= RECOVERY_SUCCESS_FRACTION
            or i - last_observation < HAZARD_OBSERVATION_GAP_BARS
        ):
            continue
        s_bin, a_bin, r_bin = (
            _severity_bin(severity_pct[i]), _age_bin(age[i]), _recovery_bin(recovery[i])
        )
        if min(s_bin, a_bin, r_bin) < 0:
            continue
        last_observation = i
        resolved = _resolve_hazard_observation(
            close, i, float(peak[i]), float(trough[i]), float(event_vol[i])
        )
        if resolved is None:
            continue
        outcome, resolution_index = resolved
        buckets[resolution_index].append(
            (s_bin, a_bin, r_bin, int(outcome), int(resolution_index - i))
        )

    primary: dict[Any, list[float]] = defaultdict(lambda: [0.0, 0.0, 0.0])
    secondary: dict[Any, list[float]] = defaultdict(lambda: [0.0, 0.0, 0.0])
    tertiary: dict[Any, list[float]] = defaultdict(lambda: [0.0, 0.0, 0.0])
    global_counter: dict[Any, list[float]] = defaultdict(lambda: [0.0, 0.0, 0.0])
    probability = np.full(len(out), np.nan)
    cell_count = np.zeros(len(out), dtype="float64")
    backoff = np.full(len(out), 4.0)
    resolution_lag = np.full(len(out), np.nan)
    global_count = np.zeros(len(out), dtype="float64")

    for i in range(len(out)):
        if i > 0:
            for s_bin, a_bin, r_bin, outcome, lag in buckets[i - 1]:
                _update_counter(primary, (s_bin, a_bin, r_bin), outcome, lag)
                _update_counter(secondary, (s_bin, r_bin), outcome, lag)
                _update_counter(tertiary, s_bin, outcome, lag)
                _update_counter(global_counter, "global", outcome, lag)
        global_count[i] = global_counter["global"][1]
        s_bin, a_bin, r_bin = (
            _severity_bin(severity_pct[i]), _age_bin(age[i]), _recovery_bin(recovery[i])
        )
        if min(s_bin, a_bin, r_bin) < 0:
            continue
        candidates = [
            (0, primary[(s_bin, a_bin, r_bin)]),
            (1, secondary[(s_bin, r_bin)]),
            (2, tertiary[s_bin]),
            (3, global_counter["global"]),
        ]
        selected_level, selected = 4, global_counter["global"]
        for level, row in candidates:
            if row[1] >= MIN_HAZARD_CELL_OBSERVATIONS:
                selected_level, selected = level, row
                break
        successes, count, lag_sum = selected
        probability[i] = (
            successes + HAZARD_PRIOR_ALPHA
        ) / (count + HAZARD_PRIOR_ALPHA + HAZARD_PRIOR_BETA)
        cell_count[i] = count
        backoff[i] = float(selected_level)
        if count > 0:
            resolution_lag[i] = lag_sum / count

    out["Drawdown_Hazard_Probability"] = probability
    out["Drawdown_Hazard_Cell_Count"] = cell_count
    out["Drawdown_Hazard_Backoff_Level"] = backoff
    out["Drawdown_Hazard_Resolution_Lag"] = resolution_lag
    out["Drawdown_Hazard_Global_Count"] = global_count
    return out


def add_drawdown_hazard_features(features: pd.DataFrame) -> pd.DataFrame:
    out = _normalize_feature_input(features)
    open_ = out["Open"].astype("float64")
    high = out["High"].astype("float64")
    low = out["Low"].astype("float64")
    close = out["Close"].astype("float64")
    returns = np.log((close + EPS) / (close.shift(1) + EPS))
    out["Log_Return_1"] = returns
    out["Negative_Event_Bar"] = returns.lt(0)
    event_return = np.log((close + EPS) / (close.shift(EVENT_VOL_LOOKBACK) + EPS))
    out["Event_Vol"] = event_return.ewm(
        span=EVENT_VOL_EWM_SPAN, adjust=False
    ).std().clip(lower=MIN_EVENT_VOL)
    out = _build_path_features(out)
    severity = out["Drawdown_Severity_100"]
    out["Drawdown_Severity_Percentile_100_Over_1000"] = severity.rolling(
        SEVERITY_BASELINE_WINDOW + 1,
        min_periods=SEVERITY_BASELINE_WINDOW + 1,
    ).apply(_rolling_percentile_current, raw=True)
    out["Drawdown_Velocity_3"] = severity - severity.shift(3)
    out["Drawdown_Velocity_5"] = severity - severity.shift(5)
    out["Drawdown_Velocity_10"] = severity - severity.shift(10)
    out["Drawdown_Acceleration_3_10"] = (
        out["Drawdown_Velocity_3"] - out["Drawdown_Velocity_10"]
    )
    atr = (
        pd.to_numeric(out["ATR_14"], errors="coerce")
        if "ATR_14" in out.columns else close * out["Event_Vol"]
    )
    out["Distance_From_Trough_ATR"] = (close - out["Drawdown_Trough"]) / (atr + EPS)
    negative = returns.lt(0).astype("float64")
    out["Negative_Return_Fraction_20"] = negative.rolling(20, min_periods=20).mean()
    out["Cumulative_Return_Since_Peak"] = np.log(
        (close + EPS) / (out["Drawdown_Peak_100"] + EPS)
    )
    out["Cumulative_Negative_Return_20"] = returns.clip(upper=0).rolling(20, min_periods=20).sum()
    out["Downside_Semivariance_20"] = returns.clip(upper=0).pow(2).rolling(20, min_periods=20).mean()
    down = returns.clip(upper=0).abs().rolling(20, min_periods=20).sum()
    up = returns.clip(lower=0).rolling(20, min_periods=20).sum()
    out["Downside_Upmove_Ratio_20"] = down / (up + EPS)
    bar_range = (high - low).clip(lower=EPS)
    body = close - open_
    out["Body_Direction"] = np.sign(body)
    out["Body_Share"] = body.abs() / (bar_range + EPS)
    out["Close_Location"] = (close - low) / (bar_range + EPS)
    out = _build_causal_hazard_features(out)
    out["Drawdown_Hazard_Active_State"] = (
        out["Drawdown_Active"].astype(bool)
        & out["Drawdown_Severity_Percentile_100_Over_1000"].ge(
            MIN_DRAWDOWN_SEVERITY_PERCENTILE
        )
        & out["Recovery_Fraction"].le(MAX_RECOVERY_FRACTION)
        & out["Drawdown_Hazard_Probability"].ge(MIN_HAZARD_PROBABILITY)
        & out["Drawdown_Hazard_Cell_Count"].ge(MIN_HAZARD_CELL_OBSERVATIONS)
    ).astype("int64")
    out.replace([np.inf, -np.inf], np.nan, inplace=True)
    return out


def _quantiles(series: pd.Series) -> dict[str, float | None]:
    numeric = pd.to_numeric(series, errors="coerce").dropna()
    if numeric.empty:
        return {"q10": None, "q25": None, "q50": None, "q75": None, "q90": None}
    values = numeric.quantile([0.10, 0.25, 0.50, 0.75, 0.90])
    return {f"q{int(q * 100)}": float(values.loc[q]) for q in values.index}


def _extract_high_recall_events(features: pd.DataFrame) -> pd.DataFrame:
    diagnostics: dict[str, Any] = {
        "bars_seen": int(len(features)),
        "active_drawdown_bars": int(features["Drawdown_Active"].fillna(False).sum()),
        "valid_severity_rows": int(features["Drawdown_Severity_Percentile_100_Over_1000"].notna().sum()),
        "valid_hazard_rows": int(features["Drawdown_Hazard_Probability"].notna().sum()),
        "hazard_cells_with_enough_samples": int(features["Drawdown_Hazard_Cell_Count"].ge(MIN_HAZARD_CELL_OBSERVATIONS).sum()),
        "raw_severity_gate_bars": int(features["Drawdown_Severity_Percentile_100_Over_1000"].ge(MIN_DRAWDOWN_SEVERITY_PERCENTILE).sum()),
        "raw_recovery_gate_bars": int(features["Recovery_Fraction"].le(MAX_RECOVERY_FRACTION).sum()),
        "raw_hazard_gate_bars": int(features["Drawdown_Hazard_Probability"].ge(MIN_HAZARD_PROBABILITY).sum()),
        "raw_joint_active_bars": int(features["Drawdown_Hazard_Active_State"].eq(1).sum()),
        "negative_joint_active_bars": 0,
        "raw_state_entries": 0,
        "initial_state_entry_events": 0,
        "renewed_impulse_events": 0,
        "min_gap_suppressed": 0,
        "events_emitted": 0,
        "hazard_probability_quantiles": _quantiles(features["Drawdown_Hazard_Probability"]),
        "hazard_cell_count_quantiles": _quantiles(features["Drawdown_Hazard_Cell_Count"]),
        "drawdown_depth_quantiles": _quantiles(features["Drawdown_Severity_100"]),
        "drawdown_age_quantiles": _quantiles(features["Bars_Since_Peak_100"]),
        "recovery_fraction_quantiles": _quantiles(features["Recovery_Fraction"]),
    }
    rows: list[pd.Series] = []
    last_event_index = -10**9
    previous_active = False
    emitted_in_state = False
    for index, row in features.iterrows():
        active = bool(row["Drawdown_Hazard_Active_State"] == 1)
        negative_bar = bool(row["Negative_Event_Bar"])
        if active and not previous_active:
            diagnostics["raw_state_entries"] += 1
            emitted_in_state = False
        if not active:
            previous_active = False
            emitted_in_state = False
            continue
        previous_active = True
        if negative_bar:
            diagnostics["negative_joint_active_bars"] += 1
        if not negative_bar:
            continue
        if int(index) - last_event_index < MIN_EVENT_GAP_BARS:
            diagnostics["min_gap_suppressed"] += 1
            continue
        event = row.copy()
        state_entry = int(not emitted_in_state)
        event["Drawdown_Hazard_Event"] = 1
        event["Drawdown_Hazard_State_Entry"] = state_entry
        event["Drawdown_Hazard_Renewed_Impulse"] = 1 - state_entry
        rows.append(event)
        emitted_in_state = True
        last_event_index = int(index)
        diagnostics[
            "initial_state_entry_events" if state_entry else "renewed_impulse_events"
        ] += 1
        diagnostics["events_emitted"] += 1
    _LAST_EVENT_DIAGNOSTICS.clear()
    _LAST_EVENT_DIAGNOSTICS.update(diagnostics)
    if not rows:
        empty = features.iloc[[]].copy()
        empty.attrs["event_diagnostics"] = diagnostics
        return empty
    selected = pd.DataFrame(rows).reset_index(drop=True)
    selected.attrs["event_diagnostics"] = diagnostics
    return selected


def _validate_candidate_events(events: pd.DataFrame) -> None:
    required = [
        "Datetime", "Bar_Start", "edge_id", "side", "Event_Vol", "event_id",
        "candidate_event_generator", "Drawdown_Hazard_Event",
        "Drawdown_Hazard_Active_State", "Drawdown_Hazard_State_Entry",
        "Drawdown_Hazard_Renewed_Impulse", "Negative_Event_Bar",
        "Drawdown_Active", "Log_Return_1", "Drawdown_Severity_100",
        "Drawdown_Severity_Percentile_100_Over_1000", "Recovery_Fraction",
        "Drawdown_Hazard_Probability", "Drawdown_Hazard_Cell_Count",
        "event_known_after_close", "uses_future_information",
    ]
    missing = [column for column in required if column not in events.columns]
    if missing:
        raise CandidateEventError(f"Candidate events missing required columns: {missing}")
    if events.empty:
        raise CandidateEventError("Candidate generator produced zero drawdown-hazard events")
    forbidden = sorted(_forbidden_event_columns().intersection(events.columns))
    if forbidden:
        raise CandidateEventError(f"Candidate events contain forbidden columns: {forbidden}")
    if not events["edge_id"].eq(EDGE_ID).all():
        raise CandidateEventError("Unexpected edge_id")
    if not pd.to_numeric(events["side"], errors="coerce").eq(RAW_SIDE_VALUE).all():
        raise CandidateEventError("Raw candidate side must remain zero")
    for column in [
        "Drawdown_Hazard_Event", "Drawdown_Hazard_Active_State",
        "Negative_Event_Bar", "Drawdown_Active",
    ]:
        if not pd.to_numeric(events[column], errors="coerce").eq(1).all():
            raise CandidateEventError(f"All events must satisfy {column}=1")
    entry = pd.to_numeric(events["Drawdown_Hazard_State_Entry"], errors="coerce")
    renewed = pd.to_numeric(events["Drawdown_Hazard_Renewed_Impulse"], errors="coerce")
    if not entry.isin([0, 1]).all() or not renewed.isin([0, 1]).all() or not (entry + renewed).eq(1).all():
        raise CandidateEventError("Each event must be exactly one of state entry or renewed impulse")
    checks = [
        ("Log_Return_1", lambda x: x < 0, "negative return"),
        ("Drawdown_Severity_Percentile_100_Over_1000", lambda x: x >= MIN_DRAWDOWN_SEVERITY_PERCENTILE, "severity percentile"),
        ("Recovery_Fraction", lambda x: x <= MAX_RECOVERY_FRACTION, "recovery fraction"),
        ("Drawdown_Hazard_Probability", lambda x: x >= MIN_HAZARD_PROBABILITY, "hazard probability"),
        ("Drawdown_Hazard_Cell_Count", lambda x: x >= MIN_HAZARD_CELL_OBSERVATIONS, "hazard sample count"),
        ("Event_Vol", lambda x: x > 0, "Event_Vol"),
    ]
    for column, predicate, description in checks:
        values = pd.to_numeric(events[column], errors="coerce")
        if values.isna().any() or not predicate(values).all():
            raise CandidateEventError(f"Candidate events violate {description} contract")
    if events["uses_future_information"].astype(bool).any():
        raise CandidateEventError("Future information is forbidden")
    if not events["event_known_after_close"].astype(bool).all():
        raise CandidateEventError("Events are known only after close")


def generate_v2_drawdownhazardcontinuation_short_candidate_events(
    features: pd.DataFrame, **_: Any,
) -> pd.DataFrame:
    expanded = add_drawdown_hazard_features(features)
    selected = _extract_high_recall_events(expanded)
    diagnostics = get_last_event_diagnostics()
    if selected.empty:
        selected = pd.DataFrame(columns=["Datetime", "Bar_Start", *EVENT_CONTEXT_COLUMNS])
    keep = [
        "Datetime", "Bar_Start", "Open", "High", "Low", "Close",
        *[column for column in EVENT_CONTEXT_COLUMNS if column in selected.columns],
    ]
    events = selected[[column for column in keep if column in selected.columns]].copy()
    events["edge_id"] = EDGE_ID
    events["side"] = RAW_SIDE_VALUE
    events["event_id"] = events["Datetime"].apply(
        lambda value: f"{EDGE_ID}|{pd.Timestamp(value).isoformat()}|drawdown_hazard_impulse"
    )
    events["candidate_event_generator"] = CANDIDATE_EVENT_GENERATOR
    events["event_known_after_close"] = True
    events["uses_future_information"] = False
    events["primary_peak_window"] = PRIMARY_PEAK_WINDOW
    events["severity_baseline_window"] = SEVERITY_BASELINE_WINDOW
    events["hazard_resolution_max_bars"] = HAZARD_RESOLUTION_MAX_BARS
    events["hazard_observation_gap_bars"] = HAZARD_OBSERVATION_GAP_BARS
    events["new_trough_buffer_vol"] = NEW_TROUGH_BUFFER_VOL
    events["recovery_success_fraction"] = RECOVERY_SUCCESS_FRACTION
    events["min_drawdown_severity_percentile"] = MIN_DRAWDOWN_SEVERITY_PERCENTILE
    events["max_recovery_fraction"] = MAX_RECOVERY_FRACTION
    events["min_hazard_probability"] = MIN_HAZARD_PROBABILITY
    events["min_hazard_cell_observations"] = MIN_HAZARD_CELL_OBSERVATIONS
    events["min_gap_bars"] = MIN_EVENT_GAP_BARS
    events["Datetime"] = pd.to_datetime(events["Datetime"], utc=True, errors="coerce")
    events["Bar_Start"] = pd.to_datetime(events["Bar_Start"], utc=True, errors="coerce")
    for column in [name for name in EVENT_CONTEXT_COLUMNS if name in events.columns]:
        events[column] = pd.to_numeric(events[column], errors="coerce")
    events = events.dropna(subset=[
        "Datetime", "Bar_Start", "Event_Vol", "Log_Return_1",
        "Drawdown_Severity_Percentile_100_Over_1000", "Recovery_Fraction",
        "Drawdown_Hazard_Probability", "Drawdown_Hazard_Cell_Count",
    ]).sort_values("Datetime").reset_index(drop=True)
    events.attrs["event_diagnostics"] = diagnostics
    _validate_candidate_events(events)
    return events


def generate_v1_drawdownhazardcontinuation_short_candidate_events(
    features: pd.DataFrame, **kwargs: Any,
) -> pd.DataFrame:
    """Compatibility alias for older runtime references."""
    return generate_v2_drawdownhazardcontinuation_short_candidate_events(features, **kwargs)


def validate_candidate_events(events: pd.DataFrame) -> None:
    _validate_candidate_events(events)


def candidate_event_contract() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "raw_side_value": RAW_SIDE_VALUE,
        "final_side_value": SIDE_VALUE,
        "candidate_event_generator": CANDIDATE_EVENT_GENERATOR,
        "primary_peak_window": PRIMARY_PEAK_WINDOW,
        "severity_baseline_window": SEVERITY_BASELINE_WINDOW,
        "hazard_resolution_max_bars": HAZARD_RESOLUTION_MAX_BARS,
        "hazard_observation_gap_bars": HAZARD_OBSERVATION_GAP_BARS,
        "new_trough_buffer_vol": NEW_TROUGH_BUFFER_VOL,
        "recovery_success_fraction": RECOVERY_SUCCESS_FRACTION,
        "min_drawdown_severity_percentile": MIN_DRAWDOWN_SEVERITY_PERCENTILE,
        "max_recovery_fraction": MAX_RECOVERY_FRACTION,
        "min_hazard_probability": MIN_HAZARD_PROBABILITY,
        "min_hazard_cell_observations": MIN_HAZARD_CELL_OBSERVATIONS,
        "sampling_mode": "spaced_negative_impulses_inside_active_drawdown_hazard_state",
        "min_event_gap_bars": MIN_EVENT_GAP_BARS,
        "hazard_history_rule": "only_observations_with_resolution_index_less_than_current_index",
        "uses_future_information": False,
    }


if __name__ == "__main__":
    print("✅ BTCUSD/drawdownhazardcontinuation_short candidate_events.py import check passed")
    print(candidate_event_contract())
