"""
Candidate event generation for NASDAQ/rangestructure_short.

V1 source:
- NASDAQ/range-structure-independent-edge/4_range_structure_event_sampling.py

Core V1 idea:
- Define a prior 100-bar structural range using shifted rolling high/low.
- Fire events when price is near a prior range extreme and away from mid-range.
- Require past-only 50-bar structural-bias t-stat strength.
- Range_Structure_Event_Type marks location only, not trade direction.

V2 side-specialization:
- This module can generate both raw structural-bias sides.
- primary_side.py filters this edge to Structure_Bias_TStat < 0 -> side=-1 short.
- Range-specific fields are event/control/context fields, not generic model-schema features.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

EDGE_ID = "NASDAQ/rangestructure_short"
SIDE_VALUE = -1
CANDIDATE_EVENT_GENERATOR = "rangestructure_short_v1_range_extreme_bias_candidate_events"

RANGE_LOOKBACK = 100
EXTREME_ZONE_THRESHOLD = 0.15
STRUCTURE_BIAS_LOOKBACK = 50
STRUCTURE_BIAS_TSTAT_THRESHOLD = 0.50
MAX_MID_RANGE_POSITION = 0.45
MIN_OBS = 20
EVENT_VOL_LOOKBACK = 50
EVENT_VOL_EWM_SPAN = 100
MIN_VOL = 1e-8
MIN_GAP_BARS = 3
EPS = 1e-12

EVENT_CONTEXT_COLUMNS = [
    "Event_Vol",
    "Bar_Return",
    "Range_High",
    "Range_Low",
    "Range_Width",
    "Range_Position",
    "Dist_To_Range_High",
    "Dist_To_Range_Low",
    "Range_Width_Median",
    "Range_Compression_Ratio",
    "Structure_Bias_Mean",
    "Structure_Bias_Std",
    "Structure_Bias_TStat",
    "Range_Structure_Event_Type",
    "Body_Direction",
    "Body_Share",
    "Close_Location",
    "Regime_State",
    "Regime_Entropy",
    "Regime_Duration",
    "Prob_State_0",
    "Prob_State_1",
    "Prob_State_2",
    "Prob_State_3",
]


class CandidateEventError(RuntimeError):
    """Raised when candidate event generation must fail closed."""


def _required_event_columns() -> list[str]:
    return [
        "Datetime",
        "Bar_Start",
        "edge_id",
        "side",
        "Event_Vol",
        "event_id",
        "candidate_event_generator",
        "Range_Structure_Event_Type",
        "Structure_Bias_TStat",
        "event_known_after_close",
        "uses_future_information",
    ]


def _forbidden_event_columns() -> set[str]:
    return {
        "meta_label",
        "t1",
        "barrier_hit",
        "resolution_source",
        "entry_price",
        "pt_price",
        "sl_price",
        "realized_r",
        "raw_probability",
        "calibrated_probability",
        "afml_bet_size",
        "approved_signal",
    }


def _normalize_feature_input(features: pd.DataFrame) -> pd.DataFrame:
    required = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close"]
    missing = [col for col in required if col not in features.columns]
    if missing:
        raise CandidateEventError(f"Input features missing required columns: {missing}")

    df = features.copy()
    df["Datetime"] = pd.to_datetime(df["Datetime"], utc=True, errors="coerce")
    df["Bar_Start"] = pd.to_datetime(df["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open", "High", "Low", "Close",
        "Regime_State", "Regime_Entropy", "Regime_Duration",
        "Prob_State_0", "Prob_State_1", "Prob_State_2", "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in df.columns]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=required).copy()
    df = df.sort_values("Datetime").reset_index(drop=True)
    if df.empty:
        raise CandidateEventError("Input features are empty after normalization.")
    return df


def add_v1_range_structure_features(features: pd.DataFrame) -> pd.DataFrame:
    """Add the V1 range-structure fields using the same past-only formulas as long."""

    out = _normalize_feature_input(features)
    open_ = out["Open"].astype("float64")
    high = out["High"].astype("float64")
    low = out["Low"].astype("float64")
    close = out["Close"].astype("float64")

    out["Event_Vol"] = np.log((close + EPS) / (close.shift(EVENT_VOL_LOOKBACK) + EPS)).ewm(
        span=EVENT_VOL_EWM_SPAN,
        adjust=False,
    ).std().clip(lower=MIN_VOL)

    out["Bar_Return"] = np.log((close + EPS) / (close.shift(1) + EPS))
    out["Range_High"] = high.rolling(RANGE_LOOKBACK, min_periods=MIN_OBS).max().shift(1)
    out["Range_Low"] = low.rolling(RANGE_LOOKBACK, min_periods=MIN_OBS).min().shift(1)
    out["Range_Width"] = (out["Range_High"] - out["Range_Low"]).clip(lower=EPS)
    out["Range_Position"] = ((close - out["Range_Low"]) / (out["Range_Width"] + EPS)).clip(lower=-1.0, upper=2.0)
    out["Dist_To_Range_High"] = (out["Range_High"] - close) / (out["Range_Width"] + EPS)
    out["Dist_To_Range_Low"] = (close - out["Range_Low"]) / (out["Range_Width"] + EPS)
    out["Range_Width_Median"] = out["Range_Width"].rolling(RANGE_LOOKBACK, min_periods=MIN_OBS).median().shift(1)
    out["Range_Compression_Ratio"] = out["Range_Width"] / (out["Range_Width_Median"] + EPS)

    out["Structure_Bias_Mean"] = out["Bar_Return"].rolling(
        STRUCTURE_BIAS_LOOKBACK,
        min_periods=MIN_OBS,
    ).mean().shift(1)
    out["Structure_Bias_Std"] = out["Bar_Return"].rolling(
        STRUCTURE_BIAS_LOOKBACK,
        min_periods=MIN_OBS,
    ).std().shift(1)
    out["Structure_Bias_TStat"] = out["Structure_Bias_Mean"] / (
        (out["Structure_Bias_Std"] + EPS) / np.sqrt(float(STRUCTURE_BIAS_LOOKBACK))
    )

    bar_range = (high - low).clip(lower=EPS)
    body = close - open_
    out["Body_Direction"] = np.sign(body)
    out["Body_Share"] = body.abs() / (bar_range + EPS)
    out["Close_Location"] = (close - low) / (bar_range + EPS)

    near_low = out["Range_Position"] <= EXTREME_ZONE_THRESHOLD
    near_high = out["Range_Position"] >= (1.0 - EXTREME_ZONE_THRESHOLD)
    away_from_mid = (out["Range_Position"] <= MAX_MID_RANGE_POSITION) | (
        out["Range_Position"] >= (1.0 - MAX_MID_RANGE_POSITION)
    )
    bias_ok = out["Structure_Bias_TStat"].abs() >= STRUCTURE_BIAS_TSTAT_THRESHOLD

    out["Range_Structure_Event_Type"] = 0
    out.loc[near_low & away_from_mid & bias_ok, "Range_Structure_Event_Type"] = -1
    out.loc[near_high & away_from_mid & bias_ok, "Range_Structure_Event_Type"] = 1
    out["Range_Structure_Raw_Side"] = np.sign(out["Structure_Bias_TStat"]).astype("float64")

    out.replace([np.inf, -np.inf], np.nan, inplace=True)
    return out


def _extract_v1_spaced_range_structure_events(
    features: pd.DataFrame,
    *,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    if min_gap_bars < 0:
        raise CandidateEventError("min_gap_bars must be >= 0")
    if "Range_Structure_Event_Type" not in features.columns:
        raise CandidateEventError("Feature table missing Range_Structure_Event_Type")

    selected_indices: list[int] = []
    last_event_i = -10**9
    event_types = pd.to_numeric(features["Range_Structure_Event_Type"], errors="coerce").to_numpy(dtype="float64")
    sides = pd.to_numeric(features["Range_Structure_Raw_Side"], errors="coerce").to_numpy(dtype="float64")

    for i, event_type in enumerate(event_types):
        if not np.isfinite(event_type) or event_type == 0:
            continue
        if not np.isfinite(sides[i]) or sides[i] == 0:
            continue
        if i - last_event_i < min_gap_bars:
            continue
        selected_indices.append(i)
        last_event_i = i

    if not selected_indices:
        return features.iloc[[]].copy()
    return features.iloc[selected_indices].copy().reset_index(drop=True)


def _validate_candidate_events(events: pd.DataFrame) -> None:
    missing = [col for col in _required_event_columns() if col not in events.columns]
    if missing:
        raise CandidateEventError(f"Candidate events missing required columns: {missing}")
    if events.empty:
        raise CandidateEventError("Candidate event generator produced zero rangestructure_short events.")

    forbidden_present = sorted(_forbidden_event_columns().intersection(events.columns))
    if forbidden_present:
        raise CandidateEventError(f"Candidate events contain forbidden research/live-decision columns: {forbidden_present}")
    if not (events["edge_id"] == EDGE_ID).all():
        raise CandidateEventError("Candidate events contain unexpected edge_id values.")
    sides = pd.to_numeric(events["side"], errors="coerce")
    if not sides.isin([-1, 1]).all():
        raise CandidateEventError("Range-structure raw candidate sides must be +/-1 from Structure_Bias_TStat.")
    if not (events["candidate_event_generator"] == CANDIDATE_EVENT_GENERATOR).all():
        raise CandidateEventError("Candidate events contain unexpected generator values.")
    event_types = pd.to_numeric(events["Range_Structure_Event_Type"], errors="coerce")
    if not event_types.isin([-1, 1]).all():
        raise CandidateEventError("Range_Structure_Event_Type must be -1 near-low or +1 near-high.")
    if events["uses_future_information"].astype(bool).any():
        raise CandidateEventError("Candidate events must not use future information.")
    if not events["event_known_after_close"].astype(bool).all():
        raise CandidateEventError("Candidate events must be known after bar close.")
    if not np.isfinite(pd.to_numeric(events["Event_Vol"], errors="coerce").to_numpy(dtype="float64")).all():
        raise CandidateEventError("Candidate events contain non-finite Event_Vol values.")


def generate_v1_rangestructure_short_candidate_events(
    features: pd.DataFrame,
    *,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    """Generate the same raw V1 range-structure events as long before short filtering."""

    expanded = add_v1_range_structure_features(features)
    spaced = _extract_v1_spaced_range_structure_events(expanded, min_gap_bars=min_gap_bars)
    if spaced.empty:
        spaced = pd.DataFrame(columns=["Datetime", "Bar_Start", *EVENT_CONTEXT_COLUMNS])

    keep_cols = [
        "Datetime", "Bar_Start", "Open", "High", "Low", "Close",
        *[col for col in EVENT_CONTEXT_COLUMNS if col in spaced.columns],
    ]
    events = spaced[[col for col in keep_cols if col in spaced.columns]].copy()

    events["edge_id"] = EDGE_ID
    events["side"] = np.sign(pd.to_numeric(events["Structure_Bias_TStat"], errors="coerce")).astype("int64")
    events["event_id"] = events["Datetime"].apply(
        lambda ts: f"{EDGE_ID}|{pd.Timestamp(ts).isoformat()}|range_structure"
    )
    events["candidate_event_generator"] = CANDIDATE_EVENT_GENERATOR
    events["event_known_after_close"] = True
    events["uses_future_information"] = False
    events["range_lookback"] = int(RANGE_LOOKBACK)
    events["extreme_zone_threshold"] = float(EXTREME_ZONE_THRESHOLD)
    events["structure_bias_lookback"] = int(STRUCTURE_BIAS_LOOKBACK)
    events["structure_bias_tstat_threshold"] = float(STRUCTURE_BIAS_TSTAT_THRESHOLD)
    events["max_mid_range_position"] = float(MAX_MID_RANGE_POSITION)
    events["min_gap_bars"] = int(min_gap_bars)
    events["event_vol_lookback"] = int(EVENT_VOL_LOOKBACK)
    events["event_vol_ewm_span"] = int(EVENT_VOL_EWM_SPAN)

    events["Datetime"] = pd.to_datetime(events["Datetime"], utc=True, errors="coerce")
    events["Bar_Start"] = pd.to_datetime(events["Bar_Start"], utc=True, errors="coerce")
    excluded = {
        "edge_id", "event_id", "candidate_event_generator", "Datetime", "Bar_Start",
        "event_known_after_close", "uses_future_information",
    }
    for col in [c for c in events.columns if c not in excluded]:
        events[col] = pd.to_numeric(events[col], errors="coerce")
    events = events.dropna(
        subset=["Datetime", "Bar_Start", "Event_Vol", "Structure_Bias_TStat", "Range_Structure_Event_Type", "side"]
    ).copy()
    events = events[events["side"].isin([-1, 1])].copy()
    events = events.sort_values("Datetime").reset_index(drop=True)

    ordered_cols = [
        "Datetime", "Bar_Start", "edge_id", "side", "Event_Vol", "event_id", "candidate_event_generator",
        "Range_Structure_Event_Type", "Structure_Bias_TStat", "Range_Position", "Range_High", "Range_Low", "Range_Width",
        "Range_Compression_Ratio", "Structure_Bias_Mean", "Structure_Bias_Std",
        "event_known_after_close", "uses_future_information",
        *[
            col for col in events.columns
            if col not in _required_event_columns()
            and col not in {
                "Range_Position", "Range_High", "Range_Low", "Range_Width",
                "Range_Compression_Ratio", "Structure_Bias_Mean", "Structure_Bias_Std",
            }
        ],
    ]
    events = events[[col for col in ordered_cols if col in events.columns]].copy()

    _validate_candidate_events(events)
    return events


def validate_candidate_events(events: pd.DataFrame) -> None:
    _validate_candidate_events(events)


def candidate_event_contract() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "candidate_event_generator": CANDIDATE_EVENT_GENERATOR,
        "event_logic": "prior range extreme + past-only structural bias strength",
        "range_lookback": RANGE_LOOKBACK,
        "extreme_zone_threshold": EXTREME_ZONE_THRESHOLD,
        "structure_bias_lookback": STRUCTURE_BIAS_LOOKBACK,
        "structure_bias_tstat_threshold": STRUCTURE_BIAS_TSTAT_THRESHOLD,
        "max_mid_range_position": MAX_MID_RANGE_POSITION,
        "min_gap_bars": MIN_GAP_BARS,
        "side_rule_raw": "side = sign(Structure_Bias_TStat); primary_side.py filters side=-1 for rangestructure_short",
        "range_structure_event_type_meaning": "-1 near prior range low, +1 near prior range high; location only, not final direction",
        "event_fields_are_model_inputs": False,
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
        "v1_reference": "NASDAQ/range-structure-independent-edge/4_range_structure_event_sampling.py",
    }


if __name__ == "__main__":
    print("✅ NASDAQ/rangestructure_short candidate_events.py import/self-contract check passed.")
    print(candidate_event_contract())
