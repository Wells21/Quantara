"""
Candidate event generation for NASDAQ/reversal_long.

V1 source:
- NASDAQ/mean_reversion-independent-deep-reversal/4_deep_reversal_event_sampling.py

Core V1 idea:
- Build a local Kalman fair-value proxy from Close.
- Measure Close deviation from that local reference.
- Convert deviation to a rolling z-score.
- Fire reversal events when |Deviation_Z| >= 0.80 with a 5-bar gap.

V2 side-specialization:
- This edge is long-only.
- It emits only oversold local-fair-value deviations:
    Deviation_Side = -1 -> side = +1 long.
- Candidate events are label-free and live-safe.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

EDGE_ID = "NASDAQ/reversal_long"
SIDE_VALUE = 1
DEVIATION_SIDE = -1
CANDIDATE_EVENT_GENERATOR = "reversal_long_v1_oversold_kalman_deviation_candidate_events"

VOL_LOOKBACK = 50
VOL_EWM_SPAN = 100
MIN_VOL = 1e-8
DEV_WINDOW = 50
DEV_Z_THRESHOLD = 0.80
MIN_GAP_BARS = 5
EPS = 1e-12

EVENT_CONTEXT_COLUMNS = [
    "Event_Vol",
    "Kalman_Close_Local",
    "Dist_Kalman_Local",
    "Deviation_Z",
    "Deviation_Side",
    "Regime_State",
    "Regime_Entropy",
    "Regime_Duration",
    "Prob_State_0",
    "Prob_State_1",
    "Prob_State_2",
    "Prob_State_3",
]


class CandidateEventError(RuntimeError):
    """Raised when candidate event generation must fail closed."""


def _required_event_columns() -> list[str]:
    return [
        "Datetime",
        "Bar_Start",
        "edge_id",
        "side",
        "Event_Vol",
        "event_id",
        "candidate_event_generator",
        "Deviation_Side",
        "Deviation_Z",
        "event_known_after_close",
        "uses_future_information",
    ]


def _forbidden_event_columns() -> set[str]:
    return {
        "meta_label",
        "t1",
        "barrier_hit",
        "resolution_source",
        "entry_price",
        "pt_price",
        "sl_price",
        "realized_r",
        "raw_probability",
        "calibrated_probability",
        "afml_bet_size",
        "approved_signal",
    }


def _normalize_feature_input(features: pd.DataFrame) -> pd.DataFrame:
    required = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close"]
    missing = [col for col in required if col not in features.columns]
    if missing:
        raise CandidateEventError(f"Input features missing required columns: {missing}")

    df = features.copy()
    df["Datetime"] = pd.to_datetime(df["Datetime"], utc=True, errors="coerce")
    df["Bar_Start"] = pd.to_datetime(df["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open",
        "High",
        "Low",
        "Close",
        "Regime_State",
        "Regime_Entropy",
        "Regime_Duration",
        "Prob_State_0",
        "Prob_State_1",
        "Prob_State_2",
        "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in df.columns]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=required).copy()
    df = df.sort_values("Datetime").reset_index(drop=True)
    if df.empty:
        raise CandidateEventError("Input features are empty after normalization.")
    return df


def apply_1d_kalman_filter(prices: pd.Series) -> pd.Series:
    values = pd.to_numeric(prices, errors="coerce").astype("float64")
    if values.isna().any():
        values = values.ffill().bfill()
    n = len(values)
    if n == 0:
        return pd.Series(dtype="float64", index=prices.index)

    state_means = np.zeros(n, dtype="float64")
    state_covs = np.zeros(n, dtype="float64")
    state_means[0] = float(values.iloc[0])
    state_covs[0] = 1.0

    process_variance = 1e-5
    measurement_variance = 1e-3
    for t in range(1, n):
        prior_mean = state_means[t - 1]
        prior_cov = state_covs[t - 1] + process_variance
        kalman_gain = prior_cov / (prior_cov + measurement_variance)
        state_means[t] = prior_mean + kalman_gain * (float(values.iloc[t]) - prior_mean)
        state_covs[t] = (1.0 - kalman_gain) * prior_cov

    return pd.Series(state_means, index=prices.index)


def add_v1_deep_reversal_features(
    features: pd.DataFrame,
    *,
    vol_lookback: int = VOL_LOOKBACK,
    vol_ewm_span: int = VOL_EWM_SPAN,
    dev_window: int = DEV_WINDOW,
    min_vol: float = MIN_VOL,
) -> pd.DataFrame:
    """Add V1 Step 4 deep-reversal event features.

    This function is live-safe: it uses only the current closed bar plus rolling
    history available at that bar close.
    """

    if vol_lookback <= 0:
        raise CandidateEventError("vol_lookback must be > 0")
    if vol_ewm_span <= 0:
        raise CandidateEventError("vol_ewm_span must be > 0")
    if dev_window <= 1:
        raise CandidateEventError("dev_window must be > 1")
    if min_vol <= 0:
        raise CandidateEventError("min_vol must be > 0")

    out = _normalize_feature_input(features)
    close = out["Close"].astype("float64")

    ret = np.log((close + EPS) / (close.shift(vol_lookback) + EPS))
    out["Event_Vol"] = ret.ewm(span=vol_ewm_span, adjust=False).std().clip(lower=min_vol)

    out["Kalman_Close_Local"] = apply_1d_kalman_filter(close)
    out["Dist_Kalman_Local"] = (close - out["Kalman_Close_Local"]) / (out["Kalman_Close_Local"] + EPS)

    dev_mean = out["Dist_Kalman_Local"].rolling(dev_window).mean()
    dev_std = out["Dist_Kalman_Local"].rolling(dev_window).std().clip(lower=min_vol)
    out["Deviation_Z"] = (out["Dist_Kalman_Local"] - dev_mean) / (dev_std + EPS)

    out["Deviation_Side"] = 0
    out.loc[out["Deviation_Z"] >= DEV_Z_THRESHOLD, "Deviation_Side"] = 1
    out.loc[out["Deviation_Z"] <= -DEV_Z_THRESHOLD, "Deviation_Side"] = -1

    out.replace([np.inf, -np.inf], np.nan, inplace=True)
    return out


def _extract_v1_spaced_deep_reversal_events(
    features: pd.DataFrame,
    *,
    z_threshold: float = DEV_Z_THRESHOLD,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    """Preserve V1 spacing across both overbought and oversold deep-reversal events."""

    if z_threshold <= 0:
        raise CandidateEventError("z_threshold must be > 0")
    if min_gap_bars < 0:
        raise CandidateEventError("min_gap_bars must be >= 0")
    if "Deviation_Z" not in features.columns:
        raise CandidateEventError("Feature table missing Deviation_Z")

    selected_indices: list[int] = []
    last_event_i = -10**9
    z_values = pd.to_numeric(features["Deviation_Z"], errors="coerce").to_numpy(dtype="float64")

    for i, z in enumerate(z_values):
        if not np.isfinite(z):
            continue
        if abs(z) < z_threshold:
            continue
        if i - last_event_i < min_gap_bars:
            continue
        selected_indices.append(i)
        last_event_i = i

    if not selected_indices:
        return features.iloc[[]].copy()
    return features.iloc[selected_indices].copy().reset_index(drop=True)


def _validate_candidate_events(events: pd.DataFrame) -> None:
    missing = [col for col in _required_event_columns() if col not in events.columns]
    if missing:
        raise CandidateEventError(f"Candidate events missing required columns: {missing}")
    if events.empty:
        raise CandidateEventError("Candidate event generator produced zero reversal_long events.")

    forbidden_present = sorted(_forbidden_event_columns().intersection(events.columns))
    if forbidden_present:
        raise CandidateEventError(f"Candidate events contain forbidden research/live-decision columns: {forbidden_present}")
    if not (events["edge_id"] == EDGE_ID).all():
        raise CandidateEventError("Candidate events contain unexpected edge_id values.")
    if not (pd.to_numeric(events["side"], errors="coerce") == SIDE_VALUE).all():
        raise CandidateEventError("reversal_long candidate events must have side=+1 only.")
    if not (events["candidate_event_generator"] == CANDIDATE_EVENT_GENERATOR).all():
        raise CandidateEventError("Candidate events contain unexpected generator values.")
    if not (pd.to_numeric(events["Deviation_Side"], errors="coerce") == DEVIATION_SIDE).all():
        raise CandidateEventError("reversal_long emits Deviation_Side=-1 oversold events only.")
    if events["uses_future_information"].astype(bool).any():
        raise CandidateEventError("Candidate events must not use future information.")
    if not events["event_known_after_close"].astype(bool).all():
        raise CandidateEventError("Candidate events must be known after bar close.")
    if not np.isfinite(pd.to_numeric(events["Event_Vol"], errors="coerce").to_numpy(dtype="float64")).all():
        raise CandidateEventError("Candidate events contain non-finite Event_Vol values.")


def generate_v1_reversal_long_candidate_events(
    features: pd.DataFrame,
    *,
    z_threshold: float = DEV_Z_THRESHOLD,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    """Generate V1 Step 4 oversold Kalman-deviation events for reversal_long."""

    expanded = add_v1_deep_reversal_features(features)
    spaced = _extract_v1_spaced_deep_reversal_events(
        expanded,
        z_threshold=z_threshold,
        min_gap_bars=min_gap_bars,
    )
    long_events = spaced[pd.to_numeric(spaced["Deviation_Side"], errors="coerce") == DEVIATION_SIDE].copy()
    if long_events.empty:
        long_events = pd.DataFrame(columns=["Datetime", "Bar_Start", *EVENT_CONTEXT_COLUMNS])

    keep_cols = [
        "Datetime",
        "Bar_Start",
        "Open",
        "High",
        "Low",
        "Close",
        *[col for col in EVENT_CONTEXT_COLUMNS if col in long_events.columns],
    ]
    events = long_events[[col for col in keep_cols if col in long_events.columns]].copy()

    events["edge_id"] = EDGE_ID
    events["side"] = SIDE_VALUE
    events["event_id"] = events["Datetime"].apply(
        lambda ts: f"{EDGE_ID}|{pd.Timestamp(ts).isoformat()}|oversold_kalman_deviation"
    )
    events["candidate_event_generator"] = CANDIDATE_EVENT_GENERATOR
    events["event_known_after_close"] = True
    events["uses_future_information"] = False
    events["dev_window"] = int(DEV_WINDOW)
    events["dev_z_threshold"] = float(z_threshold)
    events["min_gap_bars"] = int(min_gap_bars)
    events["vol_lookback"] = int(VOL_LOOKBACK)
    events["vol_ewm_span"] = int(VOL_EWM_SPAN)

    events["Datetime"] = pd.to_datetime(events["Datetime"], utc=True, errors="coerce")
    events["Bar_Start"] = pd.to_datetime(events["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open",
        "High",
        "Low",
        "Close",
        "side",
        "Event_Vol",
        "Kalman_Close_Local",
        "Dist_Kalman_Local",
        "Deviation_Z",
        "Deviation_Side",
        "Regime_State",
        "Regime_Entropy",
        "Regime_Duration",
        "Prob_State_0",
        "Prob_State_1",
        "Prob_State_2",
        "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in events.columns]:
        events[col] = pd.to_numeric(events[col], errors="coerce")

    events = events.dropna(subset=["Datetime", "Bar_Start", "Event_Vol", "Deviation_Z", "Deviation_Side"]).copy()
    events = events.sort_values("Datetime").reset_index(drop=True)

    ordered_cols = [
        "Datetime",
        "Bar_Start",
        "edge_id",
        "side",
        "Event_Vol",
        "event_id",
        "candidate_event_generator",
        "Deviation_Side",
        "Deviation_Z",
        "Kalman_Close_Local",
        "Dist_Kalman_Local",
        "event_known_after_close",
        "uses_future_information",
        *[col for col in events.columns if col not in _required_event_columns() and col not in {"Kalman_Close_Local", "Dist_Kalman_Local"}],
    ]
    events = events[[col for col in ordered_cols if col in events.columns]].copy()

    _validate_candidate_events(events)
    return events


def validate_candidate_events(events: pd.DataFrame) -> None:
    _validate_candidate_events(events)


def candidate_event_contract() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "side": SIDE_VALUE,
        "deviation_side": DEVIATION_SIDE,
        "candidate_event_generator": CANDIDATE_EVENT_GENERATOR,
        "event_logic": "oversold local Kalman fair-value deviation -> long mean reversion",
        "vol_lookback": VOL_LOOKBACK,
        "vol_ewm_span": VOL_EWM_SPAN,
        "dev_window": DEV_WINDOW,
        "dev_z_threshold": DEV_Z_THRESHOLD,
        "min_gap_bars": MIN_GAP_BARS,
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
        "v1_reference": "NASDAQ/mean_reversion-independent-deep-reversal/4_deep_reversal_event_sampling.py",
    }


if __name__ == "__main__":
    print("✅ NASDAQ/reversal_long candidate_events.py import/self-contract check passed.")
    print(candidate_event_contract())
