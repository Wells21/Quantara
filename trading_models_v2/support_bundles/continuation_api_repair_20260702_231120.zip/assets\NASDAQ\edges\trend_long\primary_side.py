"""
Primary-side logic for NASDAQ/trend_long.

This module ports the useful V1 Step 5A trend primary-side engine into the V2
edge package boundary.

V1 reference:
- Core trend direction comes from Close_FFD - rolling_mean(Close_FFD, 50).
- Kalman confirmation is enabled.
- 5-bar return confirmation is enabled.
- Regime filter is disabled by default.

V2 contract:
- FFD must come from verified shared asset-level FFD artifacts.
- If runtime.py::build_features already includes Close_FFD, reuse it.
- If Close_FFD is absent, load it from the verified FFD artifact.
- The dashboard must not create Close_FFD or side-engine fields.
- This module creates candidate-event filtering context only. It does not create
  labels, probabilities, AFML sizes, or approved signals.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

_THIS_FILE = Path(__file__).resolve()
_EDGE_ROOT = _THIS_FILE.parent
_V2_ROOT = _THIS_FILE.parents[4]
_REPO_ROOT = _THIS_FILE.parents[5]
for _path in (_EDGE_ROOT, _V2_ROOT, _REPO_ROOT):
    path_str = str(_path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from shared.ffd.verify_asset_ffd_manifest import verify_asset_ffd_manifest  # noqa: E402


EDGE_ID = "NASDAQ/trend_long"
ASSET = "NASDAQ"
SIDE_VALUE = 1
EPS = 1e-12

TREND_WINDOW = 50
TREND_THRESHOLD = 0.0
USE_REGIME_FILTER = False
USE_KALMAN_CONFIRM = True
KALMAN_DIST_THRESHOLD = 0.0
USE_RETURN_CONFIRM = True
RETURN_LOOKBACK = 5
LIVE_BUFFER_BARS = 150


class PrimarySideError(RuntimeError):
    """Raised when primary-side generation must fail closed."""


def load_verified_ffd_features(asset: str = ASSET) -> pd.DataFrame:
    """Load verified shared asset-level FFD features."""

    verification = verify_asset_ffd_manifest(asset)
    path = _V2_ROOT / verification["features"]
    if not path.exists():
        raise PrimarySideError(f"Verified FFD features path does not exist: {path}")

    ffd = pd.read_csv(path)
    required = ["Datetime", "Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]
    missing = [col for col in required if col not in ffd.columns]
    if missing:
        raise PrimarySideError(f"FFD features missing required columns: {missing}")

    ffd["Datetime"] = pd.to_datetime(ffd["Datetime"], utc=True, errors="coerce")
    for col in ["Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]:
        ffd[col] = pd.to_numeric(ffd[col], errors="coerce")
    ffd = ffd.dropna(subset=required).copy()
    ffd = ffd.sort_values("Datetime").reset_index(drop=True)
    if ffd.empty:
        raise PrimarySideError("Verified FFD features are empty after normalization.")
    return ffd


def _compute_local_kalman(close: pd.Series) -> pd.Series:
    """V1 local Kalman smoother used by Step 5A."""

    values = close.to_numpy(dtype="float64")
    n = len(values)
    if n == 0:
        raise PrimarySideError("Cannot compute Kalman on empty close series.")

    kalman = np.zeros(n, dtype="float64")
    cov = np.zeros(n, dtype="float64")
    kalman[0] = values[0]
    cov[0] = 1.0
    process_variance = 1e-5
    measurement_variance = 1e-3

    for t in range(1, n):
        prior_mean = kalman[t - 1]
        prior_cov = cov[t - 1] + process_variance
        k_gain = prior_cov / (prior_cov + measurement_variance)
        kalman[t] = prior_mean + k_gain * (values[t] - prior_mean)
        cov[t] = (1.0 - k_gain) * prior_cov

    return pd.Series(kalman, index=close.index)


def _attach_close_ffd(df: pd.DataFrame, ffd_features: pd.DataFrame | None = None) -> pd.DataFrame:
    """Ensure a clean Close_FFD column exists without duplicate merge suffixes."""

    out = df.copy()
    if "Close_FFD" in out.columns:
        out["Close_FFD"] = pd.to_numeric(out["Close_FFD"], errors="coerce")
        return out

    ffd = load_verified_ffd_features() if ffd_features is None else ffd_features.copy()
    ffd["Datetime"] = pd.to_datetime(ffd["Datetime"], utc=True, errors="coerce")
    ffd["Close_FFD"] = pd.to_numeric(ffd["Close_FFD"], errors="coerce")
    ffd = ffd.dropna(subset=["Datetime", "Close_FFD"]).copy()
    ffd = ffd.sort_values("Datetime").reset_index(drop=True)

    merged = out.merge(ffd[["Datetime", "Close_FFD"]], on="Datetime", how="left", validate="one_to_one")
    return merged.sort_values("Datetime").reset_index(drop=True)


def build_primary_side_context(features: pd.DataFrame, ffd_features: pd.DataFrame | None = None) -> pd.DataFrame:
    """Build V1 Step 5A primary-side context on the full feature timeline."""

    required = ["Datetime", "Close"]
    missing = [col for col in required if col not in features.columns]
    if missing:
        raise PrimarySideError(f"Primary-side input missing required columns: {missing}")

    df = features.copy()
    df["Datetime"] = pd.to_datetime(df["Datetime"], utc=True, errors="coerce")
    df["Close"] = pd.to_numeric(df["Close"], errors="coerce")
    df = df.dropna(subset=required).copy()
    df = df.sort_values("Datetime").reset_index(drop=True)

    merged = _attach_close_ffd(df, ffd_features=ffd_features)
    if "Close_FFD" not in merged.columns:
        raise PrimarySideError("Close_FFD was not available after verified FFD attachment.")

    merged["ffd_ma"] = merged["Close_FFD"].rolling(TREND_WINDOW).mean()
    merged["trend_signal"] = merged["Close_FFD"] - merged["ffd_ma"]

    merged["Kalman_Close_Local"] = _compute_local_kalman(merged["Close"])
    merged["Dist_Kalman_Local"] = (
        (merged["Close"] - merged["Kalman_Close_Local"]) /
        (merged["Kalman_Close_Local"] + EPS)
    )

    ret_col = f"Trend_Return_{RETURN_LOOKBACK}"
    merged[ret_col] = np.log((merged["Close"] + EPS) / (merged["Close"].shift(RETURN_LOOKBACK) + EPS))

    trend_core_side = np.zeros(len(merged), dtype="int64")
    trend_core_side[merged["trend_signal"] > TREND_THRESHOLD] = 1
    trend_core_side[merged["trend_signal"] < -TREND_THRESHOLD] = -1
    merged["trend_core_side"] = trend_core_side
    merged["regime_ok"] = 1

    if USE_KALMAN_CONFIRM:
        merged["kalman_ok"] = np.where(
            merged["trend_core_side"] == 1,
            (merged["Dist_Kalman_Local"] > KALMAN_DIST_THRESHOLD).astype("int64"),
            np.where(
                merged["trend_core_side"] == -1,
                (merged["Dist_Kalman_Local"] < -KALMAN_DIST_THRESHOLD).astype("int64"),
                0,
            ),
        )
    else:
        merged["kalman_ok"] = 1

    if USE_RETURN_CONFIRM:
        merged["return_ok"] = np.where(
            merged["trend_core_side"] == 1,
            (merged[ret_col] > 0).astype("int64"),
            np.where(merged["trend_core_side"] == -1, (merged[ret_col] < 0).astype("int64"), 0),
        )
    else:
        merged["return_ok"] = 1

    merged["primary_side"] = np.where(
        (merged["trend_core_side"] == SIDE_VALUE)
        & (merged["regime_ok"] == 1)
        & (merged["kalman_ok"] == 1)
        & (merged["return_ok"] == 1),
        SIDE_VALUE,
        0,
    ).astype("int64")

    return merged


def filter_long_events_with_primary_side(events: pd.DataFrame, features: pd.DataFrame) -> pd.DataFrame:
    """Filter positive CUSUM events using V1 Step 5A trend-long side logic."""

    if events.empty:
        raise PrimarySideError("Cannot filter empty event table.")
    if "Datetime" not in events.columns:
        raise PrimarySideError("Event table missing Datetime.")

    side_context = build_primary_side_context(features)
    ret_col = f"Trend_Return_{RETURN_LOOKBACK}"
    side_cols = [
        "Datetime",
        "Close_FFD",
        "ffd_ma",
        "trend_signal",
        "Kalman_Close_Local",
        "Dist_Kalman_Local",
        ret_col,
        "trend_core_side",
        "regime_ok",
        "kalman_ok",
        "return_ok",
        "primary_side",
    ]

    out = events.copy()
    out["Datetime"] = pd.to_datetime(out["Datetime"], utc=True, errors="coerce")
    out = out.merge(side_context[side_cols], on="Datetime", how="left", validate="one_to_one")
    out["primary_side_filter"] = (out["primary_side"] == SIDE_VALUE).astype("int64")
    out = out[out["primary_side_filter"] == 1].copy()
    out["side"] = SIDE_VALUE
    out = out.sort_values("Datetime").reset_index(drop=True)

    if out.empty:
        raise PrimarySideError("Primary-side filter removed all candidate events.")
    return out


def primary_side_config() -> dict[str, Any]:
    return {
        "trend_window": TREND_WINDOW,
        "trend_threshold": TREND_THRESHOLD,
        "use_regime_filter": USE_REGIME_FILTER,
        "use_kalman_confirm": USE_KALMAN_CONFIRM,
        "kalman_dist_threshold": KALMAN_DIST_THRESHOLD,
        "use_return_confirm": USE_RETURN_CONFIRM,
        "return_lookback": RETURN_LOOKBACK,
        "live_buffer_bars": LIVE_BUFFER_BARS,
        "core_trend_feature": "Close_FFD",
        "uses_verified_shared_ffd": True,
        "uses_future_information": False,
    }
