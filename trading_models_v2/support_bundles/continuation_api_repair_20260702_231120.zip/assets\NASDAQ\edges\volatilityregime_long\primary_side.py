"""
Primary-side logic for NASDAQ/volatilityregime_long.

V1 source:
- NASDAQ/volatility-regime-independent-edge/5a_volatility_regime_primary_side_engine.py

Core V1 mapping:
- Vol_Regime_Event=1 is non-directional compression-to-expansion.
- Bullish expansion candle -> side +1 long.
- Bearish expansion candle -> side -1 short.

V2 side-specialization:
- volatilityregime_long accepts bullish expansion candles only.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pandas as pd

_THIS_FILE = Path(__file__).resolve()
_EDGE_ROOT = _THIS_FILE.parent
_V2_ROOT = _THIS_FILE.parents[4]
_REPO_ROOT = _THIS_FILE.parents[5]
for _path in (_EDGE_ROOT, _V2_ROOT, _REPO_ROOT):
    path_str = str(_path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from shared.ffd.verify_asset_ffd_manifest import verify_asset_ffd_manifest  # noqa: E402

EDGE_ID = "NASDAQ/volatilityregime_long"
ASSET = "NASDAQ"
SIDE_VALUE = 1
LIVE_BUFFER_BARS = 200
MIN_BODY_SHARE = 0.10
LONG_CLOSE_LOCATION = 0.55
SHORT_CLOSE_LOCATION = 0.45

FORBIDDEN_PRIMARY_SIDE_COLUMNS = {
    "meta_label",
    "t1",
    "barrier_hit",
    "resolution_source",
    "entry_price",
    "pt_price",
    "sl_price",
    "realized_r",
    "raw_probability",
    "calibrated_probability",
    "afml_bet_size",
    "approved_signal",
    "Ticks",
    "Proxy_Value",
    "Tick_Activity_Ratio",
    "Proxy_Value_Ratio",
    "Activity_Impulse",
}


class PrimarySideError(RuntimeError):
    """Raised when primary-side generation must fail closed."""


def load_verified_ffd_features(asset: str = ASSET) -> pd.DataFrame:
    verification = verify_asset_ffd_manifest(asset)
    path = _V2_ROOT / verification["features"]
    if not path.exists():
        raise PrimarySideError(f"Verified FFD features path does not exist: {path}")

    ffd = pd.read_csv(path)
    required = ["Datetime", "Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]
    missing = [col for col in required if col not in ffd.columns]
    if missing:
        raise PrimarySideError(f"FFD features missing required columns: {missing}")

    ffd["Datetime"] = pd.to_datetime(ffd["Datetime"], utc=True, errors="coerce")
    for col in ["Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]:
        ffd[col] = pd.to_numeric(ffd[col], errors="coerce")
    ffd = ffd.dropna(subset=required).copy()
    ffd = ffd.sort_values("Datetime").reset_index(drop=True)
    if ffd.empty:
        raise PrimarySideError("Verified FFD features are empty after normalization.")
    return ffd


def _validate_primary_side_input(events: pd.DataFrame) -> pd.DataFrame:
    required = [
        "Datetime",
        "edge_id",
        "side",
        "Event_Vol",
        "Vol_Regime_Event",
        "Current_Vol_Ratio",
        "Was_Compressed",
        "Vol_Expansion",
        "Body_Direction",
        "Body_Share",
        "Close_Location",
    ]
    missing = [col for col in required if col not in events.columns]
    if missing:
        raise PrimarySideError(f"Primary-side input missing required columns: {missing}")

    forbidden_present = sorted(FORBIDDEN_PRIMARY_SIDE_COLUMNS.intersection(events.columns))
    if forbidden_present:
        raise PrimarySideError(f"Primary-side input contains forbidden research/live-decision or volume-proxy columns: {forbidden_present}")

    out = events.copy()
    out["Datetime"] = pd.to_datetime(out["Datetime"], utc=True, errors="coerce")
    if "Bar_Start" in out.columns:
        out["Bar_Start"] = pd.to_datetime(out["Bar_Start"], utc=True, errors="coerce")
    for col in [
        "side", "Event_Vol", "Vol_Regime_Event", "Current_Vol_Ratio", "Was_Compressed",
        "Vol_Expansion", "Body_Direction", "Body_Share", "Close_Location",
    ]:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=["Datetime", "side", "Event_Vol", "Vol_Regime_Event", "Current_Vol_Ratio", "Body_Direction", "Body_Share", "Close_Location"]).copy()
    if out.empty:
        raise PrimarySideError("Primary-side input is empty after normalization.")
    if not (out["edge_id"] == EDGE_ID).all():
        bad = out.loc[out["edge_id"] != EDGE_ID, "edge_id"].unique().tolist()
        raise PrimarySideError(f"volatilityregime_long primary side received wrong edge_id values: {bad}")
    if not (pd.to_numeric(out["Vol_Regime_Event"], errors="coerce") == 1).all():
        raise PrimarySideError("volatilityregime primary-side input must have Vol_Regime_Event=1.")
    if not (pd.to_numeric(out["Was_Compressed"], errors="coerce") == 1).all():
        raise PrimarySideError("volatilityregime primary-side input must have Was_Compressed=1.")
    if not (pd.to_numeric(out["Vol_Expansion"], errors="coerce") == 1).all():
        raise PrimarySideError("volatilityregime primary-side input must have Vol_Expansion=1.")
    return out.sort_values("Datetime").reset_index(drop=True)


def assign_volatilityregime_long_primary_side(events: pd.DataFrame) -> pd.DataFrame:
    out = _validate_primary_side_input(events)
    out["primary_side_rule"] = "Vol_Regime_Event=1 bullish expansion candle -> side=+1 long"

    long_expansion = (
        (pd.to_numeric(out["Vol_Regime_Event"], errors="coerce") == 1)
        & (pd.to_numeric(out["Body_Direction"], errors="coerce") > 0)
        & (pd.to_numeric(out["Body_Share"], errors="coerce") >= MIN_BODY_SHARE)
        & (pd.to_numeric(out["Close_Location"], errors="coerce") >= LONG_CLOSE_LOCATION)
    )
    out["primary_side"] = 0
    out.loc[long_expansion, "primary_side"] = SIDE_VALUE
    out["primary_side_filter"] = (out["primary_side"] == SIDE_VALUE).astype("int64")
    out = out[out["primary_side_filter"] == 1].copy()

    if out.empty:
        raise PrimarySideError("No volatilityregime_long events survived bullish expansion primary-side mapping.")
    if not (pd.to_numeric(out["Body_Direction"], errors="coerce") > 0).all():
        raise PrimarySideError("volatilityregime_long primary side must keep Body_Direction>0 only.")
    if not (pd.to_numeric(out["Body_Share"], errors="coerce") >= MIN_BODY_SHARE).all():
        raise PrimarySideError("volatilityregime_long primary side must keep Body_Share>=MIN_BODY_SHARE only.")
    if not (pd.to_numeric(out["Close_Location"], errors="coerce") >= LONG_CLOSE_LOCATION).all():
        raise PrimarySideError("volatilityregime_long primary side must keep Close_Location>=LONG_CLOSE_LOCATION only.")
    if not (out["primary_side"] == SIDE_VALUE).all():
        raise PrimarySideError("volatilityregime_long primary_side must be +1 only.")

    out["side"] = SIDE_VALUE
    out["Volatility_Regime_Event_Type"] = SIDE_VALUE
    return out.sort_values("Datetime").reset_index(drop=True)


def filter_long_events_with_primary_side(events: pd.DataFrame, features: pd.DataFrame | None = None) -> pd.DataFrame:
    return assign_volatilityregime_long_primary_side(events)


def validate_primary_side_events(events: pd.DataFrame) -> None:
    out = assign_volatilityregime_long_primary_side(events)
    if out.empty:
        raise PrimarySideError("Validated volatilityregime_long primary-side output is empty.")


def primary_side_config() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "side_value": SIDE_VALUE,
        "side_rule": "Vol_Regime_Event=1 + Body_Direction>0 + Body_Share>=0.10 + Close_Location>=0.55 -> side=+1 long",
        "min_body_share": MIN_BODY_SHARE,
        "long_close_location": LONG_CLOSE_LOCATION,
        "short_close_location": SHORT_CLOSE_LOCATION,
        "uses_verified_shared_ffd": True,
        "live_buffer_bars": LIVE_BUFFER_BARS,
        "price_only_event_gate": True,
        "forbidden_volume_proxy_inputs": ["Ticks", "Proxy_Value", "Tick_Activity_Ratio", "Proxy_Value_Ratio", "Activity_Impulse"],
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
        "v1_reference": "NASDAQ/volatility-regime-independent-edge/5a_volatility_regime_primary_side_engine.py",
    }


if __name__ == "__main__":
    print("✅ NASDAQ/volatilityregime_long primary_side.py import/self-contract check passed.")
    print(primary_side_config())
