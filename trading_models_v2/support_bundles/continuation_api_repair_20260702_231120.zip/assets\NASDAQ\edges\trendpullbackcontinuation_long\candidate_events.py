"""
Candidate event generation for NASDAQ/trendpullbackcontinuation_long.

Core idea:
- Detect a broad positive medium-term drift state from live-reproducible OHLC/FFD
  features.
- Fire long continuation events during short-term pullbacks/temporary weakness,
  not during fresh upside impulse like trend_long.
- Require that broader structure remains intact and the completed bar shows at
  least mild reclaim from the low.

Difference from NASDAQ/trend_long:
- trend_long = positive CUSUM impulse + FFD trend-side confirmation.
- trendpullbackcontinuation_long = positive drift state + pullback/reclaim timing.

Leakage rule:
- All trend, pullback, channel, and reclaim fields are computed from current/past
  completed bars only.
- No future high/low/close, labels, probabilities, AFML sizes, or execution
  decisions are used by the event gate.

Data rule:
- Price/time only. No real volume, tick volume, order book, liquidity labels, or
  dashboard-only features are allowed.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

EDGE_ID = "NASDAQ/trendpullbackcontinuation_long"
SIDE_VALUE = 1
CANDIDATE_EVENT_GENERATOR = "trendpullbackcontinuation_long_positive_drift_pullback_reclaim_candidate_events"

TREND_LOOKBACK = 50
PULLBACK_LOOKBACK = 5
PULLBACK_Z_LOOKBACK = 50
MIN_TREND_SLOPE_50 = 0.0
MIN_EMA_20_50_GAP = 0.0
MAX_PULLBACK_RETURN_Z = -0.20
MAX_PULLBACK_RETURN = 0.0
MAX_CHANNEL_POSITION_20 = 0.70
MIN_CHANNEL_POSITION_50 = 0.30
MIN_CLOSE_LOCATION = 0.40
MIN_LOWER_WICK_SHARE = 0.05
MIN_PULLBACK_DEPTH_ATR = 0.05
MIN_GAP_BARS = 3
EVENT_VOL_LOOKBACK = 50
EVENT_VOL_EWM_SPAN = 100
MIN_VOL = 1e-8
EPS = 1e-12

EVENT_CONTEXT_COLUMNS = [
    "Event_Vol",
    "Trend_Slope_50_Context",
    "EMA_20_50_Gap_Context",
    "FFD_Trend_Signal_50",
    "Positive_Drift_State",
    "Pullback_Return",
    "Pullback_Return_Z",
    "Pullback_Depth_ATR",
    "Channel_Position_20_Context",
    "Channel_Position_50_Context",
    "Current_Close_Location",
    "Lower_Wick_Share_Context",
    "Pullback_Reclaim",
    "Trend_Pullback_State_Key",
    "Trend_Pullback_Continuation_Event",
    "Regime_State",
    "Regime_Entropy",
    "Regime_Duration",
    "Prob_State_0",
    "Prob_State_1",
    "Prob_State_2",
    "Prob_State_3",
]


class CandidateEventError(RuntimeError):
    """Raised when candidate event generation must fail closed."""


def _required_event_columns() -> list[str]:
    return [
        "Datetime",
        "Bar_Start",
        "edge_id",
        "side",
        "Event_Vol",
        "event_id",
        "candidate_event_generator",
        "Positive_Drift_State",
        "Pullback_Return",
        "Pullback_Return_Z",
        "Channel_Position_20_Context",
        "Channel_Position_50_Context",
        "Current_Close_Location",
        "Pullback_Reclaim",
        "Trend_Pullback_Continuation_Event",
        "event_known_after_close",
        "uses_future_information",
    ]


def _forbidden_event_columns() -> set[str]:
    return {
        "meta_label",
        "t1",
        "barrier_hit",
        "resolution_source",
        "entry_price",
        "pt_price",
        "sl_price",
        "realized_r",
        "raw_probability",
        "calibrated_probability",
        "afml_bet_size",
        "approved_signal",
        "Ticks",
        "Proxy_Value",
        "Tick_Activity_Ratio",
        "Proxy_Value_Ratio",
        "Activity_Impulse",
    }


def _normalize_feature_input(features: pd.DataFrame) -> pd.DataFrame:
    required = [
        "Datetime",
        "Bar_Start",
        "Open",
        "High",
        "Low",
        "Close",
        "ATR_14",
        f"Log_Return_{PULLBACK_LOOKBACK}",
        "Trend_Slope_50",
        "EMA_20_50_Gap",
        "Channel_Position_20",
        "Channel_Position_50",
        "Close_Location_Recalc",
        "Lower_Wick_Share",
    ]
    missing = [col for col in required if col not in features.columns]
    if missing:
        raise CandidateEventError(f"Input features missing required trend-pullback columns: {missing}")

    df = features.copy()
    df["Datetime"] = pd.to_datetime(df["Datetime"], utc=True, errors="coerce")
    df["Bar_Start"] = pd.to_datetime(df["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open", "High", "Low", "Close", "ATR_14", f"Log_Return_{PULLBACK_LOOKBACK}", "Trend_Slope_50",
        "EMA_20_50_Gap", "Channel_Position_20", "Channel_Position_50", "Close_Location_Recalc",
        "Lower_Wick_Share", "Close_FFD", "Regime_State", "Regime_Entropy", "Regime_Duration",
        "Prob_State_0", "Prob_State_1", "Prob_State_2", "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in df.columns]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=required).copy()
    df = df.sort_values("Datetime").reset_index(drop=True)
    if df.empty:
        raise CandidateEventError("Input features are empty after normalization.")
    return df


def _add_event_vol(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    close = out["Close"].astype("float64")
    ret = np.log((close + EPS) / (close.shift(EVENT_VOL_LOOKBACK) + EPS))
    out["Event_Vol"] = ret.ewm(span=EVENT_VOL_EWM_SPAN, adjust=False).std().clip(lower=MIN_VOL)
    return out


def _shifted_zscore(x: pd.Series, window: int) -> pd.Series:
    return (x - x.rolling(window).mean().shift(1)) / (x.rolling(window).std().shift(1) + EPS)


def _bucket_pullback_return_z(x: float) -> str:
    if not np.isfinite(x):
        return "pullback_unknown"
    if x <= -1.00:
        return "pullback_deep"
    if x <= -0.50:
        return "pullback_medium"
    if x <= -0.20:
        return "pullback_light"
    return "pullback_flat"


def _bucket_channel_position(x: float) -> str:
    if not np.isfinite(x):
        return "channel_unknown"
    if x <= 0.30:
        return "channel_low"
    if x <= 0.55:
        return "channel_mid"
    if x <= 0.70:
        return "channel_upper_mid"
    return "channel_high"


def _bucket_reclaim(close_location: float, lower_wick_share: float) -> str:
    if not np.isfinite(close_location) or not np.isfinite(lower_wick_share):
        return "reclaim_unknown"
    if close_location >= 0.60 or lower_wick_share >= 0.20:
        return "reclaim_strong"
    if close_location >= 0.40 or lower_wick_share >= 0.05:
        return "reclaim_mild"
    return "reclaim_weak"


def add_trend_pullback_continuation_fields(features: pd.DataFrame) -> pd.DataFrame:
    out = _add_event_vol(_normalize_feature_input(features))
    close = out["Close"].astype("float64")
    high = out["High"].astype("float64")

    pullback_col = f"Log_Return_{PULLBACK_LOOKBACK}"
    out["Trend_Slope_50_Context"] = out["Trend_Slope_50"]
    out["EMA_20_50_Gap_Context"] = out["EMA_20_50_Gap"]
    out["Channel_Position_20_Context"] = out["Channel_Position_20"]
    out["Channel_Position_50_Context"] = out["Channel_Position_50"]
    out["Current_Close_Location"] = out["Close_Location_Recalc"]
    out["Lower_Wick_Share_Context"] = out["Lower_Wick_Share"]
    out["Pullback_Return"] = out[pullback_col]
    out["Pullback_Return_Z"] = _shifted_zscore(out["Pullback_Return"], PULLBACK_Z_LOOKBACK)

    recent_high = high.rolling(PULLBACK_LOOKBACK, min_periods=2).max()
    out["Pullback_Depth_ATR"] = (recent_high - close).clip(lower=0.0) / (out["ATR_14"].clip(lower=EPS) + EPS)

    if "Close_FFD" in out.columns:
        out["FFD_Trend_Signal_50"] = out["Close_FFD"] - out["Close_FFD"].rolling(TREND_LOOKBACK).mean()
    else:
        out["FFD_Trend_Signal_50"] = np.nan

    out["Positive_Drift_State"] = (
        (out["Trend_Slope_50_Context"] > MIN_TREND_SLOPE_50)
        | (out["EMA_20_50_Gap_Context"] > MIN_EMA_20_50_GAP)
        | (out["FFD_Trend_Signal_50"] > 0)
    ).astype("int64")

    pullback_is_weakness = (
        (out["Pullback_Return"] <= MAX_PULLBACK_RETURN)
        | (out["Pullback_Return_Z"] <= MAX_PULLBACK_RETURN_Z)
    )
    structure_ok = (
        (out["Channel_Position_20_Context"] <= MAX_CHANNEL_POSITION_20)
        & (out["Channel_Position_50_Context"] >= MIN_CHANNEL_POSITION_50)
        & (out["Pullback_Depth_ATR"] >= MIN_PULLBACK_DEPTH_ATR)
    )
    out["Pullback_Reclaim"] = (
        (out["Current_Close_Location"] >= MIN_CLOSE_LOCATION)
        | (out["Lower_Wick_Share_Context"] >= MIN_LOWER_WICK_SHARE)
    ).astype("int64")

    out["Pullback_Return_Bucket"] = out["Pullback_Return_Z"].map(_bucket_pullback_return_z)
    out["Channel_Position_Bucket"] = out["Channel_Position_20_Context"].map(_bucket_channel_position)
    out["Reclaim_Bucket"] = [
        _bucket_reclaim(cl, lw) for cl, lw in zip(out["Current_Close_Location"], out["Lower_Wick_Share_Context"])
    ]
    out["Trend_Pullback_State_Key"] = out[["Pullback_Return_Bucket", "Channel_Position_Bucket", "Reclaim_Bucket"]].astype(str).agg("|".join, axis=1)

    event_condition = (
        (out["Event_Vol"].notna())
        & (out["Positive_Drift_State"] == 1)
        & pullback_is_weakness
        & structure_ok
        & (out["Pullback_Reclaim"] == 1)
    )
    out["Trend_Pullback_Continuation_Event"] = event_condition.astype("int64")
    out.replace([np.inf, -np.inf], np.nan, inplace=True)
    return out


def _extract_spaced_events(features: pd.DataFrame, *, min_gap_bars: int = MIN_GAP_BARS) -> pd.DataFrame:
    if min_gap_bars < 0:
        raise CandidateEventError("min_gap_bars must be >= 0")
    selected_indices: list[int] = []
    last_event_i = -10**9
    flags = pd.to_numeric(features["Trend_Pullback_Continuation_Event"], errors="coerce").to_numpy(dtype="float64")
    for i, flag in enumerate(flags):
        if not np.isfinite(flag) or int(flag) != 1:
            continue
        if i - last_event_i < min_gap_bars:
            continue
        selected_indices.append(i)
        last_event_i = i
    if not selected_indices:
        return features.iloc[[]].copy()
    return features.iloc[selected_indices].copy().reset_index(drop=True)


def _validate_candidate_events(events: pd.DataFrame) -> None:
    missing = [col for col in _required_event_columns() if col not in events.columns]
    if missing:
        raise CandidateEventError(f"Candidate events missing required columns: {missing}")
    if events.empty:
        raise CandidateEventError("Candidate event generator produced zero trendpullbackcontinuation_long events.")
    forbidden_present = sorted(_forbidden_event_columns().intersection(events.columns))
    if forbidden_present:
        raise CandidateEventError(f"Candidate events contain forbidden research/live-decision or volume-proxy columns: {forbidden_present}")
    if not (events["edge_id"] == EDGE_ID).all():
        raise CandidateEventError("Candidate events contain unexpected edge_id values.")
    if not (pd.to_numeric(events["side"], errors="coerce") == SIDE_VALUE).all():
        raise CandidateEventError("trendpullbackcontinuation_long candidate events must have side=+1 only.")
    if not (events["candidate_event_generator"] == CANDIDATE_EVENT_GENERATOR).all():
        raise CandidateEventError("Candidate events contain unexpected generator values.")
    if not (pd.to_numeric(events["Trend_Pullback_Continuation_Event"], errors="coerce") == 1).all():
        raise CandidateEventError("Trend_Pullback_Continuation_Event must equal 1 for all candidate events.")
    if not (pd.to_numeric(events["Positive_Drift_State"], errors="coerce") == 1).all():
        raise CandidateEventError("Positive_Drift_State must equal 1 for all candidate events.")
    if not (pd.to_numeric(events["Channel_Position_20_Context"], errors="coerce") <= MAX_CHANNEL_POSITION_20).all():
        raise CandidateEventError("Candidate events must satisfy MAX_CHANNEL_POSITION_20.")
    if not (pd.to_numeric(events["Channel_Position_50_Context"], errors="coerce") >= MIN_CHANNEL_POSITION_50).all():
        raise CandidateEventError("Candidate events must satisfy MIN_CHANNEL_POSITION_50.")
    if not (pd.to_numeric(events["Pullback_Reclaim"], errors="coerce") == 1).all():
        raise CandidateEventError("Pullback_Reclaim must equal 1 for all candidate events.")
    if events["uses_future_information"].astype(bool).any():
        raise CandidateEventError("Candidate events must not use future information.")
    if not events["event_known_after_close"].astype(bool).all():
        raise CandidateEventError("Candidate events must be known after bar close.")
    if not np.isfinite(pd.to_numeric(events["Event_Vol"], errors="coerce").to_numpy(dtype="float64")).all():
        raise CandidateEventError("Candidate events contain non-finite Event_Vol values.")


def generate_v1_trendpullbackcontinuation_long_candidate_events(
    features: pd.DataFrame,
    *,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    expanded = add_trend_pullback_continuation_fields(features)
    spaced = _extract_spaced_events(expanded, min_gap_bars=min_gap_bars)
    if spaced.empty:
        spaced = pd.DataFrame(columns=["Datetime", "Bar_Start", *EVENT_CONTEXT_COLUMNS])

    keep_cols = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close", *[col for col in EVENT_CONTEXT_COLUMNS if col in spaced.columns]]
    events = spaced[[col for col in keep_cols if col in spaced.columns]].copy()
    events["edge_id"] = EDGE_ID
    events["side"] = SIDE_VALUE
    events["event_id"] = events["Datetime"].apply(lambda ts: f"{EDGE_ID}|{pd.Timestamp(ts).isoformat()}|trend_pullback_continuation")
    events["candidate_event_generator"] = CANDIDATE_EVENT_GENERATOR
    events["event_known_after_close"] = True
    events["uses_future_information"] = False
    events["trend_lookback"] = int(TREND_LOOKBACK)
    events["pullback_lookback"] = int(PULLBACK_LOOKBACK)
    events["max_pullback_return_z"] = float(MAX_PULLBACK_RETURN_Z)
    events["max_pullback_return"] = float(MAX_PULLBACK_RETURN)
    events["max_channel_position_20"] = float(MAX_CHANNEL_POSITION_20)
    events["min_channel_position_50"] = float(MIN_CHANNEL_POSITION_50)
    events["min_close_location"] = float(MIN_CLOSE_LOCATION)
    events["min_lower_wick_share"] = float(MIN_LOWER_WICK_SHARE)
    events["min_pullback_depth_atr"] = float(MIN_PULLBACK_DEPTH_ATR)
    events["min_gap_bars"] = int(min_gap_bars)
    events["event_vol_lookback"] = int(EVENT_VOL_LOOKBACK)
    events["event_vol_ewm_span"] = int(EVENT_VOL_EWM_SPAN)

    events["Datetime"] = pd.to_datetime(events["Datetime"], utc=True, errors="coerce")
    events["Bar_Start"] = pd.to_datetime(events["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open", "High", "Low", "Close", "side", "Event_Vol", "Trend_Slope_50_Context",
        "EMA_20_50_Gap_Context", "FFD_Trend_Signal_50", "Positive_Drift_State", "Pullback_Return",
        "Pullback_Return_Z", "Pullback_Depth_ATR", "Channel_Position_20_Context", "Channel_Position_50_Context",
        "Current_Close_Location", "Lower_Wick_Share_Context", "Pullback_Reclaim", "Trend_Pullback_Continuation_Event",
        "Regime_State", "Regime_Entropy", "Regime_Duration", "Prob_State_0", "Prob_State_1", "Prob_State_2", "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in events.columns]:
        events[col] = pd.to_numeric(events[col], errors="coerce")
    events = events.dropna(
        subset=[
            "Datetime", "Bar_Start", "Event_Vol", "Positive_Drift_State", "Pullback_Return",
            "Pullback_Return_Z", "Channel_Position_20_Context", "Channel_Position_50_Context",
            "Current_Close_Location", "Lower_Wick_Share_Context", "Pullback_Reclaim",
            "Trend_Pullback_Continuation_Event",
        ]
    ).copy()
    events = events.sort_values("Datetime").reset_index(drop=True)
    ordered_cols = [
        "Datetime", "Bar_Start", "edge_id", "side", "Event_Vol", "event_id", "candidate_event_generator",
        "Trend_Slope_50_Context", "EMA_20_50_Gap_Context", "FFD_Trend_Signal_50", "Positive_Drift_State",
        "Pullback_Return", "Pullback_Return_Z", "Pullback_Depth_ATR", "Channel_Position_20_Context",
        "Channel_Position_50_Context", "Current_Close_Location", "Lower_Wick_Share_Context", "Pullback_Reclaim",
        "Pullback_Return_Bucket", "Channel_Position_Bucket", "Reclaim_Bucket", "Trend_Pullback_State_Key",
        "Trend_Pullback_Continuation_Event", "event_known_after_close", "uses_future_information",
        *[col for col in events.columns if col not in _required_event_columns() and col not in {
            "Trend_Slope_50_Context", "EMA_20_50_Gap_Context", "FFD_Trend_Signal_50", "Pullback_Return",
            "Pullback_Return_Z", "Pullback_Depth_ATR", "Channel_Position_20_Context", "Channel_Position_50_Context",
            "Current_Close_Location", "Lower_Wick_Share_Context", "Pullback_Reclaim", "Pullback_Return_Bucket",
            "Channel_Position_Bucket", "Reclaim_Bucket", "Trend_Pullback_State_Key",
        }],
    ]
    events = events[[col for col in ordered_cols if col in events.columns]].copy()
    _validate_candidate_events(events)
    return events


def validate_candidate_events(events: pd.DataFrame) -> None:
    _validate_candidate_events(events)


def candidate_event_contract() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "side": SIDE_VALUE,
        "candidate_event_generator": CANDIDATE_EVENT_GENERATOR,
        "event_logic": "positive medium-term drift plus short-term pullback/reclaim -> long continuation",
        "trend_lookback": TREND_LOOKBACK,
        "pullback_lookback": PULLBACK_LOOKBACK,
        "min_trend_slope_50": MIN_TREND_SLOPE_50,
        "min_ema_20_50_gap": MIN_EMA_20_50_GAP,
        "max_pullback_return_z": MAX_PULLBACK_RETURN_Z,
        "max_pullback_return": MAX_PULLBACK_RETURN,
        "max_channel_position_20": MAX_CHANNEL_POSITION_20,
        "min_channel_position_50": MIN_CHANNEL_POSITION_50,
        "min_close_location": MIN_CLOSE_LOCATION,
        "min_lower_wick_share": MIN_LOWER_WICK_SHARE,
        "min_pullback_depth_atr": MIN_PULLBACK_DEPTH_ATR,
        "min_gap_bars": MIN_GAP_BARS,
        "price_only_event_gate": True,
        "forbidden_volume_proxy_inputs": ["Ticks", "Proxy_Value", "Tick_Activity_Ratio", "Proxy_Value_Ratio", "Activity_Impulse"],
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
    }


if __name__ == "__main__":
    print("✅ NASDAQ/trendpullbackcontinuation_long candidate_events.py import/self-contract check passed.")
    print(candidate_event_contract())
