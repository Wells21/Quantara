"""Export runtime-built research data for BTCUSD/drawdownhazardcontinuation_short."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any
import pandas as pd

_THIS_FILE = Path(__file__).resolve()
_EDGE_ROOT = _THIS_FILE.parent
_V2_ROOT = _THIS_FILE.parents[4]
_REPO_ROOT = _THIS_FILE.parents[5]
for _path in (_EDGE_ROOT, _V2_ROOT, _REPO_ROOT):
    _text = str(_path)
    if _text not in sys.path:
        sys.path.insert(0, _text)

import runtime  # noqa: E402
from candidate_events import (  # noqa: E402
    HAZARD_OBSERVATION_GAP_BARS,
    HAZARD_RESOLUTION_MAX_BARS,
    MAX_RECOVERY_FRACTION,
    MIN_DRAWDOWN_SEVERITY_PERCENTILE,
    MIN_EVENT_GAP_BARS,
    MIN_HAZARD_CELL_OBSERVATIONS,
    MIN_HAZARD_PROBABILITY,
    NEW_TROUGH_BUFFER_VOL,
    PRIMARY_PEAK_WINDOW,
    RECOVERY_SUCCESS_FRACTION,
    SEVERITY_BASELINE_WINDOW,
    candidate_event_contract,
    get_last_event_diagnostics,
)
from primary_side import PRIMARY_SIDE_RULE, primary_side_config  # noqa: E402
from shared.io.artifact_hash import hash_artifacts  # noqa: E402

EDGE_ID = "BTCUSD/drawdownhazardcontinuation_short"
SIDE_VALUE = -1
EXPORT_NAME = "research_dataset_v2_drawdownhazardcontinuation_short_selected_2r_1000"
ROW_BUILDER = "drawdownhazardcontinuation_short_v2_2r_1000_triple_barrier_model_rows"
EXPECTED_VERTICAL_HORIZON = 1000
EXPECTED_PT_MULTIPLIER = 2.0
EXPECTED_SL_MULTIPLIER = 1.0
GEOMETRY_STATUS = "selected_from_grid_scan"
GEOMETRY_SELECTION_SOURCE = "label_geometry_grid_scan"
GRID_SCAN_SELECTED_RANK = 1
GRID_SCAN_SELECTED_ROWS = 5538
GRID_SCAN_SELECTED_NET_MEAN_R = 0.10094
GRID_SCAN_SELECTED_GROSS_MEAN_R = 0.10094
GRID_SCAN_SELECTED_VERTICAL_RATE = 0.0040
GRID_SCAN_SELECTED_MEDIAN_HOLD_BARS = 40.0


class ResearchDatasetExportError(RuntimeError):
    pass


def _relative(path: Path) -> str:
    return path.resolve().relative_to(_V2_ROOT.resolve()).as_posix()


def _paths() -> dict[str, Path]:
    root = _EDGE_ROOT / "artifacts" / "research_dataset"
    return {
        "root": root,
        "feature_matrix": root / "btcusd_drawdownhazardcontinuation_short_feature_matrix.csv",
        "candidate_events": root / "btcusd_drawdownhazardcontinuation_short_candidate_events.csv",
        "model_rows": root / "btcusd_drawdownhazardcontinuation_short_model_rows.csv",
        "model_row_manifest": root / "model_row_manifest.json",
        "event_diagnostics": root / "event_diagnostics.json",
        "export_manifest": root / "research_dataset_manifest.json",
    }


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, default=str) + "\n",
        encoding="utf-8",
    )


def _feature_names() -> list[str]:
    return runtime._schema_feature_names()  # noqa: SLF001


def _feature_export(features: pd.DataFrame, feature_names: list[str]) -> pd.DataFrame:
    missing = [name for name in feature_names if name not in features.columns]
    if missing:
        raise ResearchDatasetExportError(f"Runtime features missing schema fields: {missing}")
    base = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close", "edge_id", "side"]
    return features[[column for column in base if column in features.columns] + feature_names].copy()


def _hazard_contract() -> dict[str, float | int]:
    return {
        "primary_peak_window": int(PRIMARY_PEAK_WINDOW),
        "severity_baseline_window": int(SEVERITY_BASELINE_WINDOW),
        "hazard_resolution_max_bars": int(HAZARD_RESOLUTION_MAX_BARS),
        "hazard_observation_gap_bars": int(HAZARD_OBSERVATION_GAP_BARS),
        "new_trough_buffer_vol": float(NEW_TROUGH_BUFFER_VOL),
        "recovery_success_fraction": float(RECOVERY_SUCCESS_FRACTION),
        "min_drawdown_severity_percentile": float(MIN_DRAWDOWN_SEVERITY_PERCENTILE),
        "max_recovery_fraction": float(MAX_RECOVERY_FRACTION),
        "min_hazard_probability": float(MIN_HAZARD_PROBABILITY),
        "min_hazard_cell_observations": int(MIN_HAZARD_CELL_OBSERVATIONS),
        "min_event_gap_bars": int(MIN_EVENT_GAP_BARS),
    }


def _event_metadata_columns() -> dict[str, str]:
    return {
        "primary_peak_window": "primary_peak_window",
        "severity_baseline_window": "severity_baseline_window",
        "hazard_resolution_max_bars": "hazard_resolution_max_bars",
        "hazard_observation_gap_bars": "hazard_observation_gap_bars",
        "new_trough_buffer_vol": "new_trough_buffer_vol",
        "recovery_success_fraction": "recovery_success_fraction",
        "min_drawdown_severity_percentile": "min_drawdown_severity_percentile",
        "max_recovery_fraction": "max_recovery_fraction",
        "min_hazard_probability": "min_hazard_probability",
        "min_hazard_cell_observations": "min_hazard_cell_observations",
        "min_event_gap_bars": "min_gap_bars",
    }


def _validate_module_contracts() -> None:
    expected = _hazard_contract()
    candidate = candidate_event_contract()
    primary = primary_side_config()
    for key, value in expected.items():
        if candidate.get(key) != value:
            raise ResearchDatasetExportError(
                f"candidate_events.py {key} mismatch: {candidate.get(key)!r} != {value!r}"
            )
    for key in [
        "min_drawdown_severity_percentile", "max_recovery_fraction",
        "min_hazard_probability", "min_hazard_cell_observations",
    ]:
        if primary.get(key) != expected[key]:
            raise ResearchDatasetExportError(
                f"primary_side.py {key} mismatch: {primary.get(key)!r} != {expected[key]!r}"
            )
    edge_yaml = runtime.load_contract().get("edge_yaml", {})
    yaml_contract = edge_yaml.get("drawdown_hazard_event_contract", {})
    for key, value in expected.items():
        if yaml_contract.get(key) != value:
            raise ResearchDatasetExportError(
                f"edge.yaml drawdown_hazard_event_contract.{key} mismatch: "
                f"{yaml_contract.get(key)!r} != {value!r}"
            )


def _validate_hazard_rows(frame: pd.DataFrame, name: str) -> None:
    metadata_columns = _event_metadata_columns()
    required = [
        "Drawdown_Hazard_Event", "Drawdown_Hazard_Active_State",
        "Drawdown_Hazard_State_Entry", "Drawdown_Hazard_Renewed_Impulse",
        "Negative_Event_Bar", "Drawdown_Active", "Log_Return_1",
        "Drawdown_Severity_Percentile_100_Over_1000", "Recovery_Fraction",
        "Drawdown_Hazard_Probability", "Drawdown_Hazard_Cell_Count", "Event_Vol",
        *metadata_columns.values(),
    ]
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise ResearchDatasetExportError(f"{name} missing drawdown-hazard fields: {missing}")
    for column in [
        "Drawdown_Hazard_Event", "Drawdown_Hazard_Active_State",
        "Negative_Event_Bar", "Drawdown_Active",
    ]:
        if not pd.to_numeric(frame[column], errors="coerce").eq(1).all():
            raise ResearchDatasetExportError(f"{name} violate {column}=1")
    entry = pd.to_numeric(frame["Drawdown_Hazard_State_Entry"], errors="coerce")
    renewed = pd.to_numeric(frame["Drawdown_Hazard_Renewed_Impulse"], errors="coerce")
    if not entry.isin([0, 1]).all() or not renewed.isin([0, 1]).all() or not (entry + renewed).eq(1).all():
        raise ResearchDatasetExportError(f"{name} contain invalid hazard event-type flags")
    checks = {
        "Log_Return_1": lambda x: x < 0,
        "Drawdown_Severity_Percentile_100_Over_1000": lambda x: x >= MIN_DRAWDOWN_SEVERITY_PERCENTILE,
        "Recovery_Fraction": lambda x: x <= MAX_RECOVERY_FRACTION,
        "Drawdown_Hazard_Probability": lambda x: x >= MIN_HAZARD_PROBABILITY,
        "Drawdown_Hazard_Cell_Count": lambda x: x >= MIN_HAZARD_CELL_OBSERVATIONS,
        "Event_Vol": lambda x: x > 0,
    }
    for column, predicate in checks.items():
        values = pd.to_numeric(frame[column], errors="coerce")
        if values.isna().any() or not predicate(values).all():
            observed = {
                "min": None if values.dropna().empty else float(values.min()),
                "max": None if values.dropna().empty else float(values.max()),
                "nan_count": int(values.isna().sum()),
            }
            raise ResearchDatasetExportError(
                f"{name} violate {column} under {_hazard_contract()}; observed={observed}"
            )
    expected_contract = _hazard_contract()
    for key, column in metadata_columns.items():
        values = pd.to_numeric(frame[column], errors="coerce")
        expected = expected_contract[key]
        if values.isna().any() or not values.eq(expected).all():
            raise ResearchDatasetExportError(
                f"{name} carry inconsistent {column}: expected {expected}"
            )


def _validate(
    features: pd.DataFrame,
    events: pd.DataFrame,
    rows: pd.DataFrame,
    manifest: dict[str, Any],
    feature_names: list[str],
) -> None:
    _validate_module_contracts()
    if not feature_names or features.empty or events.empty or rows.empty:
        raise ResearchDatasetExportError("Research export contains an empty required table")
    if not events["edge_id"].eq(EDGE_ID).all():
        raise ResearchDatasetExportError("Candidate events contain wrong edge_id")
    if not pd.to_numeric(events["side"], errors="coerce").eq(SIDE_VALUE).all():
        raise ResearchDatasetExportError("Runtime events must be side=-1 after mapping")
    if not pd.to_numeric(rows["side"], errors="coerce").eq(SIDE_VALUE).all():
        raise ResearchDatasetExportError("Model rows must be side=-1")
    _validate_hazard_rows(events, "Candidate events")
    _validate_hazard_rows(rows, "Model rows")
    if not rows["pt_price"].lt(rows["entry_price"]).all():
        raise ResearchDatasetExportError("Short PT must be below entry")
    if not rows["sl_price"].gt(rows["entry_price"]).all():
        raise ResearchDatasetExportError("Short SL must be above entry")
    expected = {
        "edge_id": EDGE_ID,
        "side_value": SIDE_VALUE,
        "primary_side_rule": PRIMARY_SIDE_RULE,
        "row_builder": ROW_BUILDER,
        "geometry_status": GEOMETRY_STATUS,
        "geometry_selection_source": GEOMETRY_SELECTION_SOURCE,
        "grid_scan_selected_rank": GRID_SCAN_SELECTED_RANK,
        "grid_scan_selected_rows": GRID_SCAN_SELECTED_ROWS,
        "grid_scan_selected_net_mean_R": GRID_SCAN_SELECTED_NET_MEAN_R,
        "grid_scan_selected_gross_mean_R": GRID_SCAN_SELECTED_GROSS_MEAN_R,
        "grid_scan_selected_vertical_rate": GRID_SCAN_SELECTED_VERTICAL_RATE,
        "grid_scan_selected_median_hold_bars": GRID_SCAN_SELECTED_MEDIAN_HOLD_BARS,
        "vertical_horizon": EXPECTED_VERTICAL_HORIZON,
        "pt_multiplier": EXPECTED_PT_MULTIPLIER,
        "sl_multiplier": EXPECTED_SL_MULTIPLIER,
        "short_barrier_contract": "pt_price_below_entry_sl_price_above_entry",
    }
    for key, value in expected.items():
        if manifest.get(key) != value:
            raise ResearchDatasetExportError(
                f"Model-row manifest {key} mismatch: {manifest.get(key)!r} != {value!r}"
            )
    forbidden = {
        "meta_label", "t1", "barrier_hit", "resolution_source", "entry_price",
        "pt_price", "sl_price", "realized_r", "raw_probability",
        "calibrated_probability", "afml_bet_size", "approved_signal",
        "Ticks", "Proxy_Value", "Tick_Activity_Ratio", "Proxy_Value_Ratio",
        "Activity_Impulse",
    }
    present = sorted(forbidden.intersection(events.columns))
    if present:
        raise ResearchDatasetExportError(f"Candidate events contain forbidden fields: {present}")


def export_research_dataset(*, overwrite: bool = False, dry_run: bool = False) -> dict[str, Any]:
    started = time.time()
    paths = _paths()
    outputs = [value for key, value in paths.items() if key != "root"]
    if dry_run:
        _validate_module_contracts()
        return {
            "status": "DRY_RUN_PASS",
            "edge_id": EDGE_ID,
            "hazard_contract": _hazard_contract(),
            "selected_geometry": {
                "vertical_horizon": EXPECTED_VERTICAL_HORIZON,
                "pt_multiplier": EXPECTED_PT_MULTIPLIER,
                "sl_multiplier": EXPECTED_SL_MULTIPLIER,
            },
            "grid_scan_selected_cell": {
                "rank": GRID_SCAN_SELECTED_RANK,
                "rows": GRID_SCAN_SELECTED_ROWS,
                "net_mean_R": GRID_SCAN_SELECTED_NET_MEAN_R,
                "gross_mean_R": GRID_SCAN_SELECTED_GROSS_MEAN_R,
                "vertical_rate": GRID_SCAN_SELECTED_VERTICAL_RATE,
                "median_hold_bars": GRID_SCAN_SELECTED_MEDIAN_HOLD_BARS,
            },
            "planned_outputs": {
                key: _relative(value) for key, value in paths.items() if key != "root"
            },
        }
    existing = [path for path in outputs if path.exists()]
    if existing and not overwrite:
        raise ResearchDatasetExportError(
            "Research outputs already exist; use --overwrite intentionally:\n"
            + "\n".join(f"- {path}" for path in existing)
        )
    paths["root"].mkdir(parents=True, exist_ok=True)
    feature_names = _feature_names()
    features = runtime.build_features(drop_warmup_rows=False)
    events = runtime.generate_candidate_events(features)
    rows, row_manifest = runtime.build_model_rows(features=features, events=events)
    feature_frame = _feature_export(features, feature_names)
    diagnostics = get_last_event_diagnostics()
    _validate(feature_frame, events, rows, row_manifest, feature_names)
    feature_frame.to_csv(paths["feature_matrix"], index=False)
    events.to_csv(paths["candidate_events"], index=False)
    rows.to_csv(paths["model_rows"], index=False)
    _write_json(paths["model_row_manifest"], row_manifest)
    _write_json(paths["event_diagnostics"], diagnostics)
    hashes = hash_artifacts(outputs[:-1], root=_V2_ROOT)
    export_manifest = {
        "edge_id": EDGE_ID,
        "export_name": EXPORT_NAME,
        "status": "research_dataset_exported_not_deployable",
        "hazard_contract": _hazard_contract(),
        "geometry_status": GEOMETRY_STATUS,
        "geometry_selection_source": GEOMETRY_SELECTION_SOURCE,
        "row_builder": ROW_BUILDER,
        "vertical_horizon": EXPECTED_VERTICAL_HORIZON,
        "pt_multiplier": EXPECTED_PT_MULTIPLIER,
        "sl_multiplier": EXPECTED_SL_MULTIPLIER,
        "reward_risk_ratio": EXPECTED_PT_MULTIPLIER / EXPECTED_SL_MULTIPLIER,
        "grid_scan_selected_rank": GRID_SCAN_SELECTED_RANK,
        "grid_scan_selected_rows": GRID_SCAN_SELECTED_ROWS,
        "grid_scan_selected_net_mean_R": GRID_SCAN_SELECTED_NET_MEAN_R,
        "grid_scan_selected_gross_mean_R": GRID_SCAN_SELECTED_GROSS_MEAN_R,
        "grid_scan_selected_vertical_rate": GRID_SCAN_SELECTED_VERTICAL_RATE,
        "grid_scan_selected_median_hold_bars": GRID_SCAN_SELECTED_MEDIAN_HOLD_BARS,
        "runtime_contract_status": runtime.load_contract()["runtime_status"],
        "feature_count": len(feature_names),
        "feature_names": feature_names,
        "rows_feature_matrix": len(feature_frame),
        "rows_candidate_events": len(events),
        "rows_model_rows": len(rows),
        "event_diagnostics": diagnostics,
        "outputs": {
            key: _relative(value) for key, value in paths.items() if key != "root"
        },
        "artifact_hashes": hashes,
        "elapsed_seconds": round(time.time() - started, 3),
    }
    _write_json(paths["export_manifest"], export_manifest)
    return export_manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    print(json.dumps(
        export_research_dataset(overwrite=args.overwrite, dry_run=args.dry_run),
        indent=2,
        default=str,
    ))


if __name__ == "__main__":
    main()
