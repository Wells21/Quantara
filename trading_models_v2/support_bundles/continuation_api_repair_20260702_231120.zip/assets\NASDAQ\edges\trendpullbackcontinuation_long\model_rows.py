"""
Model-row and research-label construction for NASDAQ/trendpullbackcontinuation_long.

Contract:
- side is fixed to +1.
- Trend_Pullback_Continuation_Event is fixed to 1.
- PT price must be above entry price.
- SL price must be below entry price.
- Labels are research-only and must never be used for live scoring.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

_THIS_FILE = Path(__file__).resolve()
_EDGE_ROOT = _THIS_FILE.parent
_V2_ROOT = _THIS_FILE.parents[4]
_REPO_ROOT = _THIS_FILE.parents[5]
for _path in (_EDGE_ROOT, _V2_ROOT, _REPO_ROOT):
    path_str = str(_path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

EDGE_ID = "NASDAQ/trendpullbackcontinuation_long"
SIDE_VALUE = 1
VERTICAL_HORIZON = 1000
PT_MULTIPLIER = 1.0
SL_MULTIPLIER = 1.0
FALLBACK_TIE_POLICY = "sl_first"
TICK_RESOLUTION_PRICE = "mid"
EPS = 1e-12


class ModelRowsError(RuntimeError):
    """Raised when model-row building must fail closed."""


def _normalize_datetime_col(df: pd.DataFrame, col: str) -> pd.DataFrame:
    out = df.copy()
    out[col] = pd.to_datetime(out[col], utc=True, errors="coerce")
    return out.dropna(subset=[col]).copy()


def _validate_events(events: pd.DataFrame) -> None:
    if events.empty:
        raise ModelRowsError("trendpullbackcontinuation_long events are empty.")
    required = [
        "side", "Event_Vol", "Positive_Drift_State", "Pullback_Return", "Pullback_Return_Z",
        "Pullback_Depth_ATR", "Channel_Position_20_Context", "Channel_Position_50_Context",
        "Current_Close_Location", "Lower_Wick_Share_Context", "Pullback_Reclaim",
        "Trend_Pullback_Continuation_Event",
    ]
    missing = [col for col in required if col not in events.columns]
    if missing:
        raise ModelRowsError(f"trendpullbackcontinuation_long events missing required columns: {missing}")
    if "edge_id" in events.columns and not (events["edge_id"] == EDGE_ID).all():
        bad = events.loc[events["edge_id"] != EDGE_ID, "edge_id"].unique().tolist()
        raise ModelRowsError(f"trendpullbackcontinuation_long events contain wrong edge_id values: {bad}")
    if not (pd.to_numeric(events["side"], errors="coerce") == SIDE_VALUE).all():
        raise ModelRowsError("trendpullbackcontinuation_long events must have side=+1 only.")
    if not (pd.to_numeric(events["Trend_Pullback_Continuation_Event"], errors="coerce") == 1).all():
        raise ModelRowsError("trendpullbackcontinuation_long events must have Trend_Pullback_Continuation_Event=1.")


def _barrier_prices(entry_price: float, trgt: float, side: int) -> tuple[float, float]:
    if side == 1:
        return entry_price * (1.0 + PT_MULTIPLIER * trgt), entry_price * (1.0 - SL_MULTIPLIER * trgt)
    if side == -1:
        return entry_price * (1.0 - PT_MULTIPLIER * trgt), entry_price * (1.0 + SL_MULTIPLIER * trgt)
    raise ModelRowsError(f"Unsupported side value: {side}")


def _ohlc_touches(bar_high: float, bar_low: float, pt_price: float, sl_price: float, side: int) -> tuple[bool, bool]:
    if side == 1:
        return bar_high >= pt_price, bar_low <= sl_price
    if side == -1:
        return bar_low <= pt_price, bar_high >= sl_price
    raise ModelRowsError(f"Unsupported side value: {side}")


def _resolve_fallback_tie() -> tuple[float, str | None, str]:
    if FALLBACK_TIE_POLICY == "sl_first":
        return 0.0, "sl", "fallback_sl_first"
    if FALLBACK_TIE_POLICY == "pt_first":
        return 1.0, "pt", "fallback_pt_first"
    if FALLBACK_TIE_POLICY == "drop":
        return np.nan, None, "fallback_drop"
    raise ModelRowsError(f"Unknown fallback tie policy: {FALLBACK_TIE_POLICY}")


def apply_triple_barrier_labels(
    bars: pd.DataFrame,
    events: pd.DataFrame,
    *,
    vertical_horizon: int = VERTICAL_HORIZON,
) -> tuple[pd.DataFrame, dict[str, int]]:
    if vertical_horizon <= 0:
        raise ModelRowsError("vertical_horizon must be > 0")
    required_bars = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close"]
    required_events = ["Datetime", "side", "Event_Vol"]
    missing_bars = [col for col in required_bars if col not in bars.columns]
    missing_events = [col for col in required_events if col not in events.columns]
    if missing_bars:
        raise ModelRowsError(f"Bars missing required columns: {missing_bars}")
    if missing_events:
        raise ModelRowsError(f"Events missing required columns: {missing_events}")

    _validate_events(events)

    full_df = _normalize_datetime_col(bars, "Datetime")
    full_df["Bar_Start"] = pd.to_datetime(full_df["Bar_Start"], utc=True, errors="coerce")
    for col in ["Open", "High", "Low", "Close"]:
        full_df[col] = pd.to_numeric(full_df[col], errors="coerce")
    full_df = full_df.dropna(subset=required_bars).sort_values("Datetime").drop_duplicates("Datetime").set_index("Datetime")

    event_df = _normalize_datetime_col(events, "Datetime")
    event_df["side"] = pd.to_numeric(event_df["side"], errors="coerce")
    event_df["Event_Vol"] = pd.to_numeric(event_df["Event_Vol"], errors="coerce")
    event_df = event_df.dropna(subset=required_events).sort_values("Datetime").drop_duplicates("Datetime").set_index("Datetime")

    highs, lows, closes = full_df["High"], full_df["Low"], full_df["Close"]
    index = full_df.index
    rows = []
    stats = {
        "events_seen": 0,
        "events_labeled": 0,
        "events_dropped_missing_timestamp": 0,
        "events_dropped_horizon": 0,
        "events_dropped_invalid_target": 0,
        "ambiguous_same_bar_count": 0,
        "tick_resolved_count": 0,
        "fallback_resolved_count": 0,
    }

    for t, row in event_df.iterrows():
        stats["events_seen"] += 1
        base = row.to_dict()
        base["Datetime"] = t
        if t not in full_df.index:
            stats["events_dropped_missing_timestamp"] += 1
            continue
        loc = index.get_loc(t)
        if not isinstance(loc, (int, np.integer)):
            stats["events_dropped_missing_timestamp"] += 1
            continue
        if loc + vertical_horizon >= len(full_df):
            stats["events_dropped_horizon"] += 1
            continue

        side = int(row["side"])
        trgt = float(row["Event_Vol"])
        start_price = float(closes.loc[t])
        if side != SIDE_VALUE or not np.isfinite(trgt) or trgt <= 0 or not np.isfinite(start_price):
            stats["events_dropped_invalid_target"] += 1
            continue

        pt_price, sl_price = _barrier_prices(start_price, trgt, side)
        future_idx = index[loc + 1: loc + vertical_horizon + 1]
        label = 0.0
        end_time = future_idx[-1]
        barrier_hit = "vertical"
        resolution_source = "vertical"

        for future_t in future_idx:
            pt_touched, sl_touched = _ohlc_touches(float(highs.loc[future_t]), float(lows.loc[future_t]), pt_price, sl_price, side)
            if pt_touched and sl_touched:
                stats["ambiguous_same_bar_count"] += 1
                label, barrier_hit, resolution_source = _resolve_fallback_tie()
                stats["fallback_resolved_count"] += 1
                end_time = future_t
                break
            if pt_touched:
                label, barrier_hit, resolution_source, end_time = 1.0, "pt", "ohlc", future_t
                break
            if sl_touched:
                label, barrier_hit, resolution_source, end_time = 0.0, "sl", "ohlc", future_t
                break

        if barrier_hit == "pt":
            realized_r = 1.0
        elif barrier_hit == "sl":
            realized_r = -1.0
        else:
            end_close = float(closes.loc[end_time])
            realized_r = side * ((end_close / start_price) - 1.0) / (trgt + EPS)

        base.update({
            "meta_label": int(label),
            "t1": end_time,
            "barrier_hit": barrier_hit,
            "resolution_source": resolution_source,
            "entry_price": start_price,
            "pt_price": pt_price,
            "sl_price": sl_price,
            "realized_r": realized_r,
        })
        rows.append(base)
        stats["events_labeled"] += 1

    labeled = pd.DataFrame(rows)
    if labeled.empty:
        raise ModelRowsError("Triple-barrier labeling produced zero rows.")
    labeled["Datetime"] = pd.to_datetime(labeled["Datetime"], utc=True)
    labeled["t1"] = pd.to_datetime(labeled["t1"], utc=True)
    labeled["meta_label"] = labeled["meta_label"].astype("int64")
    labeled["side"] = labeled["side"].astype("int64")
    if not (labeled["side"] == SIDE_VALUE).all():
        raise ModelRowsError("trendpullbackcontinuation_long labeled rows must remain side=+1.")
    if not (labeled["pt_price"] > labeled["entry_price"]).all():
        raise ModelRowsError("trendpullbackcontinuation_long PT must be above entry price.")
    if not (labeled["sl_price"] < labeled["entry_price"]).all():
        raise ModelRowsError("trendpullbackcontinuation_long SL must be below entry price.")
    return labeled.sort_values("Datetime").reset_index(drop=True), stats


def _safe_label_columns(labeled_events: pd.DataFrame, feature_names: list[str], keep_cols: list[str]) -> list[str]:
    base_label_cols = [
        "Datetime", "side", "Event_Vol", "meta_label", "t1", "barrier_hit", "resolution_source",
        "entry_price", "pt_price", "sl_price", "realized_r", "event_id", "candidate_event_generator",
        "Trend_Slope_50_Context", "EMA_20_50_Gap_Context", "FFD_Trend_Signal_50", "Positive_Drift_State",
        "Pullback_Return", "Pullback_Return_Z", "Pullback_Depth_ATR", "Channel_Position_20_Context",
        "Channel_Position_50_Context", "Current_Close_Location", "Lower_Wick_Share_Context", "Pullback_Reclaim",
        "Pullback_Return_Bucket", "Channel_Position_Bucket", "Reclaim_Bucket", "Trend_Pullback_State_Key",
        "Trend_Pullback_Continuation_Event", "primary_side", "primary_side_filter", "primary_side_rule",
    ]
    protected = set(feature_names) | set(keep_cols)
    cols: list[str] = []
    for col in base_label_cols:
        if col == "Datetime":
            cols.append(col)
        elif col in protected:
            continue
        elif col in labeled_events.columns:
            cols.append(col)
    return list(dict.fromkeys(cols))


def build_event_model_rows(
    *,
    features: pd.DataFrame,
    events: pd.DataFrame,
    bars: pd.DataFrame,
    feature_names: list[str],
    vertical_horizon: int = VERTICAL_HORIZON,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    labeled_events, stats = apply_triple_barrier_labels(bars, events, vertical_horizon=vertical_horizon)
    feat = _normalize_datetime_col(features, "Datetime")
    missing_features = [name for name in feature_names if name not in feat.columns]
    if missing_features:
        raise ModelRowsError(f"Feature table missing schema features: {missing_features}")

    keep_cols = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close", "edge_id", *feature_names]
    keep_cols = list(dict.fromkeys([col for col in keep_cols if col in feat.columns]))
    label_cols = _safe_label_columns(labeled_events, feature_names=feature_names, keep_cols=keep_cols)
    modeling = feat[keep_cols].merge(labeled_events[label_cols], on="Datetime", how="inner", validate="one_to_one")
    missing_after_merge = [name for name in feature_names if name not in modeling.columns]
    if missing_after_merge:
        raise ModelRowsError(f"Model row merge lost schema feature columns: {missing_after_merge}")

    before_required = len(modeling)
    modeling["t1"] = pd.to_datetime(modeling["t1"], utc=True, errors="coerce")
    modeling = modeling.dropna(subset=["side", "Event_Vol", "meta_label", "t1"]).copy()
    after_required = len(modeling)
    before_feature_drop = len(modeling)
    modeling = modeling.dropna(subset=feature_names).copy()
    after_feature_drop = len(modeling)
    if modeling.empty:
        raise ModelRowsError("All model rows were dropped after feature NaN filtering.")

    modeling["side"] = modeling["side"].astype("int64")
    modeling["meta_label"] = modeling["meta_label"].astype("int64")
    modeling = modeling.sort_values("Datetime").reset_index(drop=True)
    if not (modeling["side"] == SIDE_VALUE).all():
        raise ModelRowsError("trendpullbackcontinuation_long model rows must have side=+1 only.")
    if "Trend_Pullback_Continuation_Event" in modeling.columns and not (modeling["Trend_Pullback_Continuation_Event"] == 1).all():
        raise ModelRowsError("trendpullbackcontinuation_long model rows must have Trend_Pullback_Continuation_Event=1 only.")
    if not (modeling["pt_price"] > modeling["entry_price"]).all():
        raise ModelRowsError("trendpullbackcontinuation_long model rows must have pt_price above entry_price.")
    if not (modeling["sl_price"] < modeling["entry_price"]).all():
        raise ModelRowsError("trendpullbackcontinuation_long model rows must have sl_price below entry_price.")

    manifest = {
        "edge_id": EDGE_ID,
        "side_value": SIDE_VALUE,
        "row_builder": "trendpullbackcontinuation_long_v1_1r_triple_barrier_model_rows",
        "primary_side_rule": "positive medium-term drift + short-term pullback/reclaim -> side=+1 long",
        "rows_candidate_events_input": int(len(events)),
        "rows_labeled_events": int(len(labeled_events)),
        "rows_after_required_filter": int(after_required),
        "rows_after_feature_nan_filter": int(after_feature_drop),
        "required_rows_dropped": int(before_required - after_required),
        "feature_nan_rows_dropped": int(before_feature_drop - after_feature_drop),
        "feature_count": int(len(feature_names)),
        "vertical_horizon": int(vertical_horizon),
        "pt_multiplier": PT_MULTIPLIER,
        "sl_multiplier": SL_MULTIPLIER,
        "fallback_tie_policy": FALLBACK_TIE_POLICY,
        "tick_resolution_price": TICK_RESOLUTION_PRICE,
        "long_barrier_contract": "pt_price_above_entry_sl_price_below_entry",
        "labeling_stats": stats,
        "meta_label_distribution": {str(k): float(v) for k, v in modeling["meta_label"].value_counts(normalize=True).sort_index().to_dict().items()},
        "barrier_hit_distribution": {str(k): float(v) for k, v in modeling["barrier_hit"].value_counts(normalize=True).sort_index().to_dict().items()},
        "resolution_source_distribution": {str(k): float(v) for k, v in modeling["resolution_source"].value_counts(normalize=True).sort_index().to_dict().items()},
        "uses_future_information_for_labels": True,
        "live_scoring_must_not_use_label_columns": True,
    }
    return modeling, manifest


def model_row_config() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "side_value": SIDE_VALUE,
        "row_builder": "trendpullbackcontinuation_long_v1_1r_triple_barrier_model_rows",
        "vertical_horizon": VERTICAL_HORIZON,
        "pt_multiplier": PT_MULTIPLIER,
        "sl_multiplier": SL_MULTIPLIER,
        "fallback_tie_policy": FALLBACK_TIE_POLICY,
        "tick_resolution_price": TICK_RESOLUTION_PRICE,
        "long_barrier_contract": "pt_price_above_entry_sl_price_below_entry",
        "uses_future_information_for_labels": True,
        "live_scoring_must_not_use_label_columns": True,
    }


if __name__ == "__main__":
    print("✅ NASDAQ/trendpullbackcontinuation_long model_rows.py import/self-contract check passed.")
    print(model_row_config())
