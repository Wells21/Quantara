"""
Candidate event generation for NASDAQ/volatilitycarry_long.

V1 source:
- NASDAQ/volatility-carry-independent-edge/4_volatility_carry_event_sampling.py

Core V1 idea:
- Detect calm volatility bars using past-only Bar_Volatility_Bps thresholds.
- Require current volatility activity to remain below a shifted median ratio cap.
- Assign raw event direction from past-only drift t-stat.
- Volatility_Carry_Event_Type is directional: +1 positive calm drift, -1 negative calm drift.

V2 side-specialization:
- This module generates raw +/- volatility-carry events.
- primary_side.py filters this edge to Volatility_Carry_Event_Type=+1 -> side=+1 long.
- Volatility-carry fields are event/control/context fields, not generic model-schema features.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

EDGE_ID = "NASDAQ/volatilitycarry_long"
SIDE_VALUE = 1
CANDIDATE_EVENT_GENERATOR = "volatilitycarry_long_v1_calm_vol_positive_drift_candidate_events"

MIN_GAP_BARS = 3
VOL_LOOKBACK = 200
LOW_VOL_QUANTILE = 0.40
DRIFT_LOOKBACK = 50
DRIFT_TSTAT_THRESHOLD = 0.50
MAX_ACTIVITY_RATIO = 1.25
MIN_OBS = 20
EVENT_VOL_LOOKBACK = 50
EVENT_VOL_EWM_SPAN = 100
MIN_VOL = 1e-8
EPS = 1e-12

EVENT_CONTEXT_COLUMNS = [
    "Event_Vol",
    "Bar_Return",
    "Bar_Volatility_Bps",
    "Low_Vol_Threshold",
    "Vol_Median",
    "Volatility_Ratio",
    "Is_Calm_Vol",
    "Drift_Mean",
    "Drift_Std",
    "Drift_TStat",
    "Volatility_Carry_Event_Type",
    "Body_Direction",
    "Body_Share",
    "Close_Location",
    "Regime_State",
    "Regime_Entropy",
    "Regime_Duration",
    "Prob_State_0",
    "Prob_State_1",
    "Prob_State_2",
    "Prob_State_3",
]


class CandidateEventError(RuntimeError):
    """Raised when candidate event generation must fail closed."""


def _required_event_columns() -> list[str]:
    return [
        "Datetime",
        "Bar_Start",
        "edge_id",
        "side",
        "Event_Vol",
        "event_id",
        "candidate_event_generator",
        "Volatility_Carry_Event_Type",
        "Drift_TStat",
        "Volatility_Ratio",
        "Is_Calm_Vol",
        "event_known_after_close",
        "uses_future_information",
    ]


def _forbidden_event_columns() -> set[str]:
    return {
        "meta_label",
        "t1",
        "barrier_hit",
        "resolution_source",
        "entry_price",
        "pt_price",
        "sl_price",
        "realized_r",
        "raw_probability",
        "calibrated_probability",
        "afml_bet_size",
        "approved_signal",
        "Ticks",
        "Proxy_Value",
        "Tick_Activity_Ratio",
        "Proxy_Value_Ratio",
        "Activity_Impulse",
    }


def _normalize_feature_input(features: pd.DataFrame) -> pd.DataFrame:
    required = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close", "Bar_Volatility_Bps"]
    missing = [col for col in required if col not in features.columns]
    if missing:
        raise CandidateEventError(f"Input features missing required volatility-carry columns: {missing}")

    df = features.copy()
    df["Datetime"] = pd.to_datetime(df["Datetime"], utc=True, errors="coerce")
    df["Bar_Start"] = pd.to_datetime(df["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open",
        "High",
        "Low",
        "Close",
        "Bar_Volatility_Bps",
        "Regime_State",
        "Regime_Entropy",
        "Regime_Duration",
        "Prob_State_0",
        "Prob_State_1",
        "Prob_State_2",
        "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in df.columns]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=required).copy()
    df = df.sort_values("Datetime").reset_index(drop=True)
    if df.empty:
        raise CandidateEventError("Input features are empty after normalization.")
    return df


def add_v1_volatility_carry_features(features: pd.DataFrame) -> pd.DataFrame:
    """Add V1 Step 4 volatility-carry event fields.

    All volatility thresholds and drift statistics are shifted by one bar, so
    the current event bar never contributes to its own event gate.
    """

    out = _normalize_feature_input(features)
    open_ = out["Open"].astype("float64")
    high = out["High"].astype("float64")
    low = out["Low"].astype("float64")
    close = out["Close"].astype("float64")
    bar_vol = out["Bar_Volatility_Bps"].astype("float64")

    out["Bar_Return"] = np.log((close + EPS) / (close.shift(1) + EPS))
    out["Low_Vol_Threshold"] = (
        bar_vol.rolling(VOL_LOOKBACK, min_periods=MIN_OBS).quantile(LOW_VOL_QUANTILE).shift(1)
    )
    out["Vol_Median"] = bar_vol.rolling(VOL_LOOKBACK, min_periods=MIN_OBS).median().shift(1)
    out["Volatility_Ratio"] = bar_vol / (out["Vol_Median"] + EPS)
    out["Is_Calm_Vol"] = bar_vol <= out["Low_Vol_Threshold"]

    drift_mean = out["Bar_Return"].rolling(DRIFT_LOOKBACK, min_periods=MIN_OBS).mean().shift(1)
    drift_std = out["Bar_Return"].rolling(DRIFT_LOOKBACK, min_periods=MIN_OBS).std().shift(1)
    out["Drift_Mean"] = drift_mean
    out["Drift_Std"] = drift_std
    out["Drift_TStat"] = drift_mean / ((drift_std + EPS) / np.sqrt(float(DRIFT_LOOKBACK)))

    bar_range = (high - low).clip(lower=EPS)
    body = close - open_
    out["Body_Direction"] = np.sign(body)
    out["Body_Share"] = body.abs() / (bar_range + EPS)
    out["Close_Location"] = (close - low) / (bar_range + EPS)

    ret = np.log((close + EPS) / (close.shift(EVENT_VOL_LOOKBACK) + EPS))
    out["Event_Vol"] = ret.ewm(span=EVENT_VOL_EWM_SPAN, adjust=False).std().clip(lower=MIN_VOL)

    out["Volatility_Carry_Event_Type"] = 0
    long_event = (
        out["Is_Calm_Vol"]
        & (out["Volatility_Ratio"] <= MAX_ACTIVITY_RATIO)
        & (out["Drift_TStat"] >= DRIFT_TSTAT_THRESHOLD)
    )
    short_event = (
        out["Is_Calm_Vol"]
        & (out["Volatility_Ratio"] <= MAX_ACTIVITY_RATIO)
        & (out["Drift_TStat"] <= -DRIFT_TSTAT_THRESHOLD)
    )
    out.loc[long_event, "Volatility_Carry_Event_Type"] = 1
    out.loc[short_event, "Volatility_Carry_Event_Type"] = -1

    out.replace([np.inf, -np.inf], np.nan, inplace=True)
    return out


def _extract_v1_spaced_volatility_carry_events(
    features: pd.DataFrame,
    *,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    if min_gap_bars < 0:
        raise CandidateEventError("min_gap_bars must be >= 0")
    if "Volatility_Carry_Event_Type" not in features.columns:
        raise CandidateEventError("Feature table missing Volatility_Carry_Event_Type")

    selected_indices: list[int] = []
    last_event_i = -10**9
    event_types = pd.to_numeric(features["Volatility_Carry_Event_Type"], errors="coerce").to_numpy(dtype="float64")

    for i, event_type in enumerate(event_types):
        if not np.isfinite(event_type) or event_type == 0:
            continue
        if i - last_event_i < min_gap_bars:
            continue
        selected_indices.append(i)
        last_event_i = i

    if not selected_indices:
        return features.iloc[[]].copy()
    return features.iloc[selected_indices].copy().reset_index(drop=True)


def _validate_candidate_events(events: pd.DataFrame) -> None:
    missing = [col for col in _required_event_columns() if col not in events.columns]
    if missing:
        raise CandidateEventError(f"Candidate events missing required columns: {missing}")
    if events.empty:
        raise CandidateEventError("Candidate event generator produced zero volatilitycarry_long events.")

    forbidden_present = sorted(_forbidden_event_columns().intersection(events.columns))
    if forbidden_present:
        raise CandidateEventError(f"Candidate events contain forbidden research/live-decision or volume-proxy columns: {forbidden_present}")
    if not (events["edge_id"] == EDGE_ID).all():
        raise CandidateEventError("Candidate events contain unexpected edge_id values.")
    sides = pd.to_numeric(events["side"], errors="coerce")
    if not sides.isin([-1, 1]).all():
        raise CandidateEventError("Volatility-carry raw candidate sides must be +/-1 from Volatility_Carry_Event_Type.")
    if not (events["candidate_event_generator"] == CANDIDATE_EVENT_GENERATOR).all():
        raise CandidateEventError("Candidate events contain unexpected generator values.")
    event_types = pd.to_numeric(events["Volatility_Carry_Event_Type"], errors="coerce")
    if not event_types.isin([-1, 1]).all():
        raise CandidateEventError("Volatility_Carry_Event_Type must be -1 or +1.")
    if not events["Is_Calm_Vol"].astype(bool).all():
        raise CandidateEventError("Volatility-carry candidate events must satisfy Is_Calm_Vol=True.")
    if (pd.to_numeric(events["Volatility_Ratio"], errors="coerce") > MAX_ACTIVITY_RATIO).any():
        raise CandidateEventError("Volatility-carry candidate events exceed MAX_ACTIVITY_RATIO.")
    if events["uses_future_information"].astype(bool).any():
        raise CandidateEventError("Candidate events must not use future information.")
    if not events["event_known_after_close"].astype(bool).all():
        raise CandidateEventError("Candidate events must be known after bar close.")
    if not np.isfinite(pd.to_numeric(events["Event_Vol"], errors="coerce").to_numpy(dtype="float64")).all():
        raise CandidateEventError("Candidate events contain non-finite Event_Vol values.")


def generate_v1_volatilitycarry_long_candidate_events(
    features: pd.DataFrame,
    *,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    """Generate V1 Step 4 price-only calm-volatility carry events.

    This returns raw +/- volatility-carry events with
    side=Volatility_Carry_Event_Type. primary_side.py performs V2 long-only
    filtering.
    """

    expanded = add_v1_volatility_carry_features(features)
    spaced = _extract_v1_spaced_volatility_carry_events(expanded, min_gap_bars=min_gap_bars)
    if spaced.empty:
        spaced = pd.DataFrame(columns=["Datetime", "Bar_Start", *EVENT_CONTEXT_COLUMNS])

    keep_cols = [
        "Datetime", "Bar_Start", "Open", "High", "Low", "Close",
        *[col for col in EVENT_CONTEXT_COLUMNS if col in spaced.columns],
    ]
    events = spaced[[col for col in keep_cols if col in spaced.columns]].copy()

    events["edge_id"] = EDGE_ID
    events["side"] = pd.to_numeric(events["Volatility_Carry_Event_Type"], errors="coerce").astype("int64")
    events["event_id"] = events["Datetime"].apply(
        lambda ts: f"{EDGE_ID}|{pd.Timestamp(ts).isoformat()}|volatility_carry"
    )
    events["candidate_event_generator"] = CANDIDATE_EVENT_GENERATOR
    events["event_known_after_close"] = True
    events["uses_future_information"] = False
    events["vol_lookback"] = int(VOL_LOOKBACK)
    events["low_vol_quantile"] = float(LOW_VOL_QUANTILE)
    events["drift_lookback"] = int(DRIFT_LOOKBACK)
    events["drift_tstat_threshold"] = float(DRIFT_TSTAT_THRESHOLD)
    events["max_activity_ratio"] = float(MAX_ACTIVITY_RATIO)
    events["min_gap_bars"] = int(min_gap_bars)
    events["event_vol_lookback"] = int(EVENT_VOL_LOOKBACK)
    events["event_vol_ewm_span"] = int(EVENT_VOL_EWM_SPAN)

    events["Datetime"] = pd.to_datetime(events["Datetime"], utc=True, errors="coerce")
    events["Bar_Start"] = pd.to_datetime(events["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open", "High", "Low", "Close", "side", "Event_Vol", "Bar_Return", "Bar_Volatility_Bps",
        "Low_Vol_Threshold", "Vol_Median", "Volatility_Ratio", "Drift_Mean", "Drift_Std", "Drift_TStat",
        "Volatility_Carry_Event_Type", "Body_Direction", "Body_Share", "Close_Location",
        "Regime_State", "Regime_Entropy", "Regime_Duration",
        "Prob_State_0", "Prob_State_1", "Prob_State_2", "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in events.columns]:
        events[col] = pd.to_numeric(events[col], errors="coerce")
    events = events.dropna(
        subset=["Datetime", "Bar_Start", "Event_Vol", "Volatility_Carry_Event_Type", "Drift_TStat", "Volatility_Ratio", "Is_Calm_Vol"]
    ).copy()
    events = events[events["side"].isin([-1, 1])].copy()
    events = events.sort_values("Datetime").reset_index(drop=True)

    ordered_cols = [
        "Datetime", "Bar_Start", "edge_id", "side", "Event_Vol", "event_id", "candidate_event_generator",
        "Volatility_Carry_Event_Type", "Drift_TStat", "Volatility_Ratio", "Is_Calm_Vol", "Bar_Volatility_Bps",
        "Low_Vol_Threshold", "Vol_Median", "Drift_Mean", "Drift_Std", "Bar_Return",
        "Body_Direction", "Body_Share", "Close_Location",
        "event_known_after_close", "uses_future_information",
        *[col for col in events.columns if col not in _required_event_columns() and col not in {
            "Bar_Volatility_Bps", "Low_Vol_Threshold", "Vol_Median", "Drift_Mean", "Drift_Std", "Bar_Return",
            "Body_Direction", "Body_Share", "Close_Location"
        }],
    ]
    events = events[[col for col in ordered_cols if col in events.columns]].copy()

    _validate_candidate_events(events)
    return events


def validate_candidate_events(events: pd.DataFrame) -> None:
    _validate_candidate_events(events)


def candidate_event_contract() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "candidate_event_generator": CANDIDATE_EVENT_GENERATOR,
        "event_logic": "calm volatility regime + past-only drift t-stat direction",
        "vol_lookback": VOL_LOOKBACK,
        "low_vol_quantile": LOW_VOL_QUANTILE,
        "drift_lookback": DRIFT_LOOKBACK,
        "drift_tstat_threshold": DRIFT_TSTAT_THRESHOLD,
        "max_activity_ratio": MAX_ACTIVITY_RATIO,
        "min_gap_bars": MIN_GAP_BARS,
        "event_vol_lookback": EVENT_VOL_LOOKBACK,
        "event_vol_ewm_span": EVENT_VOL_EWM_SPAN,
        "side_rule_raw": "side = Volatility_Carry_Event_Type; primary_side.py filters +1 for volatilitycarry_long",
        "price_only_event_gate": True,
        "forbidden_volume_proxy_inputs": ["Ticks", "Proxy_Value", "Tick_Activity_Ratio", "Proxy_Value_Ratio", "Activity_Impulse"],
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
        "v1_reference": "NASDAQ/volatility-carry-independent-edge/4_volatility_carry_event_sampling.py",
    }


if __name__ == "__main__":
    print("✅ NASDAQ/volatilitycarry_long candidate_events.py import/self-contract check passed.")
    print(candidate_event_contract())
