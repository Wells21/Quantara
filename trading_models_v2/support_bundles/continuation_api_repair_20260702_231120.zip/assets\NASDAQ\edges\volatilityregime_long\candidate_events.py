"""
Candidate event generation for NASDAQ/volatilityregime_long.

V1 source:
- NASDAQ/volatility-regime-independent-edge/4_volatility_regime_event_sampling.py

Core V1 idea:
- Detect compression-to-expansion volatility-regime events.
- The Step 4 event itself is not directional.
- Direction is assigned in primary_side.py from the expansion candle structure.

V2 side-specialization:
- This module emits raw Vol_Regime_Event=1 events with side pending.
- primary_side.py filters this edge to bullish expansion candles -> side=+1 long.
- Volatility-regime fields are event/control/context fields, not generic model-schema features.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

EDGE_ID = "NASDAQ/volatilityregime_long"
SIDE_VALUE = 1
CANDIDATE_EVENT_GENERATOR = "volatilityregime_long_v1_compression_expansion_candidate_events"

MIN_GAP_BARS = 5
LOW_VOL_QUANTILE = 0.55
EXPANSION_MULTIPLIER = 1.10
VOL_LOOKBACK = 50
RECENT_LOW_VOL_LOOKBACK = 20
EVENT_VOL_LOOKBACK = 50
EVENT_VOL_EWM_SPAN = 100
MIN_VOL = 1e-8
EPS = 1e-12
VOL_QUANTILE_COLUMN = f"Vol_Q{int(LOW_VOL_QUANTILE * 100)}_{VOL_LOOKBACK}"

EVENT_CONTEXT_COLUMNS = [
    "Event_Vol",
    "Bar_Volatility_Bps",
    "Vol_Median_50",
    "Vol_Q55_50",
    "Recent_Vol_Mean",
    "Current_Vol_Ratio",
    "Was_Compressed",
    "Vol_Expansion",
    "Vol_Regime_Event",
    "Expansion_Range_ATR",
    "Body_Direction",
    "Body_Share",
    "Close_Location",
    "Regime_State",
    "Regime_Entropy",
    "Regime_Duration",
    "Prob_State_0",
    "Prob_State_1",
    "Prob_State_2",
    "Prob_State_3",
]


class CandidateEventError(RuntimeError):
    """Raised when candidate event generation must fail closed."""


def _required_event_columns() -> list[str]:
    return [
        "Datetime",
        "Bar_Start",
        "edge_id",
        "side",
        "Event_Vol",
        "event_id",
        "candidate_event_generator",
        "Vol_Regime_Event",
        "Was_Compressed",
        "Vol_Expansion",
        "Current_Vol_Ratio",
        "Body_Direction",
        "Body_Share",
        "Close_Location",
        "event_known_after_close",
        "uses_future_information",
    ]


def _forbidden_event_columns() -> set[str]:
    return {
        "meta_label",
        "t1",
        "barrier_hit",
        "resolution_source",
        "entry_price",
        "pt_price",
        "sl_price",
        "realized_r",
        "raw_probability",
        "calibrated_probability",
        "afml_bet_size",
        "approved_signal",
        "Ticks",
        "Proxy_Value",
        "Tick_Activity_Ratio",
        "Proxy_Value_Ratio",
        "Activity_Impulse",
    }


def _normalize_feature_input(features: pd.DataFrame) -> pd.DataFrame:
    required = ["Datetime", "Bar_Start", "Open", "High", "Low", "Close", "Bar_Volatility_Bps", "ATR_14", "NATR"]
    missing = [col for col in required if col not in features.columns]
    if missing:
        raise CandidateEventError(f"Input features missing required volatility-regime columns: {missing}")

    df = features.copy()
    df["Datetime"] = pd.to_datetime(df["Datetime"], utc=True, errors="coerce")
    df["Bar_Start"] = pd.to_datetime(df["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open",
        "High",
        "Low",
        "Close",
        "Bar_Volatility_Bps",
        "ATR_14",
        "NATR",
        "Regime_State",
        "Regime_Entropy",
        "Regime_Duration",
        "Prob_State_0",
        "Prob_State_1",
        "Prob_State_2",
        "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in df.columns]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=required).copy()
    df = df.sort_values("Datetime").reset_index(drop=True)
    if df.empty:
        raise CandidateEventError("Input features are empty after normalization.")
    return df


def add_v1_volatility_regime_features(features: pd.DataFrame) -> pd.DataFrame:
    """Add V1 Step 4 volatility-regime event fields.

    Rolling baselines are shifted by one bar, matching V1 and preventing the
    event bar from entering its own compression/expansion baseline.
    """

    out = _normalize_feature_input(features)
    open_ = out["Open"].astype("float64")
    high = out["High"].astype("float64")
    low = out["Low"].astype("float64")
    close = out["Close"].astype("float64")
    bar_vol = out["Bar_Volatility_Bps"].astype("float64")

    out["Vol_Median_50"] = bar_vol.rolling(VOL_LOOKBACK).median().shift(1)
    out[VOL_QUANTILE_COLUMN] = bar_vol.rolling(VOL_LOOKBACK).quantile(LOW_VOL_QUANTILE).shift(1)
    if VOL_QUANTILE_COLUMN != "Vol_Q55_50":
        out["Vol_Q55_50"] = out[VOL_QUANTILE_COLUMN]

    out["Recent_Vol_Mean"] = bar_vol.rolling(RECENT_LOW_VOL_LOOKBACK).mean().shift(1)
    out["Current_Vol_Ratio"] = bar_vol / (out["Recent_Vol_Mean"] + EPS)
    out["Was_Compressed"] = (out["Recent_Vol_Mean"] <= (out[VOL_QUANTILE_COLUMN] * EXPANSION_MULTIPLIER)).astype("int64")
    out["Vol_Expansion"] = (out["Current_Vol_Ratio"] >= EXPANSION_MULTIPLIER).astype("int64")

    bar_range = (high - low).clip(lower=EPS)
    body = close - open_
    out["Body_Direction"] = np.sign(body)
    out["Body_Share"] = body.abs() / (bar_range + EPS)
    out["Close_Location"] = (close - low) / (bar_range + EPS)
    out["Expansion_Range_ATR"] = bar_range / (out["ATR_14"].astype("float64") + EPS)

    ret = np.log((close + EPS) / (close.shift(EVENT_VOL_LOOKBACK) + EPS))
    out["Event_Vol"] = ret.ewm(span=EVENT_VOL_EWM_SPAN, adjust=False).std().clip(lower=MIN_VOL)

    out["Vol_Regime_Event"] = ((out["Was_Compressed"] == 1) & (out["Vol_Expansion"] == 1)).astype("int64")
    out.replace([np.inf, -np.inf], np.nan, inplace=True)
    return out


def _extract_v1_spaced_volatility_regime_events(
    features: pd.DataFrame,
    *,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    if min_gap_bars < 0:
        raise CandidateEventError("min_gap_bars must be >= 0")
    if "Vol_Regime_Event" not in features.columns:
        raise CandidateEventError("Feature table missing Vol_Regime_Event")

    selected_indices: list[int] = []
    last_event_i = -10**9
    event_flags = pd.to_numeric(features["Vol_Regime_Event"], errors="coerce").to_numpy(dtype="float64")

    for i, event_flag in enumerate(event_flags):
        if not np.isfinite(event_flag) or int(event_flag) != 1:
            continue
        if i - last_event_i < min_gap_bars:
            continue
        selected_indices.append(i)
        last_event_i = i

    if not selected_indices:
        return features.iloc[[]].copy()
    return features.iloc[selected_indices].copy().reset_index(drop=True)


def _validate_candidate_events(events: pd.DataFrame) -> None:
    missing = [col for col in _required_event_columns() if col not in events.columns]
    if missing:
        raise CandidateEventError(f"Candidate events missing required columns: {missing}")
    if events.empty:
        raise CandidateEventError("Candidate event generator produced zero volatilityregime_long events.")

    forbidden_present = sorted(_forbidden_event_columns().intersection(events.columns))
    if forbidden_present:
        raise CandidateEventError(f"Candidate events contain forbidden research/live-decision or volume-proxy columns: {forbidden_present}")
    if not (events["edge_id"] == EDGE_ID).all():
        raise CandidateEventError("Candidate events contain unexpected edge_id values.")
    if not (pd.to_numeric(events["side"], errors="coerce") == 0).all():
        raise CandidateEventError("Raw volatility-regime candidate events must keep side=0 until primary_side.py assigns direction.")
    if not (events["candidate_event_generator"] == CANDIDATE_EVENT_GENERATOR).all():
        raise CandidateEventError("Candidate events contain unexpected generator values.")
    if not (pd.to_numeric(events["Vol_Regime_Event"], errors="coerce") == 1).all():
        raise CandidateEventError("Volatility-regime candidate events must have Vol_Regime_Event=1.")
    if not (pd.to_numeric(events["Was_Compressed"], errors="coerce") == 1).all():
        raise CandidateEventError("Volatility-regime candidate events must have Was_Compressed=1.")
    if not (pd.to_numeric(events["Vol_Expansion"], errors="coerce") == 1).all():
        raise CandidateEventError("Volatility-regime candidate events must have Vol_Expansion=1.")
    if events["uses_future_information"].astype(bool).any():
        raise CandidateEventError("Candidate events must not use future information.")
    if not events["event_known_after_close"].astype(bool).all():
        raise CandidateEventError("Candidate events must be known after bar close.")
    if not np.isfinite(pd.to_numeric(events["Event_Vol"], errors="coerce").to_numpy(dtype="float64")).all():
        raise CandidateEventError("Candidate events contain non-finite Event_Vol values.")


def generate_v1_volatilityregime_long_candidate_events(
    features: pd.DataFrame,
    *,
    min_gap_bars: int = MIN_GAP_BARS,
) -> pd.DataFrame:
    """Generate V1 Step 4 compression-to-expansion volatility-regime events.

    These events are intentionally non-directional. primary_side.py assigns the
    V2 long side from bullish expansion candle structure.
    """

    expanded = add_v1_volatility_regime_features(features)
    spaced = _extract_v1_spaced_volatility_regime_events(expanded, min_gap_bars=min_gap_bars)
    if spaced.empty:
        spaced = pd.DataFrame(columns=["Datetime", "Bar_Start", *EVENT_CONTEXT_COLUMNS])

    keep_cols = [
        "Datetime", "Bar_Start", "Open", "High", "Low", "Close",
        *[col for col in EVENT_CONTEXT_COLUMNS if col in spaced.columns],
    ]
    events = spaced[[col for col in keep_cols if col in spaced.columns]].copy()

    events["edge_id"] = EDGE_ID
    events["side"] = 0
    events["event_id"] = events["Datetime"].apply(
        lambda ts: f"{EDGE_ID}|{pd.Timestamp(ts).isoformat()}|volatility_regime"
    )
    events["candidate_event_generator"] = CANDIDATE_EVENT_GENERATOR
    events["event_known_after_close"] = True
    events["uses_future_information"] = False
    events["low_vol_quantile"] = float(LOW_VOL_QUANTILE)
    events["expansion_multiplier"] = float(EXPANSION_MULTIPLIER)
    events["vol_lookback"] = int(VOL_LOOKBACK)
    events["recent_low_vol_lookback"] = int(RECENT_LOW_VOL_LOOKBACK)
    events["min_gap_bars"] = int(min_gap_bars)
    events["event_vol_lookback"] = int(EVENT_VOL_LOOKBACK)
    events["event_vol_ewm_span"] = int(EVENT_VOL_EWM_SPAN)

    events["Datetime"] = pd.to_datetime(events["Datetime"], utc=True, errors="coerce")
    events["Bar_Start"] = pd.to_datetime(events["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "Open", "High", "Low", "Close", "side", "Event_Vol", "Bar_Volatility_Bps", "Vol_Median_50",
        "Vol_Q55_50", "Recent_Vol_Mean", "Current_Vol_Ratio", "Was_Compressed", "Vol_Expansion",
        "Vol_Regime_Event", "Expansion_Range_ATR", "Body_Direction", "Body_Share", "Close_Location",
        "Regime_State", "Regime_Entropy", "Regime_Duration", "Prob_State_0", "Prob_State_1", "Prob_State_2", "Prob_State_3",
    ]
    for col in [c for c in numeric_cols if c in events.columns]:
        events[col] = pd.to_numeric(events[col], errors="coerce")
    events = events.dropna(
        subset=["Datetime", "Bar_Start", "Event_Vol", "Vol_Regime_Event", "Was_Compressed", "Vol_Expansion", "Current_Vol_Ratio"]
    ).copy()
    events = events.sort_values("Datetime").reset_index(drop=True)

    ordered_cols = [
        "Datetime", "Bar_Start", "edge_id", "side", "Event_Vol", "event_id", "candidate_event_generator",
        "Vol_Regime_Event", "Was_Compressed", "Vol_Expansion", "Current_Vol_Ratio", "Bar_Volatility_Bps",
        "Vol_Median_50", "Vol_Q55_50", "Recent_Vol_Mean", "Expansion_Range_ATR",
        "Body_Direction", "Body_Share", "Close_Location",
        "event_known_after_close", "uses_future_information",
        *[col for col in events.columns if col not in _required_event_columns() and col not in {
            "Bar_Volatility_Bps", "Vol_Median_50", "Vol_Q55_50", "Recent_Vol_Mean", "Expansion_Range_ATR",
            "Body_Direction", "Body_Share", "Close_Location"
        }],
    ]
    events = events[[col for col in ordered_cols if col in events.columns]].copy()

    _validate_candidate_events(events)
    return events


def validate_candidate_events(events: pd.DataFrame) -> None:
    _validate_candidate_events(events)


def candidate_event_contract() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "candidate_event_generator": CANDIDATE_EVENT_GENERATOR,
        "event_logic": "past-only volatility compression followed by current volatility expansion",
        "low_vol_quantile": LOW_VOL_QUANTILE,
        "expansion_multiplier": EXPANSION_MULTIPLIER,
        "vol_lookback": VOL_LOOKBACK,
        "recent_low_vol_lookback": RECENT_LOW_VOL_LOOKBACK,
        "min_gap_bars": MIN_GAP_BARS,
        "event_vol_lookback": EVENT_VOL_LOOKBACK,
        "event_vol_ewm_span": EVENT_VOL_EWM_SPAN,
        "side_rule_raw": "side remains 0 until primary_side.py maps bullish expansion candle to +1 long",
        "price_only_event_gate": True,
        "forbidden_volume_proxy_inputs": ["Ticks", "Proxy_Value", "Tick_Activity_Ratio", "Proxy_Value_Ratio", "Activity_Impulse"],
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
        "v1_reference": "NASDAQ/volatility-regime-independent-edge/4_volatility_regime_event_sampling.py",
    }


if __name__ == "__main__":
    print("✅ NASDAQ/volatilityregime_long candidate_events.py import/self-contract check passed.")
    print(candidate_event_contract())
