# NASDAQ/trend_long Feature Notes

This file records edge-local feature and candidate-event decisions for the `NASDAQ/trend_long` pilot edge.

Global feature rules live in:

```text
docs/FEATURE_STRATEGY_POLICY.md
```

---

## Current feature/event stage

Current stage:

```text
Tier 1 feature schema declared
build_features() implemented with pandas_ta_classic + V1 helper logic
generate_candidate_events() implemented with V1 Step 4 positive CUSUM logic
edge not deployable
```

The current schemas are:

```text
contracts/feature_schema.json
contracts/event_schema.json
```

They declare Tier 1 live-safe candidate features and long-side candidate event sampling.

---

## Why Tier 1 only for now

V1 had a strong NASDAQ trend feature factory with broad price-only features, FFD context, and HMM/regime context.

For V2, we are not blindly copying all V1 features.

The first `trend_long` feature schema includes only features that can be reproduced live from verified asset-level closed standard_quote_tick OHLC bars.

This avoids repeating the V1 live feature mismatch problem.

---

## Implementation choice

Standard technical indicators should follow the V1 dependency style.

The V2 `build_features()` implementation uses:

```text
pandas_ta_classic
```

for standard indicators where V1 used TA functions, including:

```text
EMA
RSI
MACD
Stochastic
Williams %R
ROC
ATR
Bollinger Bands
Donchian channels
```

V1-style custom helper logic is retained only where V1 itself used custom helper logic, such as:

```text
safe_log_ratio
shifted_zscore
rolling_slope
rolling_r2
efficiency_ratio
```

This preserves useful V1 logic while keeping the V2 runtime contract intact.

---

## Candidate event implementation

`generate_candidate_events()` delegates to:

```text
assets/NASDAQ/edges/trend_long/candidate_events.py
```

Current event logic ports V1 Step 4 trend event sampling:

```text
Event_Vol = EWM_STD(log(Close[t] / Close[t-50]), span=100)
threshold h[t] = 0.3 * Event_Vol[t]
symmetric CUSUM over 1-bar log close differences
```

Because this is the side-specialized `trend_long` edge:

```text
positive CUSUM triggers are emitted
side is fixed to +1
negative CUSUM triggers reset negative state but are not emitted
```

No labels, `t1`, barrier outcomes, probabilities, AFML sizing, or approved signals are produced at this stage.

---

## Deferred V1 trend-side context

V1 Step 5A used `Close_FFD` as the core trend direction and had optional Kalman/return/regime confirmations.

In V2, this is deferred until shared runtime modules exist for:

```text
FFD context
Kalman context, if selected later
HMM/regime context
```

Reason:

```text
These must reproduce research/live outputs exactly before they can become live_available or allowed_for_model_input.
```

Do not replace V1 FFD trend core with ad-hoc dashboard logic or unrelated EMA rules.

---

## Included feature groups

The current Tier 1 schema includes candidate features from these groups:

```text
core_returns_price_action
smoothed_references
momentum_oscillators
price_volatility_range
compression_expansion
trend_efficiency
breakout_channel_bands
smc_reversal_exhaustion
```

These are broad candidates for later event-level modeling and iterative feature surgery.

They are not final selected model features.

---

## Deferred feature groups

The following V1-inspired groups are intentionally deferred:

```text
ffd_context
regime_context
```

They must not enter `selected_features.json` until research/live replay proves exact reproducibility.

---

## 1RR trend-long relevance

The feature schema is designed to help a future meta-model filter whether a primary long event is likely to reach +1R before -1R.

The candidate groups are intended to capture:

```text
trend quality
momentum continuation
range expansion/compression
volatility regime from price only
bad exhaustion entries
wick rejection
channel/breakout position
short-term reversal danger
```

Iterative feature surgery will later decide which features actually contribute.

---

## Non-negotiable boundary

Feature engineering for this edge must happen in:

```text
assets/NASDAQ/edges/trend_long/runtime.py::build_features
```

Candidate event generation for this edge must happen through:

```text
assets/NASDAQ/edges/trend_long/runtime.py::generate_candidate_events
```

Do not patch the dashboard to create missing features or events.

If a selected feature/event input is missing live, fix this edge runtime and schema.
