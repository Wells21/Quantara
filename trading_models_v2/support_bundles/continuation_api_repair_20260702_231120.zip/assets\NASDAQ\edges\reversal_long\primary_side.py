"""
Primary-side logic for NASDAQ/reversal_long.

V1 source:
- NASDAQ/mean_reversion-independent-deep-reversal/5a_deep_reversal_primary_side_engine.py

Core V1 mapping:
- Deviation_Side = -1 means oversold stretch -> side +1 long.
- Deviation_Side = +1 means overbought stretch -> side -1 short.

V2 side-specialization:
- reversal_long accepts Deviation_Side=-1 only.
- Rejection/regime/entropy/vol flags are preserved as live-safe context fields.
- These flags are not hard filters unless explicitly redesigned later.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

_THIS_FILE = Path(__file__).resolve()
_EDGE_ROOT = _THIS_FILE.parent
_V2_ROOT = _THIS_FILE.parents[4]
_REPO_ROOT = _THIS_FILE.parents[5]
for _path in (_EDGE_ROOT, _V2_ROOT, _REPO_ROOT):
    path_str = str(_path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from shared.ffd.verify_asset_ffd_manifest import verify_asset_ffd_manifest  # noqa: E402

EDGE_ID = "NASDAQ/reversal_long"
ASSET = "NASDAQ"
SIDE_VALUE = 1
DEVIATION_SIDE = -1
LIVE_BUFFER_BARS = 120

MIN_WICK_TO_BODY = 0.80
MIN_WICK_SHARE_OF_RANGE = 0.25
USE_REGIME_FILTER = False
DISALLOWED_REGIME_STATES = {3}
USE_ENTROPY_FILTER = False
MAX_REGIME_ENTROPY = 1.25
USE_VOL_FILTER = False
MIN_EVENT_NORM_RANGE = 0.30
EPS = 1e-12

FORBIDDEN_PRIMARY_SIDE_COLUMNS = {
    "meta_label",
    "t1",
    "barrier_hit",
    "resolution_source",
    "entry_price",
    "pt_price",
    "sl_price",
    "realized_r",
    "raw_probability",
    "calibrated_probability",
    "afml_bet_size",
    "approved_signal",
}


class PrimarySideError(RuntimeError):
    """Raised when primary-side generation must fail closed."""


def load_verified_ffd_features(asset: str = ASSET) -> pd.DataFrame:
    verification = verify_asset_ffd_manifest(asset)
    path = _V2_ROOT / verification["features"]
    if not path.exists():
        raise PrimarySideError(f"Verified FFD features path does not exist: {path}")

    ffd = pd.read_csv(path)
    required = ["Datetime", "Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]
    missing = [col for col in required if col not in ffd.columns]
    if missing:
        raise PrimarySideError(f"FFD features missing required columns: {missing}")

    ffd["Datetime"] = pd.to_datetime(ffd["Datetime"], utc=True, errors="coerce")
    for col in ["Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]:
        ffd[col] = pd.to_numeric(ffd[col], errors="coerce")
    ffd = ffd.dropna(subset=required).copy()
    ffd = ffd.sort_values("Datetime").reset_index(drop=True)
    if ffd.empty:
        raise PrimarySideError("Verified FFD features are empty after normalization.")
    return ffd


def add_v1_deep_reversal_rejection_context(df: pd.DataFrame) -> pd.DataFrame:
    """Add V1 Step 5A rejection/context fields without filtering events."""

    out = df.copy()
    required = ["Open", "High", "Low", "Close", "Deviation_Side", "Event_Vol"]
    missing = [col for col in required if col not in out.columns]
    if missing:
        raise PrimarySideError(f"Cannot compute rejection context; missing columns: {missing}")

    for col in ["Open", "High", "Low", "Close", "Deviation_Side", "Event_Vol"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")

    body = (out["Close"] - out["Open"]).abs()
    upper_wick = out["High"] - np.maximum(out["Close"], out["Open"])
    lower_wick = np.minimum(out["Close"], out["Open"]) - out["Low"]
    bar_range = (out["High"] - out["Low"]).clip(lower=EPS)

    out["Body"] = body
    out["Upper_Wick"] = upper_wick.clip(lower=0)
    out["Lower_Wick"] = lower_wick.clip(lower=0)
    out["Bar_Range"] = bar_range
    out["Upper_Wick_to_Body"] = out["Upper_Wick"] / (body + EPS)
    out["Lower_Wick_to_Body"] = out["Lower_Wick"] / (body + EPS)
    out["Upper_Wick_Share"] = out["Upper_Wick"] / (bar_range + EPS)
    out["Lower_Wick_Share"] = out["Lower_Wick"] / (bar_range + EPS)
    out["Prev_Upper_Wick_to_Body"] = out["Upper_Wick_to_Body"].shift(1)
    out["Prev_Lower_Wick_to_Body"] = out["Lower_Wick_to_Body"].shift(1)
    out["Prev_Upper_Wick_Share"] = out["Upper_Wick_Share"].shift(1)
    out["Prev_Lower_Wick_Share"] = out["Lower_Wick_Share"].shift(1)

    event_norm_range = out["Bar_Range"] / (out["Close"] * out["Event_Vol"].clip(lower=1e-8) + EPS)
    out["Event_Norm_Range"] = event_norm_range

    long_reject_now = (
        (out["Lower_Wick_to_Body"] >= MIN_WICK_TO_BODY)
        & (out["Lower_Wick_Share"] >= MIN_WICK_SHARE_OF_RANGE)
    )
    long_reject_prev = (
        (out["Prev_Lower_Wick_to_Body"] >= MIN_WICK_TO_BODY)
        & (out["Prev_Lower_Wick_Share"] >= MIN_WICK_SHARE_OF_RANGE)
    )
    short_reject_now = (
        (out["Upper_Wick_to_Body"] >= MIN_WICK_TO_BODY)
        & (out["Upper_Wick_Share"] >= MIN_WICK_SHARE_OF_RANGE)
    )
    short_reject_prev = (
        (out["Prev_Upper_Wick_to_Body"] >= MIN_WICK_TO_BODY)
        & (out["Prev_Upper_Wick_Share"] >= MIN_WICK_SHARE_OF_RANGE)
    )

    out["long_reject"] = (long_reject_now | long_reject_prev).astype("int64")
    out["short_reject"] = (short_reject_now | short_reject_prev).astype("int64")

    out["regime_ok"] = 1
    if USE_REGIME_FILTER and "Regime_State" in out.columns:
        out["regime_ok"] = (~out["Regime_State"].isin(DISALLOWED_REGIME_STATES)).astype("int64")

    out["entropy_ok"] = 1
    if USE_ENTROPY_FILTER and "Regime_Entropy" in out.columns:
        out["entropy_ok"] = (pd.to_numeric(out["Regime_Entropy"], errors="coerce") <= MAX_REGIME_ENTROPY).astype("int64")

    out["vol_ok"] = 1
    if USE_VOL_FILTER:
        out["vol_ok"] = (event_norm_range >= MIN_EVENT_NORM_RANGE).astype("int64")

    out.replace([np.inf, -np.inf], np.nan, inplace=True)
    return out


def _validate_primary_side_input(events: pd.DataFrame) -> pd.DataFrame:
    required = ["Datetime", "edge_id", "side", "Deviation_Side", "Deviation_Z", "Event_Vol"]
    missing = [col for col in required if col not in events.columns]
    if missing:
        raise PrimarySideError(f"Primary-side input missing required columns: {missing}")

    forbidden_present = sorted(FORBIDDEN_PRIMARY_SIDE_COLUMNS.intersection(events.columns))
    if forbidden_present:
        raise PrimarySideError(f"Primary-side input contains forbidden research/live-decision columns: {forbidden_present}")

    out = events.copy()
    out["Datetime"] = pd.to_datetime(out["Datetime"], utc=True, errors="coerce")
    if "Bar_Start" in out.columns:
        out["Bar_Start"] = pd.to_datetime(out["Bar_Start"], utc=True, errors="coerce")
    for col in ["side", "Deviation_Side", "Deviation_Z", "Event_Vol"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=["Datetime", "side", "Deviation_Side", "Deviation_Z", "Event_Vol"]).copy()
    if out.empty:
        raise PrimarySideError("Primary-side input is empty after normalization.")
    if not (out["edge_id"] == EDGE_ID).all():
        bad = out.loc[out["edge_id"] != EDGE_ID, "edge_id"].unique().tolist()
        raise PrimarySideError(f"reversal_long primary side received wrong edge_id values: {bad}")
    return out.sort_values("Datetime").reset_index(drop=True)


def assign_reversal_long_primary_side(events: pd.DataFrame) -> pd.DataFrame:
    out = _validate_primary_side_input(events)
    out = add_v1_deep_reversal_rejection_context(out)
    out["primary_side_rule"] = "Deviation_Side=-1 -> side=+1 long"
    out["primary_side"] = np.where(out["Deviation_Side"] == DEVIATION_SIDE, SIDE_VALUE, 0).astype("int64")
    out["primary_side_filter"] = (out["primary_side"] == SIDE_VALUE).astype("int64")
    out = out[out["primary_side_filter"] == 1].copy()

    if out.empty:
        raise PrimarySideError("No reversal_long events survived primary-side mapping.")
    if not (pd.to_numeric(out["Deviation_Side"], errors="coerce") == DEVIATION_SIDE).all():
        raise PrimarySideError("reversal_long primary side must only accept Deviation_Side=-1.")
    if not (out["primary_side"] == SIDE_VALUE).all():
        raise PrimarySideError("reversal_long primary_side must be +1 only.")

    out["side"] = SIDE_VALUE
    return out.sort_values("Datetime").reset_index(drop=True)


def filter_long_events_with_primary_side(events: pd.DataFrame, features: pd.DataFrame | None = None) -> pd.DataFrame:
    return assign_reversal_long_primary_side(events)


def validate_primary_side_events(events: pd.DataFrame) -> None:
    out = assign_reversal_long_primary_side(events)
    if out.empty:
        raise PrimarySideError("Validated reversal_long primary-side output is empty.")


def primary_side_config() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "side_value": SIDE_VALUE,
        "deviation_side": DEVIATION_SIDE,
        "side_rule": "Deviation_Side=-1 -> side=+1 long",
        "rejection_context_fields": ["long_reject", "short_reject", "regime_ok", "entropy_ok", "vol_ok"],
        "rejection_flags_are_hard_filters": False,
        "uses_verified_shared_ffd": True,
        "live_buffer_bars": LIVE_BUFFER_BARS,
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
        "v1_reference": "NASDAQ/mean_reversion-independent-deep-reversal/5a_deep_reversal_primary_side_engine.py",
    }


if __name__ == "__main__":
    print("✅ NASDAQ/reversal_long primary_side.py import/self-contract check passed.")
    print(primary_side_config())
