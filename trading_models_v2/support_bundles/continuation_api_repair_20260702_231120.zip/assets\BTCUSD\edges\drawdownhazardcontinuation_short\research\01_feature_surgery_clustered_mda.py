"""
01_feature_surgery_clustered_mda.py

V2 Step 01: V1-style iterative clustered feature surgery for the current edge package.

Blueprint boundary
------------------
This script is allowed to SELECT features from the exported V2 model rows.
It is NOT allowed to engineer new model-input features.

Two supported run modes
-----------------------
1) Repo mode, from trading_models_v2:

    python ./assets/<ASSET>/edges/<FAMILY>_<SIDE>/research/01_feature_surgery_clustered_mda.py

2) Flat Colab mode, from /content:

    Upload these three files directly into /content:
        01_feature_surgery_clustered_mda.py
        <edge_stem>_model_rows.csv
        feature_schema.json

    Then run:
        !python /content/01_feature_surgery_clustered_mda.py

    Output files will be written directly into /content for easy download.

This ports the useful V1 Step 6C logic while enforcing V2 contracts:
    - feature_schema.json is the model-input authority
    - no Colab/manual feature engineering
    - manual t1 overlap purge
    - manual embargo
    - MLDP sample weights = class_weight * Event_Vol * average_uniqueness
    - train-fold-only F1 threshold selection
    - clustered MDA removes one negative-MDA cluster at a time

Side-specialized note
---------------------
Each V2 edge has a fixed side derived from the edge folder or flat filename. The
model should learn whether to accept a side-specialized candidate, not trade
direction. Therefore `side` is treated as metadata unless feature_schema.json
explicitly requires otherwise; this Step 01 does not force it as a fixed model
feature.
"""

from __future__ import annotations

import json
import math
import os
import sys
import warnings
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import scipy.cluster.hierarchy as sch
import scipy.stats as stats
import xgboost as xgb
from scipy.spatial.distance import squareform
from sklearn.metrics import f1_score, precision_score, recall_score
from sklearn.utils.class_weight import compute_sample_weight

try:
    from skfolio.model_selection import CombinatorialPurgedCV
except Exception as exc:  # pragma: no cover
    CombinatorialPurgedCV = None
    SKFOLIO_IMPORT_ERROR = exc
else:
    SKFOLIO_IMPORT_ERROR = None

warnings.filterwarnings("ignore")

RNG = np.random.default_rng(42)

# =============================================================================
# CONFIG
# =============================================================================

THIS_FILE = Path(__file__).resolve()
CWD = Path.cwd().resolve()


def _looks_like_colab_root(path: Path) -> bool:
    return str(path).replace("\\", "/").rstrip("/") == "/content"


def _side_value_from_name(side: str) -> int:
    if side == "long":
        return 1
    if side == "short":
        return -1
    raise ValueError(f"Unsupported edge side: {side!r}. Expected 'long' or 'short'.")


def _parse_edge_segment(edge_segment: str) -> tuple[str, str]:
    family, sep, side = edge_segment.rpartition("_")
    if not sep or not family or side not in {"long", "short"}:
        raise ValueError(
            f"Cannot parse edge segment {edge_segment!r}. Expected '<family>_long' or '<family>_short'."
        )
    return family, side


def _context_from_edge_root(edge_root: Path) -> dict[str, Any]:
    asset = edge_root.parent.parent.name
    family, side = _parse_edge_segment(edge_root.name)
    edge_stem = f"{asset.lower()}_{family}_{side}"
    return {
        "asset": asset,
        "family": family,
        "side": side,
        "side_value": _side_value_from_name(side),
        "edge_id": f"{asset}/{family}_{side}",
        "edge_stem": edge_stem,
    }


def _context_from_edge_stem(edge_stem: str) -> dict[str, Any]:
    parts = edge_stem.split("_")
    if len(parts) < 3:
        raise ValueError(f"Cannot parse edge stem {edge_stem!r}. Expected '<asset>_<family>_<side>'.")
    asset = parts[0].upper()
    side = parts[-1]
    family = "_".join(parts[1:-1])
    if side not in {"long", "short"} or not family:
        raise ValueError(f"Cannot parse edge stem {edge_stem!r}. Expected '<asset>_<family>_<side>'.")
    return {
        "asset": asset,
        "family": family,
        "side": side,
        "side_value": _side_value_from_name(side),
        "edge_id": f"{asset}/{family}_{side}",
        "edge_stem": edge_stem,
    }


def _single_file(pattern: str, description: str) -> Path | None:
    matches = sorted(CWD.glob(pattern))
    if len(matches) == 0:
        return None
    if len(matches) > 1:
        raise ValueError(f"Flat mode found multiple {description} files for pattern {pattern!r}: {matches}")
    return matches[0]


def _resolve_paths() -> tuple[str, Path, Path, Path, Path, dict[str, Any]]:
    flat_model_rows = _single_file("*_model_rows.csv", "model-row")
    flat_feature_schema = CWD / "feature_schema.json"
    if _looks_like_colab_root(CWD) and flat_model_rows is not None and flat_feature_schema.exists():
        edge_stem = flat_model_rows.name.removesuffix("_model_rows.csv")
        context = _context_from_edge_stem(edge_stem)
        return "flat_colab", CWD, CWD, flat_model_rows, flat_feature_schema, context

    edge_root = THIS_FILE.parents[1]
    v2_root = THIS_FILE.parents[5]
    context = _context_from_edge_root(edge_root)
    model_rows_path = edge_root / "artifacts" / "research_dataset" / f"{context['edge_stem']}_model_rows.csv"
    feature_schema_path = edge_root / "contracts" / "feature_schema.json"
    return "repo", v2_root, edge_root, model_rows_path, feature_schema_path, context


RUN_MODE, V2_ROOT, EDGE_ROOT, MODEL_ROWS_PATH, FEATURE_SCHEMA_PATH, EDGE_CONTEXT = _resolve_paths()
ASSET = EDGE_CONTEXT["asset"]
FAMILY = EDGE_CONTEXT["family"]
SIDE = EDGE_CONTEXT["side"]
SIDE_VALUE = EDGE_CONTEXT["side_value"]
EDGE_ID = EDGE_CONTEXT["edge_id"]
EDGE_STEM = EDGE_CONTEXT["edge_stem"]

OUTPUT_DIR = CWD if RUN_MODE == "flat_colab" else EDGE_ROOT / "artifacts" / "feature_surgery"

OUTPUT_ITERATION_REPORT_CSV = OUTPUT_DIR / f"{EDGE_STEM}_iterative_cfi_report.csv"
OUTPUT_FINAL_CLUSTER_REPORT_CSV = OUTPUT_DIR / f"{EDGE_STEM}_final_cluster_report.csv"
OUTPUT_CORRELATION_MATRIX_CSV = OUTPUT_DIR / f"{EDGE_STEM}_feature_correlation_matrix.csv"
OUTPUT_SELECTED_FEATURES_JSON = OUTPUT_DIR / f"{EDGE_STEM}_selected_features.json"
OUTPUT_MANIFEST_JSON = OUTPUT_DIR / "feature_surgery_manifest.json"

TARGET_COL = "meta_label"
T1_COL = "t1"
EVENT_VOL_COL = "Event_Vol"
TIME_COL = "Datetime"

# V2 edges are side-specialized. Do not force constant side into the model.
OPTIONAL_FIXED_FEATURES: list[str] = []

# V1 leakage/metadata columns plus V2 probability/risk outputs.
LEAKAGE_COLS = {
    TARGET_COL,
    T1_COL,
    "barrier_hit",
    "Bar_Start",
    "entry_price",
    "pt_price",
    "sl_price",
    "realized_r",
    "resolution_source",
    "raw_probability",
    "calibrated_probability",
    "afml_bet_size",
    "approved_signal",
}

NON_FEATURE_COLS = {
    TIME_COL,
}

# V1 deliberately removed raw price levels and absolute price-unit columns.
# V2 still lets feature_schema.json be the authority first; this exclusion is a
# V1-compatible surgery policy applied only after schema filtering.
DROP_RAW_PRICE_COLS = {
    "Open",
    "High",
    "Low",
    "Close",
    "Kalman_Close",
    "EMA_10",
    "EMA_20",
    "EMA_50",
    "EMA_100",
    "EMA_200",
    "BBL_20_2",
    "BBM_20_2",
    "BBU_20_2",
    "DCL_20",
    "DCM_20",
    "DCU_20",
    "Range",
    "Body",
    "Upper_Wick",
    "Lower_Wick",
    "Body_Size",
    "ATR_14",
    "ATR_21",
    "ATR_50",
    "ATR_100",
    "OBV",
    "Proxy_Value",
    "Ticks",
}

# CPCV split generation only. Actual t1 overlap purge is manual below.
N_FOLDS = 5
N_TEST_FOLDS = 2
PURGED_SIZE = 0
EMBARGO_SIZE = 0
MANUAL_EMBARGO_SIZE = 100

# Clustering / surgery.
CLUSTER_DISTANCE_THRESHOLD = 0.5
MAX_ITERATIONS = 50
MIN_CANDIDATE_FEATURES = 5
F1_THRESHOLD_GRID = np.round(np.arange(0.30, 0.81, 0.01), 2)

# V1 XGBoost CFI/MDA model.
XGB_PARAMS = {
    "n_estimators": 500,
    "max_depth": 3,
    "learning_rate": 0.03,
    "min_child_weight": 25,
    "subsample": 0.75,
    "colsample_bytree": 0.75,
    "gamma": 0.5,
    "reg_alpha": 0.10,
    "reg_lambda": 10.0,
    "objective": "binary:logistic",
    "eval_metric": "aucpr",
    "random_state": 42,
    "n_jobs": -1,
}


class FeatureSurgeryError(RuntimeError):
    """Raised when feature surgery must fail closed."""


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def json_default(obj: Any) -> Any:
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.ndarray,)):
        return obj.tolist()
    if isinstance(obj, (pd.Timestamp,)):
        return obj.isoformat()
    return str(obj)


def save_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, default=json_default) + "\n", encoding="utf-8")


def display_path(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(V2_ROOT.resolve())).replace("\\", "/")
    except Exception:
        return str(path.resolve()).replace("\\", "/")


def get_xgb_device_kwargs() -> dict[str, Any]:
    """V1-compatible XGBoost GPU helper."""
    try:
        major = int(xgb.__version__.split(".")[0])
    except Exception:
        major = 2
    if major >= 2:
        return {"tree_method": "hist", "device": "cuda"}
    return {"tree_method": "gpu_hist"}


def make_model(params: dict[str, Any]) -> xgb.XGBClassifier:
    return xgb.XGBClassifier(**params, **get_xgb_device_kwargs())


def fit_model_safely(model: xgb.XGBClassifier, x_train: pd.DataFrame, y_train: pd.Series, sample_weight: np.ndarray) -> xgb.XGBClassifier:
    """Fit on GPU when available, retry on CPU if the local XGBoost/GPU stack fails."""
    try:
        model.fit(x_train, y_train, sample_weight=sample_weight)
        return model
    except Exception as exc:
        print(f"GPU/accelerated XGBoost fit failed; retrying on CPU. Reason: {exc}", flush=True)
        params = model.get_params()
        params.pop("device", None)
        params["tree_method"] = "hist"
        cpu_model = xgb.XGBClassifier(**params)
        cpu_model.fit(x_train, y_train, sample_weight=sample_weight)
        return cpu_model


def load_feature_schema_allowed_features() -> list[str]:
    if not FEATURE_SCHEMA_PATH.exists():
        raise FeatureSurgeryError(f"Missing feature schema: {FEATURE_SCHEMA_PATH}")
    schema = json.loads(FEATURE_SCHEMA_PATH.read_text(encoding="utf-8"))
    features = []
    for row in schema.get("features", []):
        if (
            row.get("live_available") is True
            and row.get("allowed_for_model_input") is True
            and row.get("uses_future_information") is False
        ):
            features.append(str(row["feature_name"]))
    if not features:
        raise FeatureSurgeryError("feature_schema.json has no allowed model-input features.")
    return features


def _validate_edge_contract(df: pd.DataFrame) -> None:
    if "edge_id" in df.columns and not (df["edge_id"] == EDGE_ID).all():
        bad = df.loc[df["edge_id"] != EDGE_ID, "edge_id"].unique().tolist()
        raise FeatureSurgeryError(f"{EDGE_ID} model rows contain wrong edge_id values: {bad}")
    if "side" in df.columns and not (pd.to_numeric(df["side"], errors="coerce") == SIDE_VALUE).all():
        bad = df.loc[pd.to_numeric(df["side"], errors="coerce") != SIDE_VALUE, "side"].unique().tolist()
        raise FeatureSurgeryError(f"{EDGE_ID} model rows contain wrong side values: {bad}; expected {SIDE_VALUE}")
    if "pt_price" in df.columns and "entry_price" in df.columns:
        pt = pd.to_numeric(df["pt_price"], errors="coerce")
        entry = pd.to_numeric(df["entry_price"], errors="coerce")
        if SIDE_VALUE == 1 and not (pt > entry).all():
            raise FeatureSurgeryError(f"{EDGE_ID} model rows must have pt_price above entry_price for long edges.")
        if SIDE_VALUE == -1 and not (pt < entry).all():
            raise FeatureSurgeryError(f"{EDGE_ID} model rows must have pt_price below entry_price for short edges.")
    if "sl_price" in df.columns and "entry_price" in df.columns:
        sl = pd.to_numeric(df["sl_price"], errors="coerce")
        entry = pd.to_numeric(df["entry_price"], errors="coerce")
        if SIDE_VALUE == 1 and not (sl < entry).all():
            raise FeatureSurgeryError(f"{EDGE_ID} model rows must have sl_price below entry_price for long edges.")
        if SIDE_VALUE == -1 and not (sl > entry).all():
            raise FeatureSurgeryError(f"{EDGE_ID} model rows must have sl_price above entry_price for short edges.")


def load_model_rows() -> pd.DataFrame:
    if not MODEL_ROWS_PATH.exists():
        raise FeatureSurgeryError(f"Missing exported V2 model rows: {MODEL_ROWS_PATH}")
    df = pd.read_csv(MODEL_ROWS_PATH)
    _validate_edge_contract(df)
    required = [TIME_COL, TARGET_COL, EVENT_VOL_COL, T1_COL]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise FeatureSurgeryError(f"Model rows missing required columns: {missing}")
    df[TIME_COL] = pd.to_datetime(df[TIME_COL], utc=True, errors="coerce")
    df[T1_COL] = pd.to_datetime(df[T1_COL], utc=True, errors="coerce")
    df[TARGET_COL] = pd.to_numeric(df[TARGET_COL], errors="coerce")
    df[EVENT_VOL_COL] = pd.to_numeric(df[EVENT_VOL_COL], errors="coerce")
    df = df.dropna(subset=[TIME_COL, T1_COL, TARGET_COL, EVENT_VOL_COL]).copy()
    df[TARGET_COL] = df[TARGET_COL].astype(int)
    df = df.sort_values(TIME_COL).set_index(TIME_COL)
    if df.empty:
        raise FeatureSurgeryError("Model rows are empty after normalization.")
    if df[TARGET_COL].nunique() < 2:
        raise FeatureSurgeryError("meta_label has fewer than 2 classes. Cannot run feature surgery.")
    return df


def choose_candidate_features(df: pd.DataFrame, schema_features: list[str]) -> tuple[list[str], list[str], dict[str, Any]]:
    present_allowed = [f for f in schema_features if f in df.columns]
    missing_from_rows = [f for f in schema_features if f not in df.columns]

    fixed = []
    for col in OPTIONAL_FIXED_FEATURES:
        if col in present_allowed and col not in LEAKAGE_COLS:
            fixed.append(col)

    candidates = []
    exclusion_reasons = {}
    for col in present_allowed:
        if col in fixed:
            continue
        reason = None
        if col in LEAKAGE_COLS:
            reason = "leakage_or_label_metadata"
        elif col in NON_FEATURE_COLS:
            reason = "timestamp_or_non_feature"
        elif col in DROP_RAW_PRICE_COLS:
            reason = "v1_raw_price_or_absolute_level_exclusion"
        elif col == "side":
            reason = "side_specialized_constant_metadata"
        elif not pd.api.types.is_numeric_dtype(df[col]):
            reason = "non_numeric"
        else:
            series = pd.to_numeric(df[col], errors="coerce")
            if series.notna().sum() == 0:
                reason = "all_nan_after_numeric_cast"
            elif series.nunique(dropna=True) <= 1:
                reason = "constant_or_single_value"

        if reason is not None:
            exclusion_reasons[col] = reason
            continue
        candidates.append(col)

    if not candidates:
        raise FeatureSurgeryError("No candidate features left after schema and V1-compatible exclusions.")

    diagnostics = {
        "schema_feature_count": len(schema_features),
        "present_allowed_feature_count": len(present_allowed),
        "missing_schema_features_from_model_rows": missing_from_rows,
        "fixed_features": fixed,
        "candidate_feature_count": len(candidates),
        "excluded_feature_count": len(exclusion_reasons),
        "exclusion_reasons": exclusion_reasons,
    }
    return fixed, candidates, diagnostics


def compute_uniqueness(df: pd.DataFrame) -> np.ndarray:
    """Average uniqueness over each event lifespan on the event timestamp grid."""
    if len(df) == 0:
        return np.array([], dtype=float)
    if T1_COL not in df.columns:
        raise FeatureSurgeryError("compute_uniqueness requires t1 column.")

    work = df[[T1_COL]].copy().sort_index()
    work[T1_COL] = pd.to_datetime(work[T1_COL], utc=True, errors="coerce")
    n = len(work)
    index_ns = pd.DatetimeIndex(work.index).astype("int64").to_numpy()
    t1_series = work[T1_COL]
    start_pos = np.arange(n, dtype=int)
    end_pos = start_pos.copy()

    valid_t1 = ~t1_series.isna()
    if valid_t1.any():
        t1_ns = pd.DatetimeIndex(t1_series.loc[valid_t1]).astype("int64").to_numpy()
        raw_end_pos = np.searchsorted(index_ns, t1_ns, side="right") - 1
        raw_end_pos = np.clip(raw_end_pos, 0, n - 1)
        end_pos[np.where(valid_t1.values)[0]] = raw_end_pos

    end_pos = np.maximum(end_pos, start_pos)
    diff = np.zeros(n + 1, dtype=float)
    np.add.at(diff, start_pos, 1.0)
    np.add.at(diff, end_pos + 1, -1.0)
    concurrency = np.cumsum(diff[:-1])
    inv_concurrency = np.divide(1.0, concurrency, out=np.ones_like(concurrency), where=concurrency > 0)
    prefix = np.concatenate([[0.0], np.cumsum(inv_concurrency)])
    lengths = (end_pos - start_pos + 1).astype(float)
    uniqueness_sorted = (prefix[end_pos + 1] - prefix[start_pos]) / lengths
    uniqueness_sorted = np.nan_to_num(uniqueness_sorted, nan=1.0, posinf=1.0, neginf=1.0)
    uniqueness_series = pd.Series(uniqueness_sorted, index=work.index).reindex(df.index)
    return uniqueness_series.fillna(1.0).to_numpy(dtype=float)


def make_train_weights(df: pd.DataFrame, y: pd.Series, train_idx: np.ndarray) -> np.ndarray:
    train_idx = np.asarray(train_idx, dtype=int)
    y_train = y.iloc[train_idx]
    train_df = df.iloc[train_idx].copy()
    class_w = compute_sample_weight(class_weight="balanced", y=y_train)
    magnitude = np.maximum(pd.to_numeric(train_df[EVENT_VOL_COL], errors="coerce").fillna(0.0).to_numpy(dtype=float), 1e-8)
    uniq = compute_uniqueness(train_df)
    final_w = class_w * magnitude * uniq
    mean_w = np.mean(final_w)
    if not np.isfinite(mean_w) or mean_w <= 0:
        return np.ones(len(train_idx), dtype=float)
    return final_w / mean_w


def flatten_cv_indices(idx: Any) -> np.ndarray:
    if isinstance(idx, np.ndarray):
        return np.unique(idx.astype(int))
    if hasattr(idx, "__iter__"):
        parts = []
        for part in idx:
            parts.append(np.atleast_1d(part).astype(int))
        return np.unique(np.concatenate(parts)) if parts else np.array([], dtype=int)
    return np.array([int(idx)])


def purge_train_overlaps(train_idx: np.ndarray, test_idx: np.ndarray, index: pd.Index, t1: pd.Series) -> np.ndarray:
    train_idx = np.asarray(train_idx, dtype=int)
    test_idx = np.asarray(test_idx, dtype=int)
    if len(train_idx) == 0 or len(test_idx) == 0:
        return train_idx

    train_starts = index[train_idx].values.astype("datetime64[ns]")
    train_ends = t1.iloc[train_idx].values.astype("datetime64[ns]")
    test_starts = index[test_idx].values.astype("datetime64[ns]")
    test_ends = t1.iloc[test_idx].values.astype("datetime64[ns]")

    keep_mask = np.ones(len(train_idx), dtype=bool)
    for i in range(len(train_idx)):
        overlaps = (train_starts[i] <= test_ends) & (train_ends[i] >= test_starts)
        if overlaps.any():
            keep_mask[i] = False
    return train_idx[keep_mask]


def apply_embargo(train_idx: np.ndarray, test_idx: np.ndarray, n_samples: int, embargo_size: int) -> np.ndarray:
    train_idx = np.asarray(train_idx, dtype=int)
    test_idx = np.sort(np.unique(np.asarray(test_idx, dtype=int)))
    if len(train_idx) == 0 or len(test_idx) == 0 or embargo_size <= 0:
        return train_idx

    keep_mask = np.ones(len(train_idx), dtype=bool)
    block_ends = []
    for i in range(1, len(test_idx)):
        if test_idx[i] != test_idx[i - 1] + 1:
            block_ends.append(test_idx[i - 1])
    block_ends.append(test_idx[-1])

    for block_end in block_ends:
        embargo_start = block_end + 1
        embargo_end = min(embargo_start + embargo_size, n_samples)
        keep_mask &= (train_idx < embargo_start) | (train_idx >= embargo_end)
    return train_idx[keep_mask]


def build_feature_clusters(x: pd.DataFrame) -> tuple[dict[int, list[str]], pd.DataFrame]:
    if x.shape[1] == 1:
        corr_df = pd.DataFrame([[1.0]], index=x.columns, columns=x.columns)
        return {1: list(x.columns)}, corr_df

    corr_matrix, _ = stats.spearmanr(x)
    corr_matrix = np.asarray(corr_matrix)
    if corr_matrix.ndim != 2:
        raise FeatureSurgeryError("Correlation matrix is not 2D; clustering failed.")

    corr_matrix = np.nan_to_num(np.clip(corr_matrix, -1.0, 1.0))
    dist_matrix = np.sqrt(np.clip(0.5 * (1.0 - corr_matrix), 0.0, 1.0))
    dist_matrix = (dist_matrix + dist_matrix.T) / 2.0
    np.fill_diagonal(dist_matrix, 0.0)

    linkage_matrix = sch.linkage(squareform(dist_matrix), method="ward")
    cluster_labels = sch.fcluster(linkage_matrix, t=CLUSTER_DISTANCE_THRESHOLD, criterion="distance")

    clusters: dict[int, list[str]] = {}
    for i, cid in enumerate(cluster_labels):
        clusters.setdefault(int(cid), []).append(str(x.columns[i]))

    corr_df = pd.DataFrame(corr_matrix, index=x.columns, columns=x.columns)
    return clusters, corr_df


def get_positive_class_proba(model: xgb.XGBClassifier, x: pd.DataFrame) -> np.ndarray:
    proba = model.predict_proba(x)
    if proba.shape[1] == 1:
        cls = int(model.classes_[0])
        return np.ones(len(x), dtype=float) if cls == 1 else np.zeros(len(x), dtype=float)
    class_to_col = {int(cls): i for i, cls in enumerate(model.classes_)}
    if 1 not in class_to_col:
        return np.zeros(len(x), dtype=float)
    return proba[:, class_to_col[1]]


def find_best_f1_threshold(y_true: pd.Series, proba: np.ndarray) -> tuple[float, float]:
    y_arr = np.asarray(y_true).astype(int)
    best_thr = 0.50
    best_f1 = -np.inf
    for thr in F1_THRESHOLD_GRID:
        pred = (proba >= thr).astype(int)
        score = f1_score(y_arr, pred, zero_division=0)
        if score > best_f1:
            best_f1 = float(score)
            best_thr = float(thr)
    return best_thr, best_f1


def score_at_threshold(y_true: pd.Series, proba: np.ndarray, threshold: float) -> dict[str, float]:
    pred = (proba >= threshold).astype(int)
    return {
        "f1": float(f1_score(y_true, pred, zero_division=0)),
        "precision": float(precision_score(y_true, pred, zero_division=0)),
        "recall": float(recall_score(y_true, pred, zero_division=0)),
    }


def run_clustered_mda(df: pd.DataFrame, fixed_features: list[str], cluster_features: list[str]) -> tuple[pd.DataFrame, dict[int, list[str]], pd.DataFrame, dict[str, Any]]:
    if CombinatorialPurgedCV is None:
        raise FeatureSurgeryError(
            "skfolio.model_selection.CombinatorialPurgedCV is required. "
            f"Original import error: {SKFOLIO_IMPORT_ERROR}"
        )

    x_cluster = df[cluster_features].copy()
    y = df[TARGET_COL].copy()
    clusters, corr_df = build_feature_clusters(x_cluster)

    cv = CombinatorialPurgedCV(
        n_folds=N_FOLDS,
        n_test_folds=N_TEST_FOLDS,
        purged_size=PURGED_SIZE,
        embargo_size=EMBARGO_SIZE,
    )

    mda_scores = {cid: [] for cid in clusters.keys()}
    base_f1_scores = []
    base_precision_scores = []
    base_recall_scores = []
    fold_thresholds = []
    fold_count = 0

    for split_num, (train_idx, test_idx) in enumerate(cv.split(x_cluster), start=1):
        train_idx = flatten_cv_indices(train_idx)
        test_idx = flatten_cv_indices(test_idx)
        train_idx = purge_train_overlaps(train_idx, test_idx, df.index, df[T1_COL])
        train_idx = apply_embargo(train_idx, test_idx, len(df), MANUAL_EMBARGO_SIZE)

        if len(train_idx) == 0 or len(test_idx) == 0:
            continue

        if fixed_features:
            x_train = pd.concat([df[fixed_features].iloc[train_idx], x_cluster.iloc[train_idx]], axis=1)
            x_test = pd.concat([df[fixed_features].iloc[test_idx], x_cluster.iloc[test_idx]], axis=1)
        else:
            x_train = x_cluster.iloc[train_idx].copy()
            x_test = x_cluster.iloc[test_idx].copy()

        y_train = y.iloc[train_idx]
        y_test = y.iloc[test_idx]
        if y_train.nunique() < 2:
            continue

        weights = make_train_weights(df, y, train_idx)
        model = fit_model_safely(make_model(XGB_PARAMS), x_train, y_train, weights)

        train_proba = get_positive_class_proba(model, x_train)
        best_thr, _ = find_best_f1_threshold(y_train, train_proba)
        fold_thresholds.append(best_thr)

        base_proba = get_positive_class_proba(model, x_test)
        base_metrics = score_at_threshold(y_test, base_proba, best_thr)
        base_f1_scores.append(base_metrics["f1"])
        base_precision_scores.append(base_metrics["precision"])
        base_recall_scores.append(base_metrics["recall"])
        fold_count += 1

        for cid, feats in clusters.items():
            x_shuffled = x_test.copy()
            perm = RNG.permutation(len(x_shuffled))
            for feat in feats:
                x_shuffled.loc[:, feat] = x_shuffled[feat].iloc[perm].values
            shuffled_proba = get_positive_class_proba(model, x_shuffled)
            shuffled_f1 = score_at_threshold(y_test, shuffled_proba, best_thr)["f1"]
            mda_scores[cid].append(base_metrics["f1"] - shuffled_f1)

    cluster_rows = []
    for cid, feats in clusters.items():
        values = mda_scores[cid]
        cluster_rows.append({
            "cluster_id": int(cid),
            "n_features": int(len(feats)),
            "avg_mda": float(np.mean(values)) if values else np.nan,
            "std_mda": float(np.std(values, ddof=1)) if len(values) > 1 else np.nan,
            "features": feats,
        })

    report_df = pd.DataFrame(cluster_rows).sort_values("avg_mda", ascending=False).reset_index(drop=True)
    score_summary = {
        "mean_base_f1": float(np.mean(base_f1_scores)) if base_f1_scores else np.nan,
        "mean_base_precision": float(np.mean(base_precision_scores)) if base_precision_scores else np.nan,
        "mean_base_recall": float(np.mean(base_recall_scores)) if base_recall_scores else np.nan,
        "mean_train_selected_threshold": float(np.mean(fold_thresholds)) if fold_thresholds else np.nan,
        "fold_count_used": int(fold_count),
    }
    return report_df, clusters, corr_df, score_summary


def iterative_feature_surgery(df: pd.DataFrame, fixed_features: list[str], initial_candidates: list[str]):
    current_features = list(initial_candidates)
    iteration_rows = []
    final_report_df = pd.DataFrame()
    final_clusters: dict[int, list[str]] = {}
    final_corr_df = pd.DataFrame()
    final_score_summary: dict[str, Any] = {}

    for iteration in range(1, MAX_ITERATIONS + 1):
        if len(current_features) < MIN_CANDIDATE_FEATURES:
            print(f"Stopping: candidate feature count below minimum ({MIN_CANDIDATE_FEATURES}).", flush=True)
            break

        print("\n" + "-" * 72, flush=True)
        print(f"ITERATION {iteration}", flush=True)
        print(f"Current candidate feature count: {len(current_features):,}", flush=True)

        report_df, clusters, corr_df, score_summary = run_clustered_mda(
            df=df,
            fixed_features=fixed_features,
            cluster_features=current_features,
        )
        final_report_df = report_df.copy()
        final_clusters = clusters
        final_corr_df = corr_df.copy()
        final_score_summary = dict(score_summary)

        print(report_df[["cluster_id", "n_features", "avg_mda", "std_mda"]].to_string(index=False), flush=True)
        print(
            f"Base F1={score_summary.get('mean_base_f1', np.nan):.6f} | "
            f"Precision={score_summary.get('mean_base_precision', np.nan):.6f} | "
            f"Recall={score_summary.get('mean_base_recall', np.nan):.6f} | "
            f"Mean train-selected threshold={score_summary.get('mean_train_selected_threshold', np.nan):.4f} | "
            f"Folds={score_summary.get('fold_count_used', 0)}",
            flush=True,
        )

        for _, row in report_df.iterrows():
            iteration_rows.append({
                "iteration": iteration,
                "cluster_id": int(row["cluster_id"]),
                "n_features": int(row["n_features"]),
                "avg_mda": float(row["avg_mda"]) if pd.notna(row["avg_mda"]) else np.nan,
                "std_mda": float(row["std_mda"]) if pd.notna(row["std_mda"]) else np.nan,
                "features": row["features"],
                "base_f1": score_summary.get("mean_base_f1", np.nan),
                "base_precision": score_summary.get("mean_base_precision", np.nan),
                "base_recall": score_summary.get("mean_base_recall", np.nan),
                "mean_train_selected_threshold": score_summary.get("mean_train_selected_threshold", np.nan),
                "fold_count_used": score_summary.get("fold_count_used", 0),
            })

        negative_clusters = report_df[report_df["avg_mda"] < 0].copy()
        if negative_clusters.empty:
            print("Stopping: no negative MDA clusters remain.", flush=True)
            break

        worst_row = negative_clusters.sort_values("avg_mda", ascending=True).iloc[0]
        worst_cluster_id = int(worst_row["cluster_id"])
        worst_score = float(worst_row["avg_mda"])
        worst_features = clusters[worst_cluster_id]

        print(f"Removing worst cluster {worst_cluster_id} | avg_mda={worst_score:.6f}", flush=True)
        print(f"Features removed: {worst_features}", flush=True)
        current_features = [f for f in current_features if f not in worst_features]

        if len(current_features) == 0:
            print("Stopping: no candidate features remain after removal.", flush=True)
            break

    selected_features = list(fixed_features) + list(current_features)
    iteration_report_df = pd.DataFrame(iteration_rows)
    return selected_features, iteration_report_df, final_report_df, final_clusters, final_corr_df, final_score_summary


def write_outputs(
    selected_features: list[str],
    iteration_report_df: pd.DataFrame,
    final_report_df: pd.DataFrame,
    final_clusters: dict[int, list[str]],
    final_corr_df: pd.DataFrame,
    final_score_summary: dict[str, Any],
    diagnostics: dict[str, Any],
    rows_used: int,
    date_start: Any,
    date_end: Any,
) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if not iteration_report_df.empty:
        out = iteration_report_df.copy()
        out["features"] = out["features"].apply(lambda x: ", ".join(x) if isinstance(x, list) else str(x))
        out.to_csv(OUTPUT_ITERATION_REPORT_CSV, index=False)

    if not final_report_df.empty:
        out = final_report_df.copy()
        out["features"] = out["features"].apply(lambda x: ", ".join(x) if isinstance(x, list) else str(x))
        out.to_csv(OUTPUT_FINAL_CLUSTER_REPORT_CSV, index=False)

    if not final_corr_df.empty:
        final_corr_df.to_csv(OUTPUT_CORRELATION_MATRIX_CSV)

    # V1-compatible selected-features artifact: pure list.
    save_json(OUTPUT_SELECTED_FEATURES_JSON, selected_features)

    manifest = {
        "created_at": now_utc(),
        "edge_id": EDGE_ID,
        "run_mode": RUN_MODE,
        "script": display_path(THIS_FILE),
        "blueprint_stage": "feature_surgery_before_model_training",
        "feature_engineering_performed_here": False,
        "input_model_rows": display_path(MODEL_ROWS_PATH),
        "input_feature_schema": display_path(FEATURE_SCHEMA_PATH),
        "rows_used": int(rows_used),
        "date_start": str(date_start),
        "date_end": str(date_end),
        "fixed_features": diagnostics["fixed_features"],
        "initial_candidate_feature_count": diagnostics["candidate_feature_count"],
        "selected_feature_count": int(len(selected_features)),
        "selected_features": selected_features,
        "final_score_summary": final_score_summary,
        "feature_schema_diagnostics": diagnostics,
        "side_specialization": {
            "edge_side": SIDE,
            "side_value": SIDE_VALUE,
            "side_column_forced_as_model_input": False,
        },
        "scoring": {
            "primary_metric": "f1",
            "mda_formula": "base_f1 - shuffled_f1",
            "threshold_selection": "best F1 threshold selected on train fold only, applied to test fold",
            "threshold_grid": F1_THRESHOLD_GRID.tolist(),
        },
        "cpcv": {
            "n_folds": N_FOLDS,
            "n_test_folds": N_TEST_FOLDS,
            "purged_size": PURGED_SIZE,
            "embargo_size": EMBARGO_SIZE,
            "manual_embargo_size": MANUAL_EMBARGO_SIZE,
            "mode": "manual_t1_overlap_purge_after_cpcv_split_generation",
        },
        "cluster_distance_threshold": CLUSTER_DISTANCE_THRESHOLD,
        "max_iterations": MAX_ITERATIONS,
        "min_candidate_features": MIN_CANDIDATE_FEATURES,
        "xgb_params": {**XGB_PARAMS, **get_xgb_device_kwargs()},
        "outputs": {
            "selected_features": display_path(OUTPUT_SELECTED_FEATURES_JSON),
            "iteration_report": display_path(OUTPUT_ITERATION_REPORT_CSV),
            "final_cluster_report": display_path(OUTPUT_FINAL_CLUSTER_REPORT_CSV),
            "correlation_matrix": display_path(OUTPUT_CORRELATION_MATRIX_CSV),
            "manifest": display_path(OUTPUT_MANIFEST_JSON),
        },
        "next_ordered_step": "02_train_meta_model_optuna.py",
        "notes": [
            "This script ports V1 Step 6C into V2.",
            "It consumes exported V2 side-specialized model rows only.",
            "It uses feature_schema.json as the model-input authority.",
            "It does not create new features.",
            "Edge side is fixed by the edge package, so side is treated as constant metadata, not a forced model input.",
            "Negative-MDA clusters are removed one at a time and clustering is recomputed each iteration.",
            "The selected features should be consumed by the next V2 training step, not edited manually.",
            "Flat Colab mode writes outputs directly to the current working directory for easy download.",
        ],
    }
    save_json(OUTPUT_MANIFEST_JSON, manifest)


def main() -> None:
    print("=" * 80, flush=True)
    print(f"V2 STEP 01: ITERATIVE CLUSTERED MDA FEATURE SURGERY — {EDGE_ID}", flush=True)
    print("=" * 80, flush=True)
    print(f"Run mode: {RUN_MODE}", flush=True)
    print(f"Working directory: {CWD}", flush=True)
    print(f"Model rows: {MODEL_ROWS_PATH}", flush=True)
    print(f"Feature schema: {FEATURE_SCHEMA_PATH}", flush=True)
    print(f"Output directory: {OUTPUT_DIR}", flush=True)

    schema_features = load_feature_schema_allowed_features()
    df = load_model_rows()

    for col in schema_features:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    fixed_features, candidate_features, diagnostics = choose_candidate_features(df, schema_features)
    usable_cols = fixed_features + candidate_features
    before = len(df)
    df = df.dropna(subset=usable_cols).copy()
    after = len(df)
    if after == 0:
        raise FeatureSurgeryError("All rows dropped after selected candidate/fixed feature NaN filtering.")

    print(f"Rows before feature NaN filter: {before:,}", flush=True)
    print(f"Rows after feature NaN filter : {after:,}", flush=True)
    print(f"Date range: {df.index.min()} -> {df.index.max()}", flush=True)
    print(f"Schema allowed features: {len(schema_features):,}", flush=True)
    print(f"Fixed features: {fixed_features}", flush=True)
    print(f"Candidate features for clustering: {len(candidate_features):,}", flush=True)

    selected_features, iteration_report_df, final_report_df, final_clusters, final_corr_df, final_score_summary = iterative_feature_surgery(
        df=df,
        fixed_features=fixed_features,
        initial_candidates=candidate_features,
    )

    write_outputs(
        selected_features=selected_features,
        iteration_report_df=iteration_report_df,
        final_report_df=final_report_df,
        final_clusters=final_clusters,
        final_corr_df=final_corr_df,
        final_score_summary=final_score_summary,
        diagnostics=diagnostics,
        rows_used=len(df),
        date_start=df.index.min(),
        date_end=df.index.max(),
    )

    print("\n✅ V2 clustered MDA feature surgery completed.", flush=True)
    print(f"Selected features: {len(selected_features):,}", flush=True)
    print(f"Saved selected features: {OUTPUT_SELECTED_FEATURES_JSON}", flush=True)
    print(f"Saved manifest: {OUTPUT_MANIFEST_JSON}", flush=True)
    print("Next ordered step: 02_train_meta_model_optuna.py", flush=True)

    if RUN_MODE == "flat_colab":
        print("\nFlat Colab output files to download:", flush=True)
        for path in [
            OUTPUT_SELECTED_FEATURES_JSON,
            OUTPUT_ITERATION_REPORT_CSV,
            OUTPUT_FINAL_CLUSTER_REPORT_CSV,
            OUTPUT_CORRELATION_MATRIX_CSV,
            OUTPUT_MANIFEST_JSON,
        ]:
            print(f"  - {path}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except FeatureSurgeryError as exc:
        raise SystemExit(f"❌ {exc}") from exc
