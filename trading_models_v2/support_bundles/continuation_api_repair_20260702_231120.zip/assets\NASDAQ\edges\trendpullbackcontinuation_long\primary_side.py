"""
Primary-side logic for NASDAQ/trendpullbackcontinuation_long.

This edge is long-only. The side comes from positive medium-term drift plus
short-term pullback/reclaim timing, not from positive CUSUM impulse, Kalman
fair-value deviation, SMC, tick volume, or order-book logic.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pandas as pd

_THIS_FILE = Path(__file__).resolve()
_EDGE_ROOT = _THIS_FILE.parent
_V2_ROOT = _THIS_FILE.parents[4]
_REPO_ROOT = _THIS_FILE.parents[5]
for _path in (_EDGE_ROOT, _V2_ROOT, _REPO_ROOT):
    path_str = str(_path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from shared.ffd.verify_asset_ffd_manifest import verify_asset_ffd_manifest  # noqa: E402

EDGE_ID = "NASDAQ/trendpullbackcontinuation_long"
ASSET = "NASDAQ"
SIDE_VALUE = 1
LIVE_BUFFER_BARS = 500
MIN_TREND_SLOPE_50 = 0.0
MIN_EMA_20_50_GAP = 0.0
MAX_PULLBACK_RETURN_Z = -0.20
MAX_PULLBACK_RETURN = 0.0
MAX_CHANNEL_POSITION_20 = 0.70
MIN_CHANNEL_POSITION_50 = 0.30
MIN_CLOSE_LOCATION = 0.40
MIN_LOWER_WICK_SHARE = 0.05
MIN_PULLBACK_DEPTH_ATR = 0.05

FORBIDDEN_PRIMARY_SIDE_COLUMNS = {
    "meta_label", "t1", "barrier_hit", "resolution_source", "entry_price", "pt_price", "sl_price",
    "realized_r", "raw_probability", "calibrated_probability", "afml_bet_size", "approved_signal",
    "Ticks", "Proxy_Value", "Tick_Activity_Ratio", "Proxy_Value_Ratio", "Activity_Impulse",
}


class PrimarySideError(RuntimeError):
    """Raised when primary-side generation must fail closed."""


def load_verified_ffd_features(asset: str = ASSET) -> pd.DataFrame:
    verification = verify_asset_ffd_manifest(asset)
    path = _V2_ROOT / verification["features"]
    if not path.exists():
        raise PrimarySideError(f"Verified FFD features path does not exist: {path}")
    ffd = pd.read_csv(path)
    required = ["Datetime", "Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]
    missing = [col for col in required if col not in ffd.columns]
    if missing:
        raise PrimarySideError(f"FFD features missing required columns: {missing}")
    ffd["Datetime"] = pd.to_datetime(ffd["Datetime"], utc=True, errors="coerce")
    for col in ["Open_FFD", "High_FFD", "Low_FFD", "Close_FFD"]:
        ffd[col] = pd.to_numeric(ffd[col], errors="coerce")
    ffd = ffd.dropna(subset=required).sort_values("Datetime").reset_index(drop=True)
    if ffd.empty:
        raise PrimarySideError("Verified FFD features are empty after normalization.")
    return ffd


def _validate_primary_side_input(events: pd.DataFrame) -> pd.DataFrame:
    required = [
        "Datetime", "edge_id", "side", "Event_Vol", "Positive_Drift_State", "Pullback_Return",
        "Pullback_Return_Z", "Pullback_Depth_ATR", "Channel_Position_20_Context", "Channel_Position_50_Context",
        "Current_Close_Location", "Lower_Wick_Share_Context", "Pullback_Reclaim",
        "Trend_Pullback_Continuation_Event",
    ]
    missing = [col for col in required if col not in events.columns]
    if missing:
        raise PrimarySideError(f"Primary-side input missing required trend-pullback columns: {missing}")
    forbidden_present = sorted(FORBIDDEN_PRIMARY_SIDE_COLUMNS.intersection(events.columns))
    if forbidden_present:
        raise PrimarySideError(f"Primary-side input contains forbidden research/live-decision or volume-proxy columns: {forbidden_present}")

    out = events.copy()
    out["Datetime"] = pd.to_datetime(out["Datetime"], utc=True, errors="coerce")
    if "Bar_Start" in out.columns:
        out["Bar_Start"] = pd.to_datetime(out["Bar_Start"], utc=True, errors="coerce")
    numeric_cols = [
        "side", "Event_Vol", "Trend_Slope_50_Context", "EMA_20_50_Gap_Context", "FFD_Trend_Signal_50",
        "Positive_Drift_State", "Pullback_Return", "Pullback_Return_Z", "Pullback_Depth_ATR",
        "Channel_Position_20_Context", "Channel_Position_50_Context", "Current_Close_Location",
        "Lower_Wick_Share_Context", "Pullback_Reclaim", "Trend_Pullback_Continuation_Event",
    ]
    for col in [c for c in numeric_cols if c in out.columns]:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=[
        "Datetime", "side", "Event_Vol", "Positive_Drift_State", "Pullback_Return", "Pullback_Return_Z",
        "Pullback_Depth_ATR", "Channel_Position_20_Context", "Channel_Position_50_Context",
        "Current_Close_Location", "Lower_Wick_Share_Context", "Pullback_Reclaim", "Trend_Pullback_Continuation_Event",
    ]).copy()
    if out.empty:
        raise PrimarySideError("Primary-side input is empty after normalization.")
    if not (out["edge_id"] == EDGE_ID).all():
        bad = out.loc[out["edge_id"] != EDGE_ID, "edge_id"].unique().tolist()
        raise PrimarySideError(f"trendpullbackcontinuation_long primary side received wrong edge_id values: {bad}")
    return out.sort_values("Datetime").reset_index(drop=True)


def assign_trendpullbackcontinuation_long_primary_side(events: pd.DataFrame) -> pd.DataFrame:
    out = _validate_primary_side_input(events)
    pullback_ok = (
        (pd.to_numeric(out["Pullback_Return"], errors="coerce") <= MAX_PULLBACK_RETURN)
        | (pd.to_numeric(out["Pullback_Return_Z"], errors="coerce") <= MAX_PULLBACK_RETURN_Z)
    )
    reclaim_ok = (
        (pd.to_numeric(out["Current_Close_Location"], errors="coerce") >= MIN_CLOSE_LOCATION)
        | (pd.to_numeric(out["Lower_Wick_Share_Context"], errors="coerce") >= MIN_LOWER_WICK_SHARE)
    )
    long_condition = (
        (pd.to_numeric(out["Trend_Pullback_Continuation_Event"], errors="coerce") == 1)
        & (pd.to_numeric(out["Positive_Drift_State"], errors="coerce") == 1)
        & pullback_ok
        & (pd.to_numeric(out["Channel_Position_20_Context"], errors="coerce") <= MAX_CHANNEL_POSITION_20)
        & (pd.to_numeric(out["Channel_Position_50_Context"], errors="coerce") >= MIN_CHANNEL_POSITION_50)
        & (pd.to_numeric(out["Pullback_Depth_ATR"], errors="coerce") >= MIN_PULLBACK_DEPTH_ATR)
        & reclaim_ok
        & (pd.to_numeric(out["Pullback_Reclaim"], errors="coerce") == 1)
    )
    out = out[long_condition].copy()
    if out.empty:
        raise PrimarySideError("No trendpullbackcontinuation_long events survived pullback-continuation primary-side mapping.")
    out["side"] = SIDE_VALUE
    out["primary_side"] = SIDE_VALUE
    out["primary_side_filter"] = 1
    out["primary_side_rule"] = "positive medium-term drift + short-term pullback/reclaim -> side=+1 long"
    return out.sort_values("Datetime").reset_index(drop=True)


def filter_long_events_with_primary_side(events: pd.DataFrame, features: pd.DataFrame | None = None) -> pd.DataFrame:
    return assign_trendpullbackcontinuation_long_primary_side(events)


def validate_primary_side_events(events: pd.DataFrame) -> None:
    out = assign_trendpullbackcontinuation_long_primary_side(events)
    if out.empty:
        raise PrimarySideError("Validated trendpullbackcontinuation_long primary-side output is empty.")


def primary_side_config() -> dict[str, Any]:
    return {
        "edge_id": EDGE_ID,
        "side_value": SIDE_VALUE,
        "side_rule": "Trend_Pullback_Continuation_Event=1 + positive drift + pullback/reclaim -> side=+1 long",
        "min_trend_slope_50": MIN_TREND_SLOPE_50,
        "min_ema_20_50_gap": MIN_EMA_20_50_GAP,
        "max_pullback_return_z": MAX_PULLBACK_RETURN_Z,
        "max_pullback_return": MAX_PULLBACK_RETURN,
        "max_channel_position_20": MAX_CHANNEL_POSITION_20,
        "min_channel_position_50": MIN_CHANNEL_POSITION_50,
        "min_close_location": MIN_CLOSE_LOCATION,
        "min_lower_wick_share": MIN_LOWER_WICK_SHARE,
        "min_pullback_depth_atr": MIN_PULLBACK_DEPTH_ATR,
        "uses_verified_shared_ffd": True,
        "live_buffer_bars": LIVE_BUFFER_BARS,
        "price_only_event_gate": True,
        "forbidden_volume_proxy_inputs": ["Ticks", "Proxy_Value", "Tick_Activity_Ratio", "Proxy_Value_Ratio", "Activity_Impulse"],
        "uses_future_information": False,
        "contains_labels": False,
        "contains_probabilities": False,
        "contains_execution_decisions": False,
    }


if __name__ == "__main__":
    print("✅ NASDAQ/trendpullbackcontinuation_long primary_side.py import/self-contract check passed.")
    print(primary_side_config())
